# Geo Office 1.3.0

Aplicación Android ligera, local y sin inicio de sesión para documentos, PDF y OCR.

## Novedades principales

### Contraseña real para PDF
- **Imágenes a PDF** ahora solicita nombre, contraseña y confirmación antes de crear el archivo.
- El PDF resultante queda cifrado y pide la contraseña al abrirse.
- Nueva herramienta **Proteger PDF con contraseña** para crear una copia protegida de un PDF existente.
- La contraseña debe tener entre 4 y 127 caracteres.
- La app no almacena la contraseña ni puede recuperarla si se olvida.

La protección se realiza localmente mediante PDFBox-Android; los archivos no se suben a internet.

### Zoom y recuperación
- Zoom con dos dedos, desplazamiento y doble toque en OCR y PDF.
- Zoom por pellizco en el editor de documentos.
- Recuperación de la última sesión de Word, OCR y PDF al volver a abrir la app.

### Editor y OCR
- Formato de texto, listas, imágenes, tablas básicas, búsqueda, guardado DOCX/TXT y exportación PDF.
- OCR de varias imágenes, giro, blanco y negro, contraste, copia, compartir y exportación.

## Compatibilidad

La app está orientada a documentos normales y ligeros. Macros, animaciones avanzadas, fórmulas muy complejas y maquetación editorial extrema todavía no están incluidas.

## Compilación

El ZIP contiene el proyecto Android Studio completo y `gradlew`. GitHub Actions compila con Java 17 y Android SDK 35.

## Novedades 1.4.0

- Imágenes a PDF procesa las fotos una por una, sin límite artificial por cantidad o peso.
- Modo predeterminado **Mínimo peso**.
- Modos: mínimo, equilibrado, alta calidad y calidad original.
- Estimación del tamaño antes de convertir, con tamaño original y ahorro aproximado.
- Tamaño final real y ahorro real al terminar.
- PDF creado desde imágenes continúa protegido con contraseña obligatoria.
- Compresión de PDF existente con estimación previa y resultado final real.

## Versión 1.4.2

- Corrige de forma global el acceso nullable al contenido del editor Word.
- Centraliza todas las operaciones de formato, inserción, búsqueda, listas, guardado y autoguardado sobre un `Editable` no nulo.
- Evita la cadena de errores de compilación que aparecía línea por línea en `DocumentEditorActivity.kt`.


## Cambios 1.5.0

- Selección visual de imágenes dentro del documento.
- Arrastre para cambiar la posición de la imagen dentro del texto.
- Redimensionado desde la esquina inferior derecha y desde la barra contextual.
- Girar, reemplazar, eliminar, alinear y mover imágenes por párrafos.
- Apertura de imágenes guardadas dentro de DOCX creados por Geo Office.
- Recuperación de sesión mediante un DOCX temporal para conservar imágenes y formato básico.
- Imágenes a PDF con ventana completa, botones fijos, contraseña opcional y compresión mínima por defecto.
- Miniaturas reordenables por arrastre y eliminación individual antes de crear el PDF.

## Cambios 1.6.0

### Excel
- Varias hojas con pestañas: crear, renombrar, duplicar y eliminar.
- Insertar y eliminar filas o columnas.
- Negrita, cursiva, color de texto, color de celda y alineación.
- Formatos normal, moneda peruana `S/`, porcentaje y decimales.
- Copiar, pegar y limpiar la celda seleccionada.
- Fórmulas básicas: `SUM`, `AVERAGE`, `MIN`, `MAX`, `COUNT` y operaciones entre celdas.
- Guardado y reapertura de hojas, fórmulas y formato básico en XLSX.
- Recuperación automática del libro y de la hoja activa al volver a abrir la app.

### PowerPoint
- Banda de miniaturas para navegar entre diapositivas.
- Crear, duplicar, eliminar y reordenar diapositivas.
- Mover título, contenido e imagen directamente sobre la diapositiva.
- Redimensionar la imagen desde una esquina.
- Insertar o quitar imagen y cambiar el color de fondo.
- Presentación en pantalla completa.
- Guardado y reapertura de posiciones, fondos e imágenes en PPTX.
- Exportación a PDF conservando la distribución básica.
- Recuperación automática de la presentación y de la diapositiva activa.

## Límites actuales

Geo Office sigue siendo una alternativa ligera, no una copia completa de WPS. Aún no incluye macros, gráficos complejos, tablas dinámicas, combinación avanzada de celdas, múltiples objetos por diapositiva, animaciones ni transiciones profesionales. Los archivos de Office muy complejos pueden abrirse de forma parcial.
