package com.geooffice.app.ui

import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import com.geooffice.app.MainActivity
import com.geooffice.app.R
import com.geooffice.app.databinding.ActivityPresentationBinding
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.office.GeoSlide
import com.geooffice.app.office.OpenXmlPptx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.util.UriUtils
import com.google.android.material.card.MaterialCardView
import java.io.File
import kotlin.math.max

class PresentationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPresentationBinding
    private val slides = mutableListOf(GeoSlide("Título de la diapositiva", "Contenido"))
    private var currentIndex = 0
    private var currentUri: Uri? = null
    private var updating = false
    private var dragStartRawX = 0f
    private var dragStartRawY = 0f
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var resizeStartW = 0
    private var resizeStartH = 0
    private var disableAutoResumeOnExit = false
    private var pendingSlideIndex = 0
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }

    private val createPptx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation")
    ) { uri -> uri?.let { savePptx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    private val chooseImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { importSlideImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPresentationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupActions()
        setupTextWatchers()
        setupCanvasGestures()
        renderCurrent()

        val resumeMode = intent.getBooleanExtra(MainActivity.EXTRA_RESUME_SESSION, false)
        pendingSlideIndex = if (resumeMode) resumePrefs.getInt(ResumeSession.SLIDE_INDEX, 0) else 0
        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
            val sourceUri = Uri.parse(raw)
            currentUri = if (resumeMode) null else sourceUri
            binding.tvTitle.text = if (resumeMode) "Presentación recuperada" else UriUtils.displayName(this, sourceUri)
            loadFile(sourceUri)
        }
    }

    private fun setupActions() = with(binding) {
        btnBack.setOnClickListener { disableResumeAndFinish() }
        btnAddSlide.setOnClickListener { addSlide() }
        btnDeleteSlide.setOnClickListener { deleteSlide() }
        btnDuplicateSlide.setOnClickListener { duplicateSlide() }
        btnMoveLeft.setOnClickListener { moveSlide(-1) }
        btnMoveRight.setOnClickListener { moveSlide(1) }
        btnInsertImage.setOnClickListener { chooseImage.launch("image/*") }
        btnRemoveImage.setOnClickListener { removeSlideImage() }
        btnBackground.setOnClickListener { cycleBackground() }
        btnPresent.setOnClickListener { showPresentation() }
        btnSave.setOnClickListener {
            saveCurrentFields()
            val uri = currentUri
            if (uri == null) createPptx.launch(suggestedName("pptx")) else savePptx(uri, false)
        }
        btnExportPdf.setOnClickListener {
            saveCurrentFields()
            createPdf.launch(suggestedName("pdf"))
        }
    }

    private fun setupTextWatchers() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!updating) {
                    saveCurrentFields()
                    updatePreviewText()
                    renderThumbnails()
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        binding.inputTitle.addTextChangedListener(watcher)
        binding.inputBody.addTextChangedListener(watcher)
    }

    private fun setupCanvasGestures() {
        makeDraggable(binding.previewTitle, ObjectType.TITLE)
        makeDraggable(binding.previewBody, ObjectType.BODY)
        makeDraggable(binding.imageObjectContainer, ObjectType.IMAGE)
        binding.imageResizeHandle.setOnTouchListener { _, event ->
            val canvas = binding.slideCanvas
            val container = binding.imageObjectContainer
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    resizeStartW = container.width
                    resizeStartH = container.height
                    dragStartRawX = event.rawX
                    dragStartRawY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - dragStartRawX).toInt()
                    val dy = (event.rawY - dragStartRawY).toInt()
                    val maxW = (canvas.width - container.x).toInt().coerceAtLeast(70.dp)
                    val maxH = (canvas.height - container.y).toInt().coerceAtLeast(60.dp)
                    val width = (resizeStartW + dx).coerceIn(70.dp, maxW)
                    val height = (resizeStartH + dy).coerceIn(60.dp, maxH)
                    container.layoutParams = (container.layoutParams as FrameLayout.LayoutParams).apply {
                        this.width = width
                        this.height = height
                    }
                    updateObjectRect(ObjectType.IMAGE, container)
                    true
                }
                else -> false
            }
        }
    }

    private fun makeDraggable(view: View, type: ObjectType) {
        view.setOnTouchListener { _, event ->
            val canvas = binding.slideCanvas
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartRawX = event.rawX
                    dragStartRawY = event.rawY
                    dragStartX = view.x
                    dragStartY = view.y
                    view.bringToFront()
                    if (type == ObjectType.IMAGE) binding.imageResizeHandle.bringToFront()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val x = (dragStartX + event.rawX - dragStartRawX).coerceIn(0f, max(0f, canvas.width - view.width.toFloat()))
                    val y = (dragStartY + event.rawY - dragStartRawY).coerceIn(0f, max(0f, canvas.height - view.height.toFloat()))
                    view.x = x
                    view.y = y
                    updateObjectRect(type, view)
                    true
                }
                else -> false
            }
        }
    }

    private fun updateObjectRect(type: ObjectType, view: View) {
        val canvas = binding.slideCanvas
        if (canvas.width <= 0 || canvas.height <= 0 || currentIndex !in slides.indices) return
        val slide = slides[currentIndex]
        val x = (view.x / canvas.width).coerceIn(0f, 1f)
        val y = (view.y / canvas.height).coerceIn(0f, 1f)
        val w = (view.width.toFloat() / canvas.width).coerceIn(0.05f, 1f)
        val h = (view.height.toFloat() / canvas.height).coerceIn(0.05f, 1f)
        when (type) {
            ObjectType.TITLE -> { slide.titleX = x; slide.titleY = y; slide.titleW = w; slide.titleH = h }
            ObjectType.BODY -> { slide.bodyX = x; slide.bodyY = y; slide.bodyW = w; slide.bodyH = h }
            ObjectType.IMAGE -> { slide.imageX = x; slide.imageY = y; slide.imageW = w; slide.imageH = h }
        }
    }

    private fun addSlide() {
        saveCurrentFields()
        slides.add(currentIndex + 1, GeoSlide("Nueva diapositiva", ""))
        currentIndex++
        renderCurrent()
    }

    private fun deleteSlide() {
        saveCurrentFields()
        if (slides.size == 1) {
            slides[0] = GeoSlide()
            currentIndex = 0
        } else {
            slides.removeAt(currentIndex)
            currentIndex = currentIndex.coerceAtMost(slides.lastIndex)
        }
        renderCurrent()
    }

    private fun duplicateSlide() {
        saveCurrentFields()
        val source = slides[currentIndex]
        slides.add(currentIndex + 1, source.copy())
        currentIndex++
        renderCurrent()
    }

    private fun moveSlide(delta: Int) {
        saveCurrentFields()
        val target = currentIndex + delta
        if (target !in slides.indices) return
        val item = slides.removeAt(currentIndex)
        slides.add(target, item)
        currentIndex = target
        renderCurrent()
    }

    private fun moveTo(index: Int) {
        if (index !in slides.indices) return
        saveCurrentFields()
        currentIndex = index
        renderCurrent()
    }

    private fun saveCurrentFields() {
        if (updating || currentIndex !in slides.indices) return
        slides[currentIndex].title = binding.inputTitle.text?.toString().orEmpty()
        slides[currentIndex].body = binding.inputBody.text?.toString().orEmpty()
    }

    private fun renderCurrent() {
        if (currentIndex !in slides.indices) currentIndex = 0
        val slide = slides[currentIndex]
        updating = true
        binding.inputTitle.setText(slide.title)
        binding.inputBody.setText(slide.body)
        binding.tvSlideCounter.text = "Diapositiva ${currentIndex + 1} de ${slides.size}"
        binding.btnDeleteSlide.text = if (slides.size == 1) "Limpiar" else "Eliminar"
        binding.btnMoveLeft.isEnabled = currentIndex > 0
        binding.btnMoveRight.isEnabled = currentIndex < slides.lastIndex
        binding.btnRemoveImage.isEnabled = !slide.imagePath.isNullOrBlank()
        updating = false
        updatePreviewText()
        renderSlideAppearance()
        renderThumbnails()
    }

    private fun updatePreviewText() {
        val slide = slides.getOrNull(currentIndex) ?: return
        binding.previewTitle.text = binding.inputTitle.text?.toString()?.ifBlank { "Sin título" }
        binding.previewBody.text = binding.inputBody.text?.toString().orEmpty()
        val dark = ColorUtils.calculateLuminance(slide.backgroundColor) < 0.45
        binding.previewTitle.setTextColor(if (dark) Color.WHITE else Color.rgb(22, 32, 51))
        binding.previewBody.setTextColor(if (dark) Color.rgb(229, 231, 235) else Color.rgb(75, 85, 99))
    }

    private fun renderSlideAppearance() {
        val slide = slides[currentIndex]
        binding.slideCanvas.setBackgroundColor(slide.backgroundColor)
        val path = slide.imagePath
        if (!path.isNullOrBlank() && File(path).isFile) {
            binding.slideImage.setImageBitmap(BitmapFactory.decodeFile(path))
            binding.imageObjectContainer.visibility = View.VISIBLE
        } else {
            binding.slideImage.setImageDrawable(null)
            binding.imageObjectContainer.visibility = View.GONE
        }
        binding.slideCanvas.post {
            applyNormalizedRect(binding.previewTitle, slide.titleX, slide.titleY, slide.titleW, slide.titleH)
            applyNormalizedRect(binding.previewBody, slide.bodyX, slide.bodyY, slide.bodyW, slide.bodyH)
            if (binding.imageObjectContainer.visibility == View.VISIBLE) {
                applyNormalizedRect(binding.imageObjectContainer, slide.imageX, slide.imageY, slide.imageW, slide.imageH)
                binding.imageResizeHandle.bringToFront()
            }
        }
    }

    private fun applyNormalizedRect(view: View, x: Float, y: Float, w: Float, h: Float) {
        val canvas = binding.slideCanvas
        if (canvas.width <= 0 || canvas.height <= 0) return
        view.layoutParams = (view.layoutParams as FrameLayout.LayoutParams).apply {
            width = (canvas.width * w).toInt().coerceAtLeast(60.dp)
            height = (canvas.height * h).toInt().coerceAtLeast(42.dp)
        }
        view.x = (canvas.width * x).coerceIn(0f, max(0f, canvas.width - view.layoutParams.width.toFloat()))
        view.y = (canvas.height * y).coerceIn(0f, max(0f, canvas.height - view.layoutParams.height.toFloat()))
    }

    private fun renderThumbnails() {
        binding.thumbnailStrip.removeAllViews()
        slides.forEachIndexed { index, slide ->
            val card = MaterialCardView(this).apply {
                radius = 10.dp.toFloat()
                strokeWidth = if (index == currentIndex) 3.dp else 1.dp
                setStrokeColor(if (index == currentIndex) Color.rgb(37, 99, 235) else Color.rgb(120, 120, 120))
                setCardBackgroundColor(slide.backgroundColor)
                isClickable = true
                setOnClickListener { moveTo(index) }
            }
            val label = TextView(this).apply {
                text = "${index + 1}\n${slide.title.ifBlank { "Sin título" }.take(18)}"
                gravity = Gravity.CENTER
                setPadding(6.dp, 4.dp, 6.dp, 4.dp)
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (ColorUtils.calculateLuminance(slide.backgroundColor) < 0.45) Color.WHITE else Color.rgb(22, 32, 51))
                maxLines = 3
            }
            card.addView(label)
            binding.thumbnailStrip.addView(card, LinearLayout.LayoutParams(108.dp, 70.dp).apply { marginEnd = 8.dp })
        }
    }

    private fun importSlideImage(uri: Uri) {
        Thread {
            runCatching {
                val bitmap = PdfExporter.loadBitmap(this, uri)
                val directory = File(cacheDir, "presentation_images").apply { mkdirs() }
                val file = File(directory, "slide_${System.currentTimeMillis()}.png")
                file.outputStream().use { output -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, output) }
                bitmap.recycle()
                file.absolutePath
            }.onSuccess { path ->
                runOnUiThread {
                    val slide = slides[currentIndex]
                    slide.imagePath = path
                    slide.imageX = 0.55f
                    slide.imageY = 0.28f
                    slide.imageW = 0.38f
                    slide.imageH = 0.55f
                    renderCurrent()
                }
            }.onFailure { runOnUiThread { toast("No se pudo insertar la imagen: ${it.message}") } }
        }.start()
    }

    private fun removeSlideImage() {
        slides[currentIndex].imagePath = null
        renderCurrent()
    }

    private fun cycleBackground() {
        val colors = intArrayOf(
            Color.WHITE,
            Color.rgb(239, 246, 255),
            Color.rgb(254, 249, 195),
            Color.rgb(236, 253, 245),
            Color.rgb(30, 41, 59),
            Color.rgb(88, 28, 135),
            Color.rgb(127, 29, 29)
        )
        val slide = slides[currentIndex]
        val index = colors.indexOf(slide.backgroundColor)
        slide.backgroundColor = colors[((index + 1) % colors.size)]
        renderCurrent()
    }

    private fun showPresentation() {
        saveCurrentFields()
        var index = currentIndex
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val canvas = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val counter = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(8.dp, 8.dp, 8.dp, 12.dp)
        }
        root.addView(canvas)
        root.addView(counter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(root)

        fun render() {
            canvas.removeAllViews()
            val slide = slides[index]
            canvas.setBackgroundColor(slide.backgroundColor)
            val dark = ColorUtils.calculateLuminance(slide.backgroundColor) < 0.45
            val title = TextView(this).apply {
                text = slide.title.ifBlank { "Sin título" }
                gravity = Gravity.CENTER
                textSize = 30f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (dark) Color.WHITE else Color.rgb(22, 32, 51))
            }
            val body = TextView(this).apply {
                text = slide.body
                gravity = Gravity.CENTER
                textSize = 19f
                setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY)
            }
            canvas.addView(title)
            canvas.addView(body)
            val imagePath = slide.imagePath
            val image = if (!imagePath.isNullOrBlank() && File(imagePath).isFile) ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(imagePath))
                scaleType = ImageView.ScaleType.FIT_CENTER
                canvas.addView(this)
            } else null
            canvas.post {
                applyNormalizedRectInCanvas(canvas, title, slide.titleX, slide.titleY, slide.titleW, slide.titleH)
                applyNormalizedRectInCanvas(canvas, body, slide.bodyX, slide.bodyY, slide.bodyW, slide.bodyH)
                image?.let { applyNormalizedRectInCanvas(canvas, it, slide.imageX, slide.imageY, slide.imageW, slide.imageH) }
            }
            counter.text = "${index + 1} / ${slides.size} · toca para avanzar · mantén pulsado para cerrar"
        }
        canvas.setOnClickListener {
            if (index < slides.lastIndex) { index++; render() } else dialog.dismiss()
        }
        canvas.setOnLongClickListener { dialog.dismiss(); true }
        render()
        dialog.show()
    }

    private fun applyNormalizedRectInCanvas(canvas: FrameLayout, view: View, x: Float, y: Float, w: Float, h: Float) {
        view.layoutParams = FrameLayout.LayoutParams(
            (canvas.width * w).toInt().coerceAtLeast(80.dp),
            (canvas.height * h).toInt().coerceAtLeast(50.dp)
        )
        view.x = canvas.width * x
        view.y = canvas.height * y
    }

    private fun loadFile(uri: Uri) {
        Thread {
            runCatching { OpenXmlPptx.read(this, uri) }
                .onSuccess { loaded ->
                    runOnUiThread {
                        if (loaded.isNotEmpty()) {
                            slides.clear()
                            slides.addAll(loaded)
                            currentIndex = pendingSlideIndex.coerceIn(0, slides.lastIndex)
                            renderCurrent()
                        }
                    }
                }
                .onFailure { error -> runOnUiThread { toast("No se pudo abrir: ${error.message}") } }
        }.start()
    }

    private fun savePptx(uri: Uri, updateCurrent: Boolean) {
        val snapshot = slides.map { it.copy() }
        Thread {
            runCatching { OpenXmlPptx.write(this, uri, snapshot) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        toast("Presentación guardada · ${UriUtils.formatSize(UriUtils.size(this, uri))}")
                    }
                }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val snapshot = slides.map { it.copy() }
        Thread {
            runCatching { PdfExporter.slidesToPdf(this, uri, snapshot) }
                .onSuccess { runOnUiThread { toast("PDF creado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }


    override fun onPause() {
        super.onPause()
        if (disableAutoResumeOnExit || slides.isEmpty()) {
            resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
            return
        }
        saveCurrentFields()
        runCatching {
            val directory = File(cacheDir, "resume").apply { mkdirs() }
            val file = File(directory, "presentation_session.pptx")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            OpenXmlPptx.write(this, uri, slides.map { it.copy() })
            resumePrefs.edit()
                .putBoolean(ResumeSession.AUTO_RESUME, true)
                .putString(ResumeSession.LAST_SCREEN, ResumeSession.SCREEN_PRESENTATION)
                .putString(ResumeSession.PRESENTATION_SESSION_URI, uri.toString())
                .putInt(ResumeSession.SLIDE_INDEX, currentIndex)
                .apply()
        }
    }

    private fun disableResumeAndFinish() {
        disableAutoResumeOnExit = true
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
        finish()
    }

    private fun suggestedName(extension: String): String {
        val base = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${base?.takeIf { it.isNotBlank() } ?: "Presentación Geo Office"}.$extension"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
    private enum class ObjectType { TITLE, BODY, IMAGE }
}
