package com.geooffice.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object PdfOps {

    enum class CompressionProfile(
        val label: String,
        val description: String,
        val maxDimension: Int,
        val jpegQuality: Float,
        val estimateRatio: Double
    ) {
        MINIMUM(
            "Mínimo peso",
            "Máxima compresión. Ideal para documentos y envío por WhatsApp.",
            1100,
            0.42f,
            0.12
        ),
        BALANCED(
            "Equilibrado",
            "Texto claro y tamaño reducido.",
            1600,
            0.68f,
            0.28
        ),
        HIGH(
            "Alta calidad",
            "Conserva más detalle y no limita la cantidad de imágenes.",
            2400,
            0.88f,
            0.60
        ),
        ORIGINAL(
            "Calidad original",
            "Mantiene la mayor resolución posible. El archivo puede ser grande.",
            3200,
            0.96f,
            0.95
        )
    }

    fun estimateOutputBytes(originalBytes: Long, itemCount: Int, profile: CompressionProfile): Long {
        val count = itemCount.coerceAtLeast(1)
        if (originalBytes <= 0L) {
            val fallbackPerItem = when (profile) {
                CompressionProfile.MINIMUM -> 260_000L
                CompressionProfile.BALANCED -> 620_000L
                CompressionProfile.HIGH -> 1_500_000L
                CompressionProfile.ORIGINAL -> 3_500_000L
            }
            return fallbackPerItem * count + count * 8_000L
        }
        val estimated = (originalBytes * profile.estimateRatio).toLong()
        val minimumUseful = when (profile) {
            CompressionProfile.MINIMUM -> 70_000L
            CompressionProfile.BALANCED -> 140_000L
            CompressionProfile.HIGH -> 280_000L
            CompressionProfile.ORIGINAL -> 500_000L
        } * count
        return max(estimated, minimumUseful) + count * 8_000L
    }

    fun imagesToProtectedPdf(
        context: Context,
        images: List<Uri>,
        output: Uri,
        userPassword: String,
        profile: CompressionProfile = CompressionProfile.MINIMUM
    ): Int {
        require(images.isNotEmpty()) { "Selecciona al menos una imagen" }
        if (userPassword.isNotBlank()) validatePassword(userPassword)

        PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { document ->
            images.forEach { imageUri ->
                val bitmap = loadBitmapScaled(context, imageUri, profile.maxDimension)
                try {
                    val landscape = bitmap.width > bitmap.height
                    val page = if (landscape) {
                        PDPage(PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width))
                    } else {
                        PDPage(PDRectangle.A4)
                    }
                    document.addPage(page)
                    val image = JPEGFactory.createFromImage(document, bitmap, profile.jpegQuality, 150)
                    val margin = 18f
                    val availableWidth = page.mediaBox.width - margin * 2f
                    val availableHeight = page.mediaBox.height - margin * 2f
                    val scale = min(availableWidth / image.width, availableHeight / image.height)
                    val drawWidth = image.width * scale
                    val drawHeight = image.height * scale
                    val x = (page.mediaBox.width - drawWidth) / 2f
                    val y = (page.mediaBox.height - drawHeight) / 2f
                    PDPageContentStream(document, page).use { content ->
                        content.drawImage(image, x, y, drawWidth, drawHeight)
                    }
                } finally {
                    bitmap.recycle()
                }
            }
            if (userPassword.isNotBlank()) applyPasswordProtection(document, userPassword)
            context.contentResolver.openOutputStream(output, "w").use { destination ->
                requireNotNull(destination) { "No se pudo crear el PDF protegido" }
                document.save(destination)
            }
        }
        return images.size
    }

    fun protect(context: Context, input: Uri, output: Uri, userPassword: String) {
        validatePassword(userPassword)
        context.contentResolver.openInputStream(input).use { source ->
            requireNotNull(source) { "No se pudo abrir el PDF" }
            PDDocument.load(source).use { document ->
                applyPasswordProtection(document, userPassword)
                context.contentResolver.openOutputStream(output, "w").use { destination ->
                    requireNotNull(destination) { "No se pudo crear el PDF protegido" }
                    document.save(destination)
                }
            }
        }
    }

    private fun applyPasswordProtection(document: PDDocument, userPassword: String) {
        val permissions = AccessPermission()
        val ownerPassword = UUID.randomUUID().toString() + userPassword
        val policy = StandardProtectionPolicy(ownerPassword, userPassword, permissions)
        policy.setEncryptionKeyLength(256)
        policy.setPreferAES(true)
        document.protect(policy)
    }

    private fun validatePassword(password: String) {
        require(password.length >= 4) { "La contraseña debe tener al menos 4 caracteres" }
        require(password.length <= 127) { "La contraseña es demasiado larga" }
    }

    fun merge(context: Context, inputs: List<Uri>, output: Uri) {
        require(inputs.size >= 2) { "Selecciona al menos dos PDF" }
        val streams = inputs.map { uri ->
            context.contentResolver.openInputStream(uri) ?: error("No se pudo abrir un PDF")
        }
        try {
            context.contentResolver.openOutputStream(output, "w").use { out ->
                requireNotNull(out) { "No se pudo crear el PDF" }
                val merger = PDFMergerUtility()
                streams.forEach { merger.addSource(it) }
                merger.destinationStream = out
                merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
            }
        } finally {
            streams.forEach { runCatching { it.close() } }
        }
    }

    fun split(context: Context, input: Uri, outputTree: Uri): Int {
        val directory = DocumentFile.fromTreeUri(context, outputTree) ?: error("Carpeta no válida")
        context.contentResolver.openInputStream(input).use { stream ->
            requireNotNull(stream) { "No se pudo abrir el PDF" }
            PDDocument.load(stream).use { source ->
                for (index in 0 until source.numberOfPages) {
                    val file = directory.createFile("application/pdf", "GeoOffice_pagina_${index + 1}.pdf")
                        ?: error("No se pudo crear la página ${index + 1}")
                    context.contentResolver.openOutputStream(file.uri, "w").use { out ->
                        requireNotNull(out)
                        PDDocument().use { target ->
                            target.importPage(source.getPage(index))
                            target.save(out)
                        }
                    }
                }
                return source.numberOfPages
            }
        }
    }

    fun toImages(context: Context, input: Uri, outputTree: Uri): Int {
        val directory = DocumentFile.fromTreeUri(context, outputTree) ?: error("Carpeta no válida")
        context.contentResolver.openFileDescriptor(input, "r").use { descriptor ->
            requireNotNull(descriptor) { "No se pudo abrir el PDF" }
            PdfRenderer(descriptor).use { renderer ->
                for (index in 0 until renderer.pageCount) {
                    renderer.openPage(index).use { page ->
                        val scale = 2f
                        val bitmap = Bitmap.createBitmap(
                            (page.width * scale).toInt().coerceAtLeast(1),
                            (page.height * scale).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val file = directory.createFile("image/png", "GeoOffice_pagina_${index + 1}.png")
                            ?: error("No se pudo crear la imagen ${index + 1}")
                        context.contentResolver.openOutputStream(file.uri, "w").use { out ->
                            requireNotNull(out)
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        }
                        bitmap.recycle()
                    }
                }
                return renderer.pageCount
            }
        }
    }

    fun compressAsImages(
        context: Context,
        input: Uri,
        output: Uri,
        profile: CompressionProfile = CompressionProfile.MINIMUM
    ): Int {
        val tempFile = File.createTempFile("geo_office_compressed_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openFileDescriptor(input, "r").use { descriptor ->
                requireNotNull(descriptor) { "No se pudo abrir el PDF" }
                PdfRenderer(descriptor).use { renderer ->
                    PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { document ->
                        for (index in 0 until renderer.pageCount) {
                            renderer.openPage(index).use { sourcePage ->
                                val renderScale = max(1f, profile.maxDimension.toFloat() / sourcePage.width.coerceAtLeast(1))
                                val bitmapWidth = (sourcePage.width * renderScale).roundToInt().coerceAtLeast(1)
                                val bitmapHeight = (sourcePage.height * renderScale).roundToInt().coerceAtLeast(1)
                                val bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
                                try {
                                    bitmap.eraseColor(Color.WHITE)
                                    sourcePage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val page = PDPage(PDRectangle(sourcePage.width.toFloat(), sourcePage.height.toFloat()))
                                    document.addPage(page)
                                    val image = JPEGFactory.createFromImage(document, bitmap, profile.jpegQuality, 150)
                                    PDPageContentStream(document, page).use { content ->
                                        content.drawImage(image, 0f, 0f, page.mediaBox.width, page.mediaBox.height)
                                    }
                                } finally {
                                    bitmap.recycle()
                                }
                            }
                        }
                        FileOutputStream(tempFile).use { document.save(it) }
                    }
                    context.contentResolver.openOutputStream(output, "w").use { out ->
                        requireNotNull(out) { "No se pudo crear el PDF comprimido" }
                        tempFile.inputStream().use { it.copyTo(out) }
                    }
                    return renderer.pageCount
                }
            }
        } finally {
            tempFile.delete()
        }
    }

    private fun loadBitmapScaled(context: Context, uri: Uri, maxDimension: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la imagen" }
            BitmapFactory.decodeStream(input, null, bounds)
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Imagen no compatible" }

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension * 2) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la imagen" }
            BitmapFactory.decodeStream(input, null, options) ?: error("No se pudo leer la imagen")
        }
        val largest = max(decoded.width, decoded.height)
        if (largest <= maxDimension) return decoded

        val scale = maxDimension.toFloat() / largest.toFloat()
        val targetWidth = (decoded.width * scale).roundToInt().coerceAtLeast(1)
        val targetHeight = (decoded.height * scale).roundToInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(decoded, targetWidth, targetHeight, true)
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }
}
