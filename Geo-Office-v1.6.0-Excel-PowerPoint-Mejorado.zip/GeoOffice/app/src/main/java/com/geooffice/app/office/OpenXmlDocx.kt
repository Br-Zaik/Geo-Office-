package com.geooffice.app.office

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.text.style.TypefaceSpan
import android.util.Xml
import com.geooffice.app.editor.GeoImageDrawable
import com.geooffice.app.editor.GeoImageSpan
import com.geooffice.app.util.XmlUtils
import com.geooffice.app.util.ZipUtils
import org.xmlpull.v1.XmlPullParser
import androidx.core.content.FileProvider
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.IdentityHashMap
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

object OpenXmlDocx {
    private const val W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    fun write(context: Context, uri: Uri, text: CharSequence) {
        val spanned = if (text is Spanned) text else SpannableStringBuilder(text)
        val images = collectImages(context, spanned)
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el documento" }
            ZipOutputStream(output).use { zip ->
                ZipUtils.writeEntry(zip, "[Content_Types].xml", contentTypes(images.isNotEmpty()))
                ZipUtils.writeEntry(zip, "_rels/.rels", rootRels())
                ZipUtils.writeEntry(zip, "docProps/core.xml", coreProps())
                ZipUtils.writeEntry(zip, "docProps/app.xml", appProps())
                ZipUtils.writeEntry(zip, "word/document.xml", documentXml(context, spanned, images))
                ZipUtils.writeEntry(zip, "word/styles.xml", stylesXml())
                ZipUtils.writeEntry(zip, "word/_rels/document.xml.rels", documentRels(images.values.toList()))
                images.values.forEach { image ->
                    ZipUtils.writeEntry(zip, "word/media/${image.fileName}", image.bytes)
                }
            }
        }
    }

    fun read(context: Context, uri: Uri): CharSequence {
        val entries = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el documento" }
            ZipUtils.readEntries(input)
        }
        val xml = entries["word/document.xml"] ?: return ""
        val relationshipTargets = parseImageRelationships(entries["word/_rels/document.xml.rels"])
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xml), "UTF-8")
        val result = SpannableStringBuilder()

        var event = parser.eventType
        var inText = false
        var paragraphStart = 0
        var runStart = 0
        var paragraphAlignment: Layout.Alignment? = null
        var paragraphIndentTwips = 0
        var bold = false
        var italic = false
        var underline = false
        var strike = false
        var foreground: Int? = null
        var background: Int? = null
        var sizeSp: Int? = null
        var fontFamily: String? = null
        var drawingRelId: String? = null
        var drawingWidthPx = 320
        var drawingHeightPx = 220

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name.substringAfter(':')) {
                        "p" -> {
                            paragraphStart = result.length
                            paragraphAlignment = null
                            paragraphIndentTwips = 0
                        }
                        "r" -> {
                            runStart = result.length
                            bold = false
                            italic = false
                            underline = false
                            strike = false
                            foreground = null
                            background = null
                            sizeSp = null
                            fontFamily = null
                        }
                        "t" -> inText = true
                        "tab" -> result.append('\t')
                        "br" -> {
                            val type = parser.attr("type")
                            result.append(if (type == "page") '\u000C' else '\n')
                        }
                        "b" -> bold = parser.attr("val") != "0"
                        "i" -> italic = parser.attr("val") != "0"
                        "u" -> underline = parser.attr("val") != "none"
                        "strike" -> strike = parser.attr("val") != "0"
                        "color" -> foreground = parseColor(parser.attr("val"))
                        "shd" -> background = parseColor(parser.attr("fill"))
                        "sz" -> sizeSp = parser.attr("val")?.toIntOrNull()?.div(2)
                        "rFonts" -> fontFamily = when (parser.attr("ascii")?.lowercase()) {
                            "times new roman", "serif" -> "serif"
                            "courier new", "monospace" -> "monospace"
                            else -> "sans"
                        }
                        "drawing" -> {
                            drawingRelId = null
                            drawingWidthPx = 320
                            drawingHeightPx = 220
                        }
                        "blip" -> drawingRelId = parser.attr("embed")
                        "extent" -> {
                            drawingWidthPx = ((parser.attr("cx")?.toLongOrNull() ?: 3048000L) / 9525L).toInt().coerceAtLeast(48)
                            drawingHeightPx = ((parser.attr("cy")?.toLongOrNull() ?: 2095500L) / 9525L).toInt().coerceAtLeast(48)
                        }
                        "jc" -> paragraphAlignment = when (parser.attr("val")) {
                            "center" -> Layout.Alignment.ALIGN_CENTER
                            "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                            else -> Layout.Alignment.ALIGN_NORMAL
                        }
                        "ind" -> paragraphIndentTwips = parser.attr("left")?.toIntOrNull() ?: 0
                    }
                }
                XmlPullParser.TEXT -> if (inText) result.append(parser.text)
                XmlPullParser.END_TAG -> {
                    when (parser.name.substringAfter(':')) {
                        "t" -> inText = false
                        "drawing" -> {
                            val relId = drawingRelId
                            val target = relId?.let { relationshipTargets[it] }
                            val key = target?.let { if (it.startsWith("word/")) it else "word/${it.removePrefix("/")}" }
                            val bytes = key?.let { entries[it] }
                            if (bytes != null) {
                                runCatching {
                                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Imagen inválida")
                                    val directory = File(context.cacheDir, "docx_images").apply { mkdirs() }
                                    val extension = key.substringAfterLast('.', "png")
                                    val file = File(directory, "docx_${System.nanoTime()}.$extension")
                                    FileOutputStream(file).use { it.write(bytes) }
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val maxWidth = (context.resources.displayMetrics.widthPixels * 0.82f).roundToInt().coerceAtLeast(160)
                                    val scale = (maxWidth.toFloat() / drawingWidthPx.coerceAtLeast(1)).coerceAtMost(1f)
                                    val displayWidth = (drawingWidthPx * scale).roundToInt().coerceAtLeast(48)
                                    val displayHeight = (drawingHeightPx * scale).roundToInt().coerceAtLeast(48)
                                    val start = result.length
                                    result.append('￼')
                                    val drawable = GeoImageDrawable(bitmap).apply {
                                        setBounds(0, 0, displayWidth, displayHeight)
                                    }
                                    result.setSpan(
                                        GeoImageSpan(drawable, uri.toString(), displayWidth, displayHeight),
                                        start,
                                        start + 1,
                                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                    )
                                }
                            }
                            drawingRelId = null
                        }
                        "r" -> {
                            val end = result.length
                            if (end > runStart) {
                                if (bold) result.setSpan(StyleSpan(android.graphics.Typeface.BOLD), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                if (italic) result.setSpan(StyleSpan(android.graphics.Typeface.ITALIC), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                if (underline) result.setSpan(UnderlineSpan(), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                if (strike) result.setSpan(StrikethroughSpan(), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                foreground?.let { result.setSpan(ForegroundColorSpan(it), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                                background?.let { result.setSpan(BackgroundColorSpan(it), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                                sizeSp?.takeIf { it in 6..96 }?.let { result.setSpan(AbsoluteSizeSpan(it, true), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                                fontFamily?.let { result.setSpan(TypefaceSpan(it), runStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                            }
                        }
                        "p" -> {
                            val end = result.length
                            if (end > paragraphStart) {
                                paragraphAlignment?.let { result.setSpan(AlignmentSpan.Standard(it), paragraphStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                                if (paragraphIndentTwips > 0) {
                                    val dp = paragraphIndentTwips / 15f
                                    val px = (dp * context.resources.displayMetrics.density).roundToInt()
                                    result.setSpan(LeadingMarginSpan.Standard(px, px), paragraphStart, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                }
                            }
                            if (result.isNotEmpty() && result.last() != '\n') result.append('\n')
                        }
                    }
                }
            }
            event = parser.next()
        }
        while (result.isNotEmpty() && result.last() == '\n') result.delete(result.length - 1, result.length)
        return result
    }

    private fun parseImageRelationships(bytes: ByteArray?): Map<String, String> {
        if (bytes == null) return emptyMap()
        val xml = bytes.toString(Charsets.UTF_8)
        val pattern = Regex("<Relationship[^>]*Id=\"([^\"]+)\"[^>]*Target=\"([^\"]+)\"[^>]*/?>")
        return pattern.findAll(xml).associate { match ->
            match.groupValues[1] to match.groupValues[2]
        }
    }

    private fun collectImages(context: Context, text: Spanned): IdentityHashMap<GeoImageSpan, ImagePart> {
        val map = IdentityHashMap<GeoImageSpan, ImagePart>()
        val spans = text.getSpans(0, text.length, GeoImageSpan::class.java)
        spans.forEachIndexed { index, span ->
            runCatching {
                val bitmap = context.contentResolver.openInputStream(Uri.parse(span.sourceUri)).use { input ->
                    requireNotNull(input) { "No se pudo abrir imagen" }
                    BitmapFactory.decodeStream(input) ?: error("Imagen inválida")
                }
                val bytes = ByteArrayOutputStream().use { output ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 95, output)
                    output.toByteArray()
                }
                map[span] = ImagePart(
                    relId = "rIdImg${index + 1}",
                    fileName = "image${index + 1}.png",
                    bytes = bytes,
                    widthPx = span.displayWidthPx,
                    heightPx = span.displayHeightPx
                )
            }
        }
        return map
    }

    private fun documentXml(context: Context, text: Spanned, images: IdentityHashMap<GeoImageSpan, ImagePart>): String {
        val body = buildString {
            var paragraphStart = 0
            var index = 0
            while (index <= text.length) {
                if (index == text.length || text[index] == '\n') {
                    append(paragraphXml(context, text, paragraphStart, index, images))
                    paragraphStart = index + 1
                }
                index++
            }
            append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>$body</w:body></w:document>"""
    }

    private fun paragraphXml(context: Context, text: Spanned, start: Int, end: Int, images: IdentityHashMap<GeoImageSpan, ImagePart>): String {
        val alignment = text.getSpans(start, end.coerceAtLeast(start), AlignmentSpan::class.java).lastOrNull()?.alignment
        val indentPx = text.getSpans(start, end.coerceAtLeast(start), LeadingMarginSpan::class.java).maxOfOrNull { it.getLeadingMargin(true) } ?: 0
        val indentTwips = ((indentPx / context.resources.displayMetrics.density) * 15f).roundToInt()
        val pPr = buildString {
            if (alignment != null || indentTwips > 0) {
                append("<w:pPr>")
                when (alignment) {
                    Layout.Alignment.ALIGN_CENTER -> append("<w:jc w:val=\"center\"/>")
                    Layout.Alignment.ALIGN_OPPOSITE -> append("<w:jc w:val=\"right\"/>")
                    else -> if (alignment != null) append("<w:jc w:val=\"left\"/>")
                }
                if (indentTwips > 0) append("<w:ind w:left=\"$indentTwips\"/>")
                append("</w:pPr>")
            }
        }
        return "<w:p>$pPr${runsXml(text, start, end, images)}</w:p>"
    }

    private fun runsXml(text: Spanned, start: Int, end: Int, images: IdentityHashMap<GeoImageSpan, ImagePart>): String = buildString {
        var position = start
        while (position < end) {
            if (text[position] == '\uFFFC') {
                val imageSpan = text.getSpans(position, position + 1, GeoImageSpan::class.java).firstOrNull()
                val image = imageSpan?.let { images[it] }
                if (image != null) append(imageRunXml(image, position + 1))
                position++
                continue
            }
            var next = text.nextSpanTransition(position, end, Any::class.java)
            val nextImage = (position until end).firstOrNull { text[it] == '\uFFFC' }
            if (nextImage != null && nextImage < next) next = nextImage
            if (next <= position) next = position + 1
            val segment = text.subSequence(position, next).toString()
            append(textRunXml(text, position, next, segment))
            position = next
        }
        if (start == end) append("<w:r><w:t></w:t></w:r>")
    }

    private fun textRunXml(text: Spanned, start: Int, end: Int, segment: String): String {
        val styles = text.getSpans(start, end, StyleSpan::class.java)
        val bold = styles.any { it.style == android.graphics.Typeface.BOLD || it.style == android.graphics.Typeface.BOLD_ITALIC }
        val italic = styles.any { it.style == android.graphics.Typeface.ITALIC || it.style == android.graphics.Typeface.BOLD_ITALIC }
        val underline = text.getSpans(start, end, UnderlineSpan::class.java).isNotEmpty()
        val strike = text.getSpans(start, end, StrikethroughSpan::class.java).isNotEmpty()
        val foreground = text.getSpans(start, end, ForegroundColorSpan::class.java).lastOrNull()?.foregroundColor
        val background = text.getSpans(start, end, BackgroundColorSpan::class.java).lastOrNull()?.backgroundColor
        val size = text.getSpans(start, end, AbsoluteSizeSpan::class.java).lastOrNull()?.let { if (it.dip) it.size else it.size } ?: 11
        val fontFamily = text.getSpans(start, end, TypefaceSpan::class.java).lastOrNull()?.family
        val docxFont = when (fontFamily) {
            "serif" -> "Times New Roman"
            "monospace" -> "Courier New"
            else -> "Calibri"
        }
        val rPr = buildString {
            append("<w:rPr><w:rFonts w:ascii=\"$docxFont\" w:hAnsi=\"$docxFont\"/>")
            if (bold) append("<w:b/>")
            if (italic) append("<w:i/>")
            if (underline) append("<w:u w:val=\"single\"/>")
            if (strike) append("<w:strike/>")
            foreground?.let { append("<w:color w:val=\"${hexColor(it)}\"/>") }
            background?.let { append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"${hexColor(it)}\"/>") }
            append("<w:sz w:val=\"${size * 2}\"/><w:szCs w:val=\"${size * 2}\"/><w:lang w:val=\"es-PE\"/>")
            append("</w:rPr>")
        }
        return buildString {
            var buffer = StringBuilder()
            fun flush() {
                if (buffer.isNotEmpty()) {
                    append("<w:r>$rPr<w:t xml:space=\"preserve\">${XmlUtils.escape(buffer.toString())}</w:t></w:r>")
                    buffer = StringBuilder()
                }
            }
            segment.forEach { char ->
                when (char) {
                    '\t' -> { flush(); append("<w:r>$rPr<w:tab/></w:r>") }
                    '\u000C' -> { flush(); append("<w:r>$rPr<w:br w:type=\"page\"/></w:r>") }
                    else -> buffer.append(char)
                }
            }
            flush()
        }
    }

    private fun imageRunXml(image: ImagePart, id: Int): String {
        val cx = image.widthPx.coerceAtLeast(1) * 9525L
        val cy = image.heightPx.coerceAtLeast(1) * 9525L
        return """<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$id" name="Imagen $id"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="${image.fileName}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${image.relId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>"""
    }

    private fun contentTypes(hasImages: Boolean) = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
${if (hasImages) "<Default Extension=\"png\" ContentType=\"image/png\"/>" else ""}
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

    private fun documentRels(images: List<ImagePart>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        append("<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>")
        images.forEach { image ->
            append("<Relationship Id=\"${image.relId}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/${image.fileName}\"/>")
        }
        append("</Relationships>")
    }

    private fun coreProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Documento de Geo Office</dc:title><dc:creator>Geo Office</dc:creator><cp:lastModifiedBy>Geo Office</cp:lastModifiedBy></cp:coreProperties>"""

    private fun appProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Geo Office</Application></Properties>"""

    private fun stylesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="es-PE"/></w:rPr></w:rPrDefault><w:pPrDefault/></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style></w:styles>"""

    private fun XmlPullParser.attr(localName: String): String? {
        for (index in 0 until attributeCount) {
            if (getAttributeName(index).substringAfter(':') == localName) return getAttributeValue(index)
        }
        return getAttributeValue(W_NS, localName)
    }

    private fun parseColor(value: String?): Int? {
        if (value.isNullOrBlank() || value.equals("auto", true) || value.length < 6) return null
        return runCatching { Color.parseColor("#${value.takeLast(6)}") }.getOrNull()
    }

    private fun hexColor(color: Int): String = String.format("%06X", color and 0xFFFFFF)

    private data class ImagePart(
        val relId: String,
        val fileName: String,
        val bytes: ByteArray,
        val widthPx: Int,
        val heightPx: Int
    )
}
