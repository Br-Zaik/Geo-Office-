package com.geooffice.app.office

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.util.Xml
import com.geooffice.app.util.XmlUtils
import com.geooffice.app.util.ZipUtils
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.File
import java.util.Locale
import java.util.zip.ZipOutputStream

data class GeoSlide(
    var title: String = "",
    var body: String = "",
    var backgroundColor: Int = Color.WHITE,
    var imagePath: String? = null,
    var imageX: Float = 0.55f,
    var imageY: Float = 0.22f,
    var imageW: Float = 0.38f,
    var imageH: Float = 0.55f,
    var titleX: Float = 0.07f,
    var titleY: Float = 0.08f,
    var titleW: Float = 0.86f,
    var titleH: Float = 0.22f,
    var bodyX: Float = 0.09f,
    var bodyY: Float = 0.34f,
    var bodyW: Float = 0.82f,
    var bodyH: Float = 0.48f
)

object OpenXmlPptx {
    private const val SLIDE_WIDTH = 12192000
    private const val SLIDE_HEIGHT = 6858000

    fun write(context: Context, uri: Uri, slides: List<GeoSlide>) {
        val safeSlides = slides.ifEmpty { listOf(GeoSlide()) }
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear la presentación" }
            ZipOutputStream(output).use { zip ->
                ZipUtils.writeEntry(zip, "[Content_Types].xml", contentTypes(safeSlides.size))
                ZipUtils.writeEntry(zip, "_rels/.rels", rootRels())
                ZipUtils.writeEntry(zip, "docProps/core.xml", coreProps())
                ZipUtils.writeEntry(zip, "docProps/app.xml", appProps(safeSlides.size))
                ZipUtils.writeEntry(zip, "ppt/presentation.xml", presentationXml(safeSlides.size))
                ZipUtils.writeEntry(zip, "ppt/_rels/presentation.xml.rels", presentationRels(safeSlides.size))
                ZipUtils.writeEntry(zip, "ppt/slideMasters/slideMaster1.xml", slideMasterXml())
                ZipUtils.writeEntry(zip, "ppt/slideMasters/_rels/slideMaster1.xml.rels", slideMasterRels())
                ZipUtils.writeEntry(zip, "ppt/slideLayouts/slideLayout1.xml", slideLayoutXml())
                ZipUtils.writeEntry(zip, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", slideLayoutRels())
                ZipUtils.writeEntry(zip, "ppt/theme/theme1.xml", themeXml())
                safeSlides.forEachIndexed { index, slide ->
                    val number = index + 1
                    val imageFile = slide.imagePath?.let(::File)?.takeIf { it.isFile }
                    ZipUtils.writeEntry(zip, "ppt/slides/slide$number.xml", slideXml(slide, imageFile != null))
                    ZipUtils.writeEntry(zip, "ppt/slides/_rels/slide$number.xml.rels", slideRels(number, imageFile != null))
                    if (imageFile != null) {
                        ZipUtils.writeEntry(zip, "ppt/media/image$number.png", imageFile.readBytes())
                    }
                }
            }
        }
    }

    fun read(context: Context, uri: Uri): List<GeoSlide> {
        val entries = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la presentación" }
            ZipUtils.readEntries(input)
        }
        val slideNames = entries.keys
            .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
            .sortedBy { it.substringAfter("slide").substringBefore(".xml").toIntOrNull() ?: Int.MAX_VALUE }
        val cacheDir = File(context.cacheDir, "ppt_images").apply { mkdirs() }
        return slideNames.mapIndexedNotNull { index, name ->
            val bytes = entries[name] ?: return@mapIndexedNotNull null
            val slide = parseSlide(bytes)
            val relName = "ppt/slides/_rels/${name.substringAfterLast('/')}.rels"
            val relBytes = entries[relName]
            val imageTarget = relBytes?.let(::parseImageRelationship)
            if (!imageTarget.isNullOrBlank()) {
                val normalized = normalizeMediaPath(imageTarget)
                entries[normalized]?.let { imageBytes ->
                    val file = File(cacheDir, "slide_${System.currentTimeMillis()}_${index + 1}.png")
                    val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                    if (bitmap != null) {
                        file.outputStream().use { output -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, output) }
                        bitmap.recycle()
                    } else {
                        file.writeBytes(imageBytes)
                    }
                    slide.imagePath = file.absolutePath
                }
            }
            slide
        }
    }

    private fun normalizeMediaPath(target: String): String {
        val clean = target.removePrefix("/")
        return when {
            clean.startsWith("ppt/") -> clean
            clean.startsWith("../") -> "ppt/${clean.removePrefix("../")}" 
            else -> "ppt/slides/$clean"
        }.replace("ppt/slides/../", "ppt/")
    }

    private fun parseImageRelationship(bytes: ByteArray): String? {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') == "Relationship") {
                val type = parser.getAttributeValue(null, "Type").orEmpty()
                if (type.endsWith("/image")) return parser.getAttributeValue(null, "Target")
            }
            event = parser.next()
        }
        return null
    }

    private fun parseSlide(bytes: ByteArray): GeoSlide {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val shapes = mutableListOf<String>()
        val shapeRects = mutableListOf<FloatArray>()
        var event = parser.eventType
        var inShape = false
        var inPic = false
        var inText = false
        var inBackground = false
        var current = StringBuilder()
        var currentOffX = 0L
        var currentOffY = 0L
        var currentCx = 0L
        var currentCy = 0L
        var background = Color.WHITE
        var picRect: FloatArray? = null
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    when (name) {
                        "bg" -> inBackground = true
                        "sp" -> { inShape = true; current = StringBuilder(); currentOffX = 0; currentOffY = 0; currentCx = 0; currentCy = 0 }
                        "pic" -> { inPic = true; currentOffX = 0; currentOffY = 0; currentCx = 0; currentCy = 0 }
                        "t" -> if (inShape) {
                            if (current.isNotEmpty() && current.last() != '\n') current.append('\n')
                            inText = true
                        }
                        "srgbClr" -> if (inBackground) {
                            parser.getAttributeValue(null, "val")?.let { runCatching { background = Color.parseColor("#$it") } }
                        }
                        "off" -> if (inShape || inPic) {
                            currentOffX = parser.getAttributeValue(null, "x")?.toLongOrNull() ?: currentOffX
                            currentOffY = parser.getAttributeValue(null, "y")?.toLongOrNull() ?: currentOffY
                        }
                        "ext" -> if (inShape || inPic) {
                            currentCx = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: currentCx
                            currentCy = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: currentCy
                        }
                    }
                }
                XmlPullParser.TEXT -> if (inText) current.append(parser.text)
                XmlPullParser.END_TAG -> {
                    when (parser.name.substringAfter(':')) {
                        "bg" -> inBackground = false
                        "t" -> inText = false
                        "sp" -> {
                            val text = current.toString().trim()
                            if (text.isNotBlank()) {
                                shapes.add(text)
                                shapeRects.add(normalizedRect(currentOffX, currentOffY, currentCx, currentCy))
                            }
                            inShape = false
                        }
                        "pic" -> {
                            picRect = normalizedRect(currentOffX, currentOffY, currentCx, currentCy)
                            inPic = false
                        }
                    }
                }
            }
            event = parser.next()
        }
        val titleRect = shapeRects.getOrNull(0) ?: floatArrayOf(0.07f, 0.08f, 0.86f, 0.22f)
        val bodyRect = shapeRects.getOrNull(1) ?: floatArrayOf(0.09f, 0.34f, 0.82f, 0.48f)
        val imageRect = picRect ?: floatArrayOf(0.55f, 0.22f, 0.38f, 0.55f)
        return GeoSlide(
            title = shapes.getOrNull(0).orEmpty(),
            body = shapes.drop(1).joinToString("\n"),
            backgroundColor = background,
            imageX = imageRect[0], imageY = imageRect[1], imageW = imageRect[2], imageH = imageRect[3],
            titleX = titleRect[0], titleY = titleRect[1], titleW = titleRect[2], titleH = titleRect[3],
            bodyX = bodyRect[0], bodyY = bodyRect[1], bodyW = bodyRect[2], bodyH = bodyRect[3]
        )
    }

    private fun normalizedRect(x: Long, y: Long, w: Long, h: Long): FloatArray = floatArrayOf(
        (x.toFloat() / SLIDE_WIDTH).coerceIn(0f, 1f),
        (y.toFloat() / SLIDE_HEIGHT).coerceIn(0f, 1f),
        (w.toFloat() / SLIDE_WIDTH).coerceIn(0.05f, 1f),
        (h.toFloat() / SLIDE_HEIGHT).coerceIn(0.05f, 1f)
    )

    private fun contentTypes(count: Int) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>""")
        for (i in 1..count) append("<Override PartName=\"/ppt/slides/slide$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
        append("""<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>""")
    }

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>"""

    private fun presentationXml(count: Int) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>""")
        for (i in 1..count) append("<p:sldId id=\"${255 + i}\" r:id=\"rId${i + 1}\"/>")
        append("""</p:sldIdLst><p:sldSz cx="$SLIDE_WIDTH" cy="$SLIDE_HEIGHT" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/><p:defaultTextStyle/></p:presentation>""")
    }

    private fun presentationRels(count: Int) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>""")
        for (i in 1..count) append("<Relationship Id=\"rId${i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide$i.xml\"/>")
        append("</Relationships>")
    }

    private fun slideXml(slide: GeoSlide, hasImage: Boolean): String {
        val bg = colorHex(slide.backgroundColor)
        val titleColor = if (isDark(slide.backgroundColor)) "FFFFFF" else "162033"
        val bodyColor = if (isDark(slide.backgroundColor)) "E5E7EB" else "4B5563"
        val image = if (hasImage) pictureShape(slide) else ""
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="$bg"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${textShape(2, "Title", slide.titleX, slide.titleY, slide.titleW, slide.titleH, slide.title, 3200, titleColor, true)}${textShape(3, "Content", slide.bodyX, slide.bodyY, slide.bodyW, slide.bodyH, slide.body, 2000, bodyColor, false)}$image</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"""
    }

    private fun textShape(id: Int, name: String, x: Float, y: Float, w: Float, h: Float, text: String, size: Int, color: String, bold: Boolean): String {
        val paragraphs = (text.lines().ifEmpty { listOf("") }).joinToString("") { line ->
            "<a:p><a:r><a:rPr lang=\"es-PE\" sz=\"$size\" b=\"${if (bold) 1 else 0}\"><a:solidFill><a:srgbClr val=\"$color\"/></a:solidFill><a:latin typeface=\"Calibri\"/></a:rPr><a:t>${XmlUtils.escape(line)}</a:t></a:r><a:endParaRPr lang=\"es-PE\" sz=\"$size\"/></a:p>"
        }
        return """<p:sp><p:nvSpPr><p:cNvPr id="$id" name="$name"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${(x * SLIDE_WIDTH).toLong()}" y="${(y * SLIDE_HEIGHT).toLong()}"/><a:ext cx="${(w * SLIDE_WIDTH).toLong()}" cy="${(h * SLIDE_HEIGHT).toLong()}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="ctr"><a:spAutoFit/></a:bodyPr><a:lstStyle/>$paragraphs</p:txBody></p:sp>"""
    }

    private fun pictureShape(slide: GeoSlide): String = """<p:pic><p:nvPicPr><p:cNvPr id="4" name="Imagen 1"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${(slide.imageX * SLIDE_WIDTH).toLong()}" y="${(slide.imageY * SLIDE_HEIGHT).toLong()}"/><a:ext cx="${(slide.imageW * SLIDE_WIDTH).toLong()}" cy="${(slide.imageH * SLIDE_HEIGHT).toLong()}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>"""

    private fun slideRels(number: Int, hasImage: Boolean) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>""")
        if (hasImage) append("<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/image$number.png\"/>")
        append("</Relationships>")
    }

    private fun colorHex(color: Int): String = String.format(Locale.US, "%02X%02X%02X", Color.red(color), Color.green(color), Color.blue(color))
    private fun isDark(color: Int): Boolean = (Color.red(color) * 0.299 + Color.green(color) * 0.587 + Color.blue(color) * 0.114) < 145

    private fun slideMasterXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/><p:sldLayoutIdLst><p:sldLayoutId id="1" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>"""
    private fun slideMasterRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>"""
    private fun slideLayoutXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"""
    private fun slideLayoutRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>"""
    private fun themeXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Geo Office"><a:themeElements><a:clrScheme name="Geo"><a:dk1><a:srgbClr val="162033"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1D4ED8"/></a:dk2><a:lt2><a:srgbClr val="F7F8FC"/></a:lt2><a:accent1><a:srgbClr val="2563EB"/></a:accent1><a:accent2><a:srgbClr val="EF4444"/></a:accent2><a:accent3><a:srgbClr val="16A34A"/></a:accent3><a:accent4><a:srgbClr val="F59E0B"/></a:accent4><a:accent5><a:srgbClr val="7C3AED"/></a:accent5><a:accent6><a:srgbClr val="0891B2"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="Geo"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Geo"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>"""
    private fun coreProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Presentación de Geo Office</dc:title><dc:creator>Geo Office</dc:creator></cp:coreProperties>"""
    private fun appProps(count: Int) = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Geo Office</Application><Slides>$count</Slides></Properties>"""
}
