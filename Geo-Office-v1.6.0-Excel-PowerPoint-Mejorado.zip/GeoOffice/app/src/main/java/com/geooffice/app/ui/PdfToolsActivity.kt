package com.geooffice.app.ui

import android.app.Dialog
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import android.util.LruCache
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.geooffice.app.R
import com.geooffice.app.databinding.ActivityPdfToolsBinding
import com.geooffice.app.pdf.PdfOps
import com.geooffice.app.util.UriUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Collections
import kotlin.math.roundToInt

class PdfToolsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfToolsBinding
    private var selectedImages: MutableList<Uri> = mutableListOf()
    private var selectedPdfs: List<Uri> = emptyList()
    private var selectedSinglePdf: Uri? = null
    private var pendingPassword = ""
    private var pendingProtectedName = "Geo Office protegido.pdf"
    private var pendingCompressionProfile = PdfOps.CompressionProfile.MINIMUM
    private var pendingOriginalBytes = 0L
    private var treeAction: TreeAction? = null

    private enum class TreeAction { SPLIT, TO_IMAGES }

    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            persistUris(uris)
            selectedImages = uris.toMutableList()
            pendingOriginalBytes = UriUtils.totalSize(this, uris)
            showImagesPdfDialog()
        }
    }

    private val createImagesPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output ->
            val password = pendingPassword
            val profile = pendingCompressionProfile
            val originalBytes = pendingOriginalBytes
            runTask("Creando PDF página por página…") {
                val pages = PdfOps.imagesToProtectedPdf(this, selectedImages, output, password, profile)
                val finalBytes = UriUtils.size(this, output)
                buildResultMessage(
                    heading = if (password.isBlank()) "PDF creado" else "PDF creado con contraseña",
                    itemLine = "$pages imágenes convertidas",
                    originalBytes = originalBytes,
                    finalBytes = finalBytes,
                    profile = profile
                )
            }
        }
    }

    private val pickProtectPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            showPasswordDialog(
                title = "Proteger PDF existente",
                defaultName = "Geo Office protegido",
                message = "Se creará una copia cifrada. El archivo original no se modifica."
            ) { name, password ->
                pendingPassword = password
                pendingProtectedName = ensurePdfExtension(name)
                createProtectedPdf.launch(pendingProtectedName)
            }
        }
    }

    private val createProtectedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val input = selectedSinglePdf
        if (output != null && input != null) {
            val password = pendingPassword
            runTask("Aplicando contraseña…") {
                PdfOps.protect(this, input, output, password)
                val size = UriUtils.size(this, output)
                "PDF protegido correctamente\nTamaño final: ${UriUtils.formatSize(size)}"
            }
        }
    }

    private val pickMergePdfs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.size < 2) toast("Selecciona al menos dos PDF")
        else {
            persistUris(uris)
            selectedPdfs = uris
            createMergedPdf.launch("Geo Office unido.pdf")
        }
    }

    private val createMergedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output ->
            runTask("Uniendo PDF…") {
                PdfOps.merge(this, selectedPdfs, output)
                "PDF unidos correctamente\nTamaño final: ${UriUtils.formatSize(UriUtils.size(this, output))}"
            }
        }
    }

    private val pickSplitPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            treeAction = TreeAction.SPLIT
            chooseFolder.launch(null)
        }
    }

    private val pickImagePdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            treeAction = TreeAction.TO_IMAGES
            chooseFolder.launch(null)
        }
    }

    private val chooseFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val input = selectedSinglePdf
        val action = treeAction
        if (tree == null || input == null || action == null) return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                tree,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        when (action) {
            TreeAction.SPLIT -> runTask("Dividiendo PDF…") {
                val count = PdfOps.split(this, input, tree)
                "$count páginas PDF guardadas"
            }
            TreeAction.TO_IMAGES -> runTask("Convirtiendo páginas…") {
                val count = PdfOps.toImages(this, input, tree)
                "$count imágenes PNG guardadas"
            }
        }
    }

    private val pickCompressPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            pendingOriginalBytes = UriUtils.size(this, it)
            showCompressPdfDialog()
        }
    }

    private val createCompressedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val input = selectedSinglePdf
        if (output != null && input != null) {
            val profile = pendingCompressionProfile
            val originalBytes = pendingOriginalBytes
            runTask("Comprimiendo página por página…") {
                val count = PdfOps.compressAsImages(this, input, output, profile)
                val finalBytes = UriUtils.size(this, output)
                buildResultMessage(
                    heading = "PDF comprimido",
                    itemLine = "$count páginas procesadas",
                    originalBytes = originalBytes,
                    finalBytes = finalBytes,
                    profile = profile
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.cardImagesToPdf.setOnClickListener { pickImages.launch(arrayOf("image/*")) }
        binding.cardProtectPdf.setOnClickListener { pickProtectPdf.launch(arrayOf("application/pdf")) }
        binding.cardMergePdf.setOnClickListener { pickMergePdfs.launch(arrayOf("application/pdf")) }
        binding.cardSplitPdf.setOnClickListener { pickSplitPdf.launch(arrayOf("application/pdf")) }
        binding.cardPdfToImages.setOnClickListener { pickImagePdf.launch(arrayOf("application/pdf")) }
        binding.cardCompressPdf.setOnClickListener { pickCompressPdf.launch(arrayOf("application/pdf")) }
    }

    private fun showImagesPdfDialog() {
        pendingCompressionProfile = PdfOps.CompressionProfile.MINIMUM
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_images_to_pdf)
        dialog.setCanceledOnTouchOutside(false)

        val countText = dialog.findViewById<TextView>(R.id.tvSelectedCount)
        val nameLayout = dialog.findViewById<TextInputLayout>(R.id.layoutPdfName)
        val nameInput = dialog.findViewById<TextInputEditText>(R.id.inputPdfName)
        val protectSwitch = dialog.findViewById<MaterialSwitch>(R.id.switchProtectPdf)
        val passwordContainer = dialog.findViewById<View>(R.id.passwordContainer)
        val passwordLayout = dialog.findViewById<TextInputLayout>(R.id.layoutPassword)
        val passwordInput = dialog.findViewById<TextInputEditText>(R.id.inputPassword)
        val confirmLayout = dialog.findViewById<TextInputLayout>(R.id.layoutConfirmPassword)
        val confirmInput = dialog.findViewById<TextInputEditText>(R.id.inputConfirmPassword)
        val compressionGroup = dialog.findViewById<RadioGroup>(R.id.radioCompression)
        val estimateText = dialog.findViewById<TextView>(R.id.tvEstimate)
        val recycler = dialog.findViewById<RecyclerView>(R.id.recyclerSelectedImages)
        val closeButton = dialog.findViewById<MaterialButton>(R.id.btnCloseDialog)
        val cancelButton = dialog.findViewById<MaterialButton>(R.id.btnCancelDialog)
        val createButton = dialog.findViewById<MaterialButton>(R.id.btnCreatePdf)

        fun refreshSelectionSummary() {
            pendingOriginalBytes = UriUtils.totalSize(this, selectedImages)
            countText.text = "${selectedImages.size} imágenes seleccionadas"
            updateEstimateText(estimateText, pendingOriginalBytes, selectedImages.size, pendingCompressionProfile)
            createButton.isEnabled = selectedImages.isNotEmpty()
        }

        val imageAdapter = SelectedImagesAdapter(selectedImages) { position ->
            if (position in selectedImages.indices) {
                selectedImages.removeAt(position)
                recycler.adapter?.notifyDataSetChanged()
                refreshSelectionSummary()
            }
        }
        recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recycler.adapter = imageAdapter
        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT,
            0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from !in selectedImages.indices || to !in selectedImages.indices) return false
                Collections.swap(selectedImages, from, to)
                recycler.adapter?.notifyItemMoved(from, to)
                recycler.adapter?.notifyItemRangeChanged(minOf(from, to), kotlin.math.abs(from - to) + 1)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit

            override fun isLongPressDragEnabled(): Boolean = true
        })
        touchHelper.attachToRecyclerView(recycler)
        refreshSelectionSummary()

        protectSwitch.setOnCheckedChangeListener { _, checked ->
            passwordContainer.visibility = if (checked) View.VISIBLE else View.GONE
            passwordLayout.error = null
            confirmLayout.error = null
        }

        compressionGroup.setOnCheckedChangeListener { _, checkedId ->
            pendingCompressionProfile = when (checkedId) {
                R.id.radioBalanced -> PdfOps.CompressionProfile.BALANCED
                R.id.radioHigh -> PdfOps.CompressionProfile.HIGH
                R.id.radioOriginal -> PdfOps.CompressionProfile.ORIGINAL
                else -> PdfOps.CompressionProfile.MINIMUM
            }
            updateEstimateText(estimateText, pendingOriginalBytes, selectedImages.size, pendingCompressionProfile)
        }

        closeButton.setOnClickListener { dialog.dismiss() }
        cancelButton.setOnClickListener { dialog.dismiss() }
        createButton.setOnClickListener {
            val name = nameInput.text?.toString()?.trim().orEmpty()
            val password = passwordInput.text?.toString().orEmpty()
            val confirmation = confirmInput.text?.toString().orEmpty()
            val protect = protectSwitch.isChecked

            nameLayout.error = null
            passwordLayout.error = null
            confirmLayout.error = null

            when {
                selectedImages.isEmpty() -> toast("Selecciona al menos una imagen")
                name.isBlank() -> nameLayout.error = "Escribe un nombre"
                protect && password.length < 4 -> passwordLayout.error = "Usa al menos 4 caracteres"
                protect && password.length > 127 -> passwordLayout.error = "La contraseña es demasiado larga"
                protect && password != confirmation -> confirmLayout.error = "Las contraseñas no coinciden"
                else -> {
                    pendingPassword = if (protect) password else ""
                    dialog.dismiss()
                    createImagesPdf.launch(ensurePdfExtension(name))
                }
            }
        }

        dialog.setOnShowListener {
            dialog.window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        dialog.show()
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    private fun showCompressPdfDialog() {
        val container = createDialogContainer()
        val nameLayout = textField("Nombre del PDF", "Geo Office comprimido")
        val estimateText = estimateTextView()
        val profileGroup = createProfileGroup(PdfOps.CompressionProfile.MINIMUM) { selected ->
            pendingCompressionProfile = selected
            updateEstimateText(estimateText, pendingOriginalBytes, 1, selected)
        }
        container.addView(sectionTitle("Nivel de compresión"))
        container.addView(profileGroup, marginTopParams(4))
        container.addView(estimateText, marginTopParams(12))
        container.addView(nameLayout.first, marginTopParams(14))
        updateEstimateText(estimateText, pendingOriginalBytes, 1, pendingCompressionProfile)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Comprimir PDF")
            .setMessage("Mínimo peso está seleccionado por defecto. La estimación puede variar según las fotos, gráficos y texto del PDF.")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Comprimir", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameLayout.second.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    nameLayout.first.error = "Escribe un nombre"
                } else {
                    dialog.dismiss()
                    createCompressedPdf.launch(ensurePdfExtension(name))
                }
            }
        }
        dialog.show()
    }

    private fun showPasswordDialog(
        title: String,
        defaultName: String,
        message: String,
        onReady: (String, String) -> Unit
    ) {
        val container = createDialogContainer()
        val nameLayout = textField("Nombre del PDF", defaultName)
        val passwordLayout = passwordField("Contraseña para abrir", "Mínimo 4 caracteres. No podremos recuperar una contraseña olvidada.")
        val confirmLayout = passwordField("Repetir contraseña", null)

        container.addView(nameLayout.first)
        container.addView(passwordLayout.first, marginTopParams(14))
        container.addView(confirmLayout.first, marginTopParams(10))

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                passwordLayout.first.error = null
                confirmLayout.first.error = null
                nameLayout.first.error = null

                val name = nameLayout.second.text?.toString()?.trim().orEmpty()
                val password = passwordLayout.second.text?.toString().orEmpty()
                val confirmation = confirmLayout.second.text?.toString().orEmpty()

                when {
                    name.isBlank() -> nameLayout.first.error = "Escribe un nombre"
                    password.length < 4 -> passwordLayout.first.error = "Usa al menos 4 caracteres"
                    password.length > 127 -> passwordLayout.first.error = "La contraseña es demasiado larga"
                    password != confirmation -> confirmLayout.first.error = "Las contraseñas no coinciden"
                    else -> {
                        dialog.dismiss()
                        onReady(name, password)
                    }
                }
            }
        }
        dialog.show()
    }

    private inner class SelectedImagesAdapter(
        private val items: MutableList<Uri>,
        private val onRemove: (Int) -> Unit
    ) : RecyclerView.Adapter<SelectedImagesAdapter.ImageViewHolder>() {

        private val thumbnailCache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }

        inner class ImageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val image: ImageView = view.findViewById(R.id.imageThumb)
            val order: TextView = view.findViewById(R.id.textOrder)
            val remove: MaterialButton = view.findViewById(R.id.btnRemoveImage)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pdf_image, parent, false)
            return ImageViewHolder(view)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
            val uri = items[position]
            val key = uri.toString()
            holder.order.text = (position + 1).toString()
            holder.remove.setOnClickListener {
                val current = holder.bindingAdapterPosition
                if (current != RecyclerView.NO_POSITION) onRemove(current)
            }
            holder.image.setImageDrawable(null)
            val cached = thumbnailCache.get(key)
            if (cached != null && !cached.isRecycled) {
                holder.image.setImageBitmap(cached)
                return
            }
            Thread {
                val bitmap = loadThumbnail(uri, 320)
                if (bitmap != null) thumbnailCache.put(key, bitmap)
                holder.image.post {
                    val current = holder.bindingAdapterPosition
                    if (current != RecyclerView.NO_POSITION && current < items.size && items[current] == uri) {
                        holder.image.setImageBitmap(bitmap)
                    }
                }
            }.start()
        }
    }

    private fun loadThumbnail(uri: Uri, target: Int): Bitmap? {
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri).use { input -> BitmapFactory.decodeStream(input, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) {
                sample *= 2
            }
            val options = BitmapFactory.Options().apply {
                inSampleSize = sample.coerceAtLeast(1)
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            contentResolver.openInputStream(uri).use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }
        }.getOrNull()
    }

    private fun createProfileGroup(
        initial: PdfOps.CompressionProfile,
        onChanged: (PdfOps.CompressionProfile) -> Unit
    ): RadioGroup {
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }
        PdfOps.CompressionProfile.entries.forEach { profile ->
            val button = RadioButton(this).apply {
                id = View.generateViewId()
                tag = profile.name
                text = "${profile.label}\n${profile.description}"
                textSize = 14f
                setPadding(0, 6.dp, 0, 6.dp)
                isChecked = profile == initial
            }
            group.addView(button)
        }
        group.setOnCheckedChangeListener { radioGroup, checkedId ->
            val selectedName = radioGroup.findViewById<RadioButton>(checkedId)?.tag?.toString() ?: return@setOnCheckedChangeListener
            val selected = PdfOps.CompressionProfile.valueOf(selectedName)
            onChanged(selected)
        }
        pendingCompressionProfile = initial
        return group
    }

    private fun updateEstimateText(
        target: TextView,
        originalBytes: Long,
        itemCount: Int,
        profile: PdfOps.CompressionProfile
    ) {
        val estimate = PdfOps.estimateOutputBytes(originalBytes, itemCount, profile)
        val lower = (estimate * 0.80).toLong()
        val upper = (estimate * 1.20).toLong()
        val original = if (originalBytes > 0) UriUtils.formatSize(originalBytes) else "No disponible"
        val saving = if (originalBytes > 0) {
            val percent = (100.0 * (1.0 - estimate.toDouble() / originalBytes.toDouble())).roundToInt().coerceIn(0, 99)
            "\nAhorro aproximado: $percent %"
        } else ""
        target.text = "Tamaño original: $original\nTamaño estimado: ${UriUtils.formatSize(lower)}–${UriUtils.formatSize(upper)}$saving\nEl tamaño final real se mostrará al terminar."
    }

    private fun buildResultMessage(
        heading: String,
        itemLine: String,
        originalBytes: Long,
        finalBytes: Long,
        profile: PdfOps.CompressionProfile
    ): String {
        val originalLine = if (originalBytes > 0L) "\nTamaño original: ${UriUtils.formatSize(originalBytes)}" else ""
        val finalLine = if (finalBytes > 0L) "\nTamaño final real: ${UriUtils.formatSize(finalBytes)}" else "\nTamaño final: no disponible"
        val savingLine = if (originalBytes > 0L && finalBytes > 0L) {
            val saving = (100.0 * (1.0 - finalBytes.toDouble() / originalBytes.toDouble())).roundToInt()
            if (saving >= 0) "\nAhorro real: $saving %" else "\nEl archivo aumentó ${-saving} %"
        } else ""
        return "$heading\n$itemLine\nModo: ${profile.label}$originalLine$finalLine$savingLine"
    }

    private fun createDialogContainer() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(20.dp, 4.dp, 20.dp, 0)
    }

    private fun textField(hint: String, defaultText: String): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this).apply {
            this.hint = hint
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
        }
        val input = TextInputEditText(layout.context).apply {
            setText(defaultText)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        layout.addView(input)
        return layout to input
    }

    private fun passwordField(hint: String, helper: String?): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this).apply {
            this.hint = hint
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
            helperText = helper
        }
        val input = TextInputEditText(layout.context).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        layout.addView(input)
        return layout to input
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun estimateTextView() = TextView(this).apply {
        textSize = 14f
        setPadding(14.dp, 12.dp, 14.dp, 12.dp)
        setBackgroundColor(0xFFF1F5F9.toInt())
    }

    private fun marginTopParams(topDp: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = topDp.dp }

    private fun ensurePdfExtension(name: String): String {
        val clean = name.trim().ifBlank { "Geo Office protegido" }
        return if (clean.endsWith(".pdf", ignoreCase = true)) clean else "$clean.pdf"
    }

    private fun persistUris(uris: List<Uri>) = uris.forEach(::persistUri)

    private fun persistUri(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    private fun runTask(startMessage: String, task: () -> String) {
        toast(startMessage)
        Thread {
            runCatching(task)
                .onSuccess { message ->
                    runOnUiThread {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Proceso terminado")
                            .setMessage(message)
                            .setPositiveButton("Aceptar", null)
                            .show()
                    }
                }
                .onFailure { error -> runOnUiThread { toast("Error: ${error.message}") } }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private val Int.dp: Int
        get() = (this * Resources.getSystem().displayMetrics.density).toInt()
}
