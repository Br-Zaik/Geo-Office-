package com.geooffice.app.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.text.style.ImageSpan
import kotlin.math.max

class GeoImageDrawable(
    var bitmap: Bitmap
) : Drawable() {
    var selected: Boolean = false

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.rgb(61, 133, 255)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val handleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.rgb(61, 133, 255)
    }

    override fun draw(canvas: Canvas) {
        val target = bounds
        if (!bitmap.isRecycled) canvas.drawBitmap(bitmap, null, target, bitmapPaint)
        if (selected) {
            val inset = 2f
            canvas.drawRect(
                target.left + inset,
                target.top + inset,
                target.right - inset,
                target.bottom - inset,
                borderPaint
            )
            val radius = max(9f, target.width() * 0.018f)
            val points = arrayOf(
                target.left.toFloat() to target.top.toFloat(),
                target.right.toFloat() to target.top.toFloat(),
                target.left.toFloat() to target.bottom.toFloat(),
                target.right.toFloat() to target.bottom.toFloat()
            )
            for (point in points) {
                val x = point.first
                val y = point.second
                canvas.drawCircle(x, y, radius, handlePaint)
                canvas.drawCircle(x, y, radius, handleStrokePaint)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        bitmapPaint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        bitmapPaint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = bounds.width().takeIf { it > 0 } ?: bitmap.width
    override fun getIntrinsicHeight(): Int = bounds.height().takeIf { it > 0 } ?: bitmap.height
}

class GeoImageSpan(
    drawable: GeoImageDrawable,
    var sourceUri: String,
    var displayWidthPx: Int,
    var displayHeightPx: Int
) : ImageSpan(drawable, sourceUri, ImageSpan.ALIGN_BOTTOM) {

    val geoDrawable: GeoImageDrawable
        get() = drawable as GeoImageDrawable

    fun setSelected(selected: Boolean) {
        geoDrawable.selected = selected
        geoDrawable.invalidateSelf()
    }

    fun resize(widthPx: Int, heightPx: Int) {
        displayWidthPx = widthPx.coerceAtLeast(48)
        displayHeightPx = heightPx.coerceAtLeast(48)
        drawable.setBounds(0, 0, displayWidthPx, displayHeightPx)
        drawable.invalidateSelf()
    }
}
