package com.geooffice.app.office

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.util.Xml
import com.geooffice.app.util.XmlUtils
import com.geooffice.app.util.ZipUtils
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.Locale
import java.util.zip.ZipOutputStream

data class GeoCellStyleData(
    val bold: Boolean = false,
    val italic: Boolean = false,
    val textColor: Int = Color.rgb(26, 32, 44),
    val fillColor: Int = Color.TRANSPARENT,
    val alignment: String = "left",
    val numberFormat: String = "normal"
)

data class GeoSheetData(
    var name: String,
    val rows: List<List<String>>,
    val styles: Map<Pair<Int, Int>, GeoCellStyleData> = emptyMap()
)

object OpenXmlXlsx {
    fun write(context: Context, uri: Uri, rows: List<List<String>>) {
        writeWorkbook(context, uri, listOf(GeoSheetData("Hoja 1", rows)))
    }

    fun read(context: Context, uri: Uri): List<List<String>> =
        readWorkbook(context, uri).firstOrNull()?.rows.orEmpty()

    fun writeWorkbook(context: Context, uri: Uri, sheets: List<GeoSheetData>) {
        val safeSheets = sheets.ifEmpty { listOf(GeoSheetData("Hoja 1", emptyList())) }
        val styleIds = linkedMapOf<GeoCellStyleData, Int>()
        safeSheets.forEach { sheet ->
            sheet.styles.values.forEach { style ->
                if (style != GeoCellStyleData() && style !in styleIds) styleIds[style] = styleIds.size + 1
            }
        }
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear la hoja de cálculo" }
            ZipOutputStream(output).use { zip ->
                ZipUtils.writeEntry(zip, "[Content_Types].xml", contentTypes(safeSheets.size))
                ZipUtils.writeEntry(zip, "_rels/.rels", rootRels())
                ZipUtils.writeEntry(zip, "docProps/core.xml", coreProps())
                ZipUtils.writeEntry(zip, "docProps/app.xml", appProps(safeSheets.size))
                ZipUtils.writeEntry(zip, "xl/workbook.xml", workbookXml(safeSheets))
                ZipUtils.writeEntry(zip, "xl/_rels/workbook.xml.rels", workbookRels(safeSheets.size))
                ZipUtils.writeEntry(zip, "xl/styles.xml", stylesXml(styleIds.keys.toList()))
                safeSheets.forEachIndexed { index, sheet ->
                    ZipUtils.writeEntry(zip, "xl/worksheets/sheet${index + 1}.xml", sheetXml(sheet, styleIds))
                }
            }
        }
    }

    fun readWorkbook(context: Context, uri: Uri): List<GeoSheetData> {
        val entries = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la hoja" }
            ZipUtils.readEntries(input)
        }
        val shared = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val parsedStyles = entries["xl/styles.xml"]?.let(::parseStyles).orEmpty()
        val rels = entries["xl/_rels/workbook.xml.rels"]?.let(::parseWorkbookRels).orEmpty()
        val sheetRefs = entries["xl/workbook.xml"]?.let(::parseWorkbookSheets).orEmpty()
        if (sheetRefs.isEmpty()) {
            val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
            val parsed = parseSheet(sheet, shared, parsedStyles)
            return listOf(GeoSheetData("Hoja 1", parsed.first, parsed.second))
        }
        return sheetRefs.mapNotNull { (name, relationId) ->
            val target = rels[relationId] ?: return@mapNotNull null
            val normalized = when {
                target.startsWith("/") -> target.removePrefix("/")
                target.startsWith("xl/") -> target
                else -> "xl/${target.removePrefix("../")}".replace("xl/xl/", "xl/")
            }
            val bytes = entries[normalized] ?: entries["xl/$target"] ?: return@mapNotNull null
            val parsed = parseSheet(bytes, shared, parsedStyles)
            GeoSheetData(name, parsed.first, parsed.second)
        }
    }

    private fun parseWorkbookSheets(bytes: ByteArray): List<Pair<String, String>> {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<Pair<String, String>>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') == "sheet") {
                val name = parser.getAttributeValue(null, "name") ?: "Hoja ${result.size + 1}"
                var relationId: String? = null
                for (index in 0 until parser.attributeCount) {
                    if (parser.getAttributeName(index).substringAfter(':') == "id") relationId = parser.getAttributeValue(index)
                }
                if (!relationId.isNullOrBlank()) result.add(name to relationId)
            }
            event = parser.next()
        }
        return result
    }

    private fun parseWorkbookRels(bytes: ByteArray): Map<String, String> {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = linkedMapOf<String, String>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') == "Relationship") {
                val id = parser.getAttributeValue(null, "Id").orEmpty()
                val target = parser.getAttributeValue(null, "Target").orEmpty()
                if (id.isNotBlank() && target.isNotBlank()) result[id] = target
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var event = parser.eventType
        var inItem = false
        var inText = false
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "si") { inItem = true; current = StringBuilder() }
                    if (name == "t" && inItem) inText = true
                }
                XmlPullParser.TEXT -> if (inText) current.append(parser.text)
                XmlPullParser.END_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "t") inText = false
                    if (name == "si") { result.add(current.toString()); inItem = false }
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSheet(
        bytes: ByteArray,
        shared: List<String>,
        styles: List<GeoCellStyleData>
    ): Pair<List<List<String>>, Map<Pair<Int, Int>, GeoCellStyleData>> {
        val cells = linkedMapOf<Pair<Int, Int>, String>()
        val cellStyles = linkedMapOf<Pair<Int, Int>, GeoCellStyleData>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType
        var ref = ""
        var type = ""
        var styleIndex = 0
        var value = StringBuilder()
        var formula = StringBuilder()
        var activeTag = ""
        var maxRow = 0
        var maxCol = 0
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "c") {
                        ref = parser.getAttributeValue(null, "r") ?: ""
                        type = parser.getAttributeValue(null, "t") ?: ""
                        styleIndex = parser.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                        value = StringBuilder()
                        formula = StringBuilder()
                    }
                    if (name == "v" || name == "t" || name == "f") activeTag = name
                }
                XmlPullParser.TEXT -> when (activeTag) {
                    "f" -> formula.append(parser.text)
                    "v", "t" -> value.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == activeTag) activeTag = ""
                    if (name == "c" && ref.isNotBlank()) {
                        val (row, col) = parseCellRef(ref)
                        var cellValue = if (formula.isNotEmpty()) "=${formula}" else value.toString()
                        if (formula.isEmpty() && type == "s") {
                            cellValue = shared.getOrNull(value.toString().toIntOrNull() ?: -1).orEmpty()
                        }
                        cells[row to col] = cellValue
                        styles.getOrNull(styleIndex)?.takeIf { it != GeoCellStyleData() }?.let { cellStyles[row to col] = it }
                        maxRow = maxOf(maxRow, row)
                        maxCol = maxOf(maxCol, col)
                    }
                }
            }
            event = parser.next()
        }
        if (cells.isEmpty()) return emptyList<List<String>>() to cellStyles
        val rows = (0..maxRow).map { row -> (0..maxCol).map { col -> cells[row to col].orEmpty() } }
        return rows to cellStyles
    }

    private fun parseStyles(bytes: ByteArray): List<GeoCellStyleData> {
        val xml = bytes.toString(Charsets.UTF_8)
        val fontBlocks = Regex("<font>(.*?)</font>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { it.groupValues[1] }.toList()
        val fonts = fontBlocks.map { block ->
            val colorText = Regex("<color[^>]*rgb=\"([0-9A-Fa-f]{6,8})\"").find(block)?.groupValues?.get(1)
            FontInfo(
                bold = "<b" in block,
                italic = "<i" in block,
                color = parseArgb(colorText) ?: Color.rgb(26, 32, 44)
            )
        }
        val fillBlocks = Regex("<fill>(.*?)</fill>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { it.groupValues[1] }.toList()
        val fills = fillBlocks.map { block ->
            parseArgb(Regex("<fgColor[^>]*rgb=\"([0-9A-Fa-f]{6,8})\"").find(block)?.groupValues?.get(1)) ?: Color.TRANSPARENT
        }
        val cellXfs = Regex("<cellXfs[^>]*>(.*?)</cellXfs>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1).orEmpty()
        val xfRegex = Regex("<xf\\s+([^>]*?)(?:/>|>(.*?)</xf>)", RegexOption.DOT_MATCHES_ALL)
        val result = mutableListOf<GeoCellStyleData>()
        xfRegex.findAll(cellXfs).forEach { match ->
            val attrs = match.groupValues[1]
            val body = match.groupValues.getOrElse(2) { "" }
            val fontId = attrInt(attrs, "fontId")
            val fillId = attrInt(attrs, "fillId")
            val numFmtId = attrInt(attrs, "numFmtId")
            val alignment = Regex("horizontal=\"(left|center|right)\"").find(body)?.groupValues?.get(1) ?: "left"
            val font = fonts.getOrNull(fontId) ?: FontInfo()
            result.add(
                GeoCellStyleData(
                    bold = font.bold,
                    italic = font.italic,
                    textColor = font.color,
                    fillColor = fills.getOrNull(fillId) ?: Color.TRANSPARENT,
                    alignment = alignment,
                    numberFormat = when (numFmtId) {
                        164 -> "currency"
                        10 -> "percent"
                        2 -> "decimal"
                        else -> "normal"
                    }
                )
            )
        }
        return result.ifEmpty { listOf(GeoCellStyleData()) }
    }

    private fun attrInt(attrs: String, name: String): Int = Regex("$name=\"(\\d+)\"").find(attrs)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun parseArgb(value: String?): Int? {
        if (value.isNullOrBlank()) return null
        return runCatching {
            val normalized = if (value.length == 6) "FF$value" else value
            normalized.toLong(16).toInt()
        }.getOrNull()
    }

    private fun parseCellRef(ref: String): Pair<Int, Int> {
        val letters = ref.takeWhile { it.isLetter() }.uppercase()
        val digits = ref.dropWhile { it.isLetter() }
        var col = 0
        letters.forEach { col = col * 26 + (it - 'A' + 1) }
        return (digits.toIntOrNull()?.minus(1) ?: 0) to (col - 1).coerceAtLeast(0)
    }

    private fun sheetXml(sheet: GeoSheetData, styleIds: Map<GeoCellStyleData, Int>): String {
        val xmlRows = buildString {
            sheet.rows.forEachIndexed { rowIndex, row ->
                val nonEmpty = row.mapIndexedNotNull { col, value ->
                    val style = sheet.styles[rowIndex to col]
                    if (value.isNotBlank() || style != null) Triple(col, value, style) else null
                }
                if (nonEmpty.isEmpty()) return@forEachIndexed
                append("<row r=\"${rowIndex + 1}\">")
                nonEmpty.forEach { (colIndex, raw, style) ->
                    val ref = columnName(colIndex) + (rowIndex + 1)
                    val styleAttr = style?.let { styleIds[it] }?.takeIf { it > 0 }?.let { " s=\"$it\"" }.orEmpty()
                    if (raw.startsWith("=") && raw.length > 1) {
                        append("<c r=\"$ref\"$styleAttr><f>").append(XmlUtils.escape(raw.drop(1))).append("</f><v>0</v></c>")
                    } else if (raw.replace(',', '.').toDoubleOrNull() != null) {
                        append("<c r=\"$ref\"$styleAttr><v>").append(raw.replace(',', '.')).append("</v></c>")
                    } else {
                        append("<c r=\"$ref\" t=\"inlineStr\"$styleAttr><is><t xml:space=\"preserve\">")
                            .append(XmlUtils.escape(raw)).append("</t></is></c>")
                    }
                }
                append("</row>")
            }
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView workbookViewId="0"><selection activeCell="A1" sqref="A1"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="20"/><sheetData>$xmlRows</sheetData>
<pageMargins left="0.35" right="0.35" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>
</worksheet>"""
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val result = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            result.append(('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return result.reverse().toString()
    }

    private fun contentTypes(count: Int) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
        for (i in 1..count) append("<Override PartName=\"/xl/worksheets/sheet$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
        append("""<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>""")
    }

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>"""

    private fun workbookXml(sheets: List<GeoSheetData>) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="12000" windowHeight="8000"/></bookViews><sheets>""")
        sheets.forEachIndexed { index, sheet ->
            val safeName = sheet.name.ifBlank { "Hoja ${index + 1}" }.take(31)
            append("<sheet name=\"${XmlUtils.escape(safeName)}\" sheetId=\"${index + 1}\" r:id=\"rId${index + 1}\"/>")
        }
        append("""</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>""")
    }

    private fun workbookRels(count: Int) = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..count) append("<Relationship Id=\"rId$i\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet$i.xml\"/>")
        append("<Relationship Id=\"rId${count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>")
    }

    private fun stylesXml(styles: List<GeoCellStyleData>): String {
        val fonts = buildString {
            append("<fonts count=\"${styles.size + 1}\"><font><sz val=\"11\"/><color rgb=\"FF1A202C\"/><name val=\"Calibri\"/><family val=\"2\"/></font>")
            styles.forEach { style ->
                append("<font>")
                if (style.bold) append("<b/>")
                if (style.italic) append("<i/>")
                append("<sz val=\"11\"/><color rgb=\"${argbHex(style.textColor)}\"/><name val=\"Calibri\"/><family val=\"2\"/></font>")
            }
            append("</fonts>")
        }
        val fills = buildString {
            append("<fills count=\"${styles.size + 2}\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>")
            styles.forEach { style ->
                if (style.fillColor == Color.TRANSPARENT) append("<fill><patternFill patternType=\"none\"/></fill>")
                else append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"${argbHex(style.fillColor)}\"/><bgColor indexed=\"64\"/></patternFill></fill>")
            }
            append("</fills>")
        }
        val xfs = buildString {
            append("<cellXfs count=\"${styles.size + 1}\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>")
            styles.forEachIndexed { index, style ->
                val numFmtId = when (style.numberFormat) { "currency" -> 164; "percent" -> 10; "decimal" -> 2; else -> 0 }
                append("<xf numFmtId=\"$numFmtId\" fontId=\"${index + 1}\" fillId=\"${index + 2}\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\" applyNumberFormat=\"1\"><alignment horizontal=\"${style.alignment}\" vertical=\"center\"/></xf>")
            }
            append("</cellXfs>")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="S/ #,##0.00"/></numFmts>$fonts$fills<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>$xfs<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""
    }

    private fun argbHex(color: Int): String = String.format(Locale.US, "%08X", color)
    private data class FontInfo(val bold: Boolean = false, val italic: Boolean = false, val color: Int = Color.rgb(26, 32, 44))
    private fun coreProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Hoja de Geo Office</dc:title><dc:creator>Geo Office</dc:creator></cp:coreProperties>"""
    private fun appProps(count: Int) = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Geo Office</Application><Sheets>$count</Sheets></Properties>"""
}
