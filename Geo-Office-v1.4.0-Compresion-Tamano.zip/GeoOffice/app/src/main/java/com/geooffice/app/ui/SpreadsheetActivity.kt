package com.geooffice.app.ui

import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.geooffice.app.MainActivity
import com.geooffice.app.R
import com.geooffice.app.databinding.ActivitySpreadsheetBinding
import com.geooffice.app.office.OpenXmlXlsx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.util.UriUtils
import java.util.Locale
import kotlin.math.roundToLong

class SpreadsheetActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySpreadsheetBinding
    private val cells = mutableListOf<MutableList<EditText>>()
    private val formulas = mutableMapOf<Pair<Int, Int>, String>()
    private var rowCount = 30
    private val colCount = 8
    private var selectedRow = 0
    private var selectedCol = 0
    private var currentUri: Uri? = null
    private var updating = false

    private val createXlsx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> uri?.let { saveXlsx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpreadsheetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        buildGrid(rowCount)
        selectCell(0, 0)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSave.setOnClickListener {
            val uri = currentUri
            if (uri == null || UriUtils.extension(this, uri) != "xlsx") {
                createXlsx.launch(suggestedName("xlsx"))
            } else {
                saveXlsx(uri, false)
            }
        }
        binding.btnExportPdf.setOnClickListener { createPdf.launch(suggestedName("pdf")) }
        binding.btnAddRow.setOnClickListener { addRows(10) }
        binding.btnClear.setOnClickListener {
            formulas.clear()
            updating = true
            cells.flatten().forEach { it.setText("") }
            updating = false
            binding.formulaBar.setText("")
        }

        binding.formulaBar.setOnEditorActionListener { _, _, event ->
            if (event == null || event.keyCode == KeyEvent.KEYCODE_ENTER) {
                applyFormulaBar()
                true
            } else false
        }
        binding.formulaBar.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) applyFormulaBar() }

        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
            currentUri = Uri.parse(raw)
            binding.tvTitle.text = UriUtils.displayName(this, currentUri!!)
            loadFile(currentUri!!)
        }
    }

    private fun buildGrid(rows: Int) {
        binding.grid.removeAllViews()
        cells.clear()
        formulas.clear()
        binding.grid.columnCount = colCount + 1
        binding.grid.rowCount = rows + 1

        binding.grid.addView(headerCell("", 0, 0))
        for (col in 0 until colCount) binding.grid.addView(headerCell(columnName(col), 0, col + 1))

        for (row in 0 until rows) {
            binding.grid.addView(headerCell((row + 1).toString(), row + 1, 0))
            val rowCells = mutableListOf<EditText>()
            for (col in 0 until colCount) {
                val cell = createCell(row, col)
                rowCells.add(cell)
                binding.grid.addView(cell)
            }
            cells.add(rowCells)
        }
    }

    private fun addRows(amount: Int) {
        val existing = exportRawRows()
        rowCount += amount
        buildGrid(rowCount)
        fillRows(existing)
        Toast.makeText(this, "$amount filas agregadas", Toast.LENGTH_SHORT).show()
    }

    private fun headerCell(text: String, row: Int, col: Int): TextView {
        return TextView(this).apply {
            this.text = text
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(context, R.color.geo_text))
            setBackgroundResource(R.drawable.bg_cell_header)
            layoutParams = GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(col)).apply {
                width = if (col == 0) 52.dp else 110.dp
                height = 48.dp
            }
        }
    }

    private fun createCell(row: Int, col: Int): EditText {
        return EditText(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 0, 8.dp, 0)
            textSize = 14f
            setTextColor(ContextCompat.getColor(context, R.color.geo_text))
            setBackgroundResource(R.drawable.bg_cell)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = GridLayout.LayoutParams(GridLayout.spec(row + 1), GridLayout.spec(col + 1)).apply {
                width = 110.dp
                height = 48.dp
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    if (!updating && hasFocus()) formulas.remove(row to col)
                }
            })
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) selectCell(row, col) else if (!updating) recalculateAll()
            }
            setOnClickListener { selectCell(row, col) }
        }
    }

    private fun selectCell(row: Int, col: Int) {
        if (row !in cells.indices || col !in 0 until colCount) return
        selectedRow = row
        selectedCol = col
        binding.tvCellName.text = columnName(col) + (row + 1)
        val cell = cells[row][col]
        updating = true
        binding.formulaBar.setText(formulas[row to col] ?: cell.text.toString())
        binding.formulaBar.setSelection(binding.formulaBar.text.length)
        updating = false
    }

    private fun applyFormulaBar() {
        if (updating || selectedRow !in cells.indices) return
        val raw = binding.formulaBar.text?.toString().orEmpty()
        val cell = cells[selectedRow][selectedCol]
        updating = true
        val key = selectedRow to selectedCol
        if (raw.startsWith("=")) {
            formulas[key] = raw
            cell.setText(formatNumber(evaluateFormula(raw.drop(1), mutableSetOf())))
        } else {
            formulas.remove(key)
            cell.setText(raw)
        }
        updating = false
        recalculateAll()
    }

    private fun recalculateAll() {
        if (updating) return
        updating = true
        cells.forEachIndexed { row, rowCells ->
            rowCells.forEachIndexed { col, cell ->
                val raw = formulas[row to col]
                if (raw?.startsWith("=") == true) {
                    cell.setText(formatNumber(evaluateFormula(raw.drop(1), mutableSetOf())))
                }
            }
        }
        updating = false
    }

    private fun evaluateFormula(expression: String, visiting: MutableSet<Pair<Int, Int>>): Double {
        val trimmed = expression.trim().uppercase(Locale.ROOT)
        val function = Regex("^(SUM|AVERAGE|MIN|MAX)\\(([A-Z]+\\d+):([A-Z]+\\d+)\\)$").matchEntire(trimmed)
        if (function != null) {
            val name = function.groupValues[1]
            val start = parseRef(function.groupValues[2]) ?: return 0.0
            val end = parseRef(function.groupValues[3]) ?: return 0.0
            val values = mutableListOf<Double>()
            for (row in minOf(start.first, end.first)..maxOf(start.first, end.first)) {
                for (col in minOf(start.second, end.second)..maxOf(start.second, end.second)) {
                    values.add(cellNumeric(row, col, visiting))
                }
            }
            return when (name) {
                "SUM" -> values.sum()
                "AVERAGE" -> values.average().takeIf { !it.isNaN() } ?: 0.0
                "MIN" -> values.minOrNull() ?: 0.0
                "MAX" -> values.maxOrNull() ?: 0.0
                else -> 0.0
            }
        }

        val binary = Regex("^([A-Z]+\\d+|-?\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*([A-Z]+\\d+|-?\\d+(?:\\.\\d+)?)$").matchEntire(trimmed)
        if (binary != null) {
            val left = tokenValue(binary.groupValues[1], visiting)
            val right = tokenValue(binary.groupValues[3], visiting)
            return when (binary.groupValues[2]) {
                "+" -> left + right
                "-" -> left - right
                "*" -> left * right
                "/" -> if (right == 0.0) 0.0 else left / right
                else -> 0.0
            }
        }

        return tokenValue(trimmed, visiting)
    }

    private fun tokenValue(token: String, visiting: MutableSet<Pair<Int, Int>>): Double {
        token.toDoubleOrNull()?.let { return it }
        val ref = parseRef(token) ?: return 0.0
        return cellNumeric(ref.first, ref.second, visiting)
    }

    private fun cellNumeric(row: Int, col: Int, visiting: MutableSet<Pair<Int, Int>>): Double {
        if (row !in cells.indices || col !in 0 until colCount) return 0.0
        val key = row to col
        if (!visiting.add(key)) return 0.0
        val cell = cells[row][col]
        val raw = formulas[row to col] ?: cell.text.toString()
        val result = if (raw.startsWith("=")) evaluateFormula(raw.drop(1), visiting) else raw.replace(',', '.').toDoubleOrNull() ?: 0.0
        visiting.remove(key)
        return result
    }

    private fun parseRef(ref: String): Pair<Int, Int>? {
        val match = Regex("^([A-Z]+)(\\d+)$").matchEntire(ref.uppercase(Locale.ROOT)) ?: return null
        var col = 0
        match.groupValues[1].forEach { col = col * 26 + (it - 'A' + 1) }
        val row = match.groupValues[2].toIntOrNull()?.minus(1) ?: return null
        return row to (col - 1)
    }

    private fun exportRawRows(): List<List<String>> = cells.mapIndexed { row, rowCells -> rowCells.mapIndexed { col, cell -> formulas[row to col] ?: cell.text.toString() } }

    private fun fillRows(rows: List<List<String>>) {
        updating = true
        rows.forEachIndexed outer@ { row, values ->
            if (row !in cells.indices) return@outer
            values.forEachIndexed inner@ { col, value ->
                if (col !in 0 until colCount) return@inner
                val cell = cells[row][col]
                if (value.startsWith("=")) {
                    formulas[row to col] = value
                    cell.setText(formatNumber(evaluateFormula(value.drop(1), mutableSetOf())))
                } else {
                    formulas.remove(row to col)
                    cell.setText(value)
                }
            }
        }
        updating = false
        recalculateAll()
    }

    private fun loadFile(uri: Uri) {
        Thread {
            runCatching {
                when (UriUtils.extension(this, uri)) {
                    "xlsx" -> OpenXmlXlsx.read(this, uri)
                    "csv" -> contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines -> lines.map { parseCsvLine(it) }.toList() }.orEmpty()
                    else -> emptyList()
                }
            }.onSuccess { rows ->
                runOnUiThread {
                    if (rows.size > rowCount) {
                        rowCount = rows.size.coerceAtMost(200)
                        buildGrid(rowCount)
                    }
                    fillRows(rows)
                }
            }.onFailure { error -> runOnUiThread { Toast.makeText(this, "No se pudo abrir: ${error.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun saveXlsx(uri: Uri, updateCurrent: Boolean) {
        val rows = exportRawRows()
        Thread {
            runCatching { OpenXmlXlsx.write(this, uri, rows) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        Toast.makeText(this, "Hoja guardada · ${UriUtils.formatSize(UriUtils.size(this, uri))}", Toast.LENGTH_LONG).show()
                    }
                }
                .onFailure {
                    runOnUiThread {
                        if (!updateCurrent) createXlsx.launch(suggestedName("xlsx"))
                        else Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val rows = exportRawRows().map { row -> row.mapIndexed { col, raw -> if (raw.startsWith("=")) formatNumber(evaluateFormula(raw.drop(1), mutableSetOf())) else raw } }
        Thread {
            runCatching { PdfExporter.tableToPdf(this, uri, rows) }
                .onSuccess { runOnUiThread { Toast.makeText(this, "PDF creado · ${UriUtils.formatSize(UriUtils.size(this, uri))}", Toast.LENGTH_LONG).show() } }
                .onFailure { runOnUiThread { Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var index = 0
        while (index < line.length) {
            val ch = line[index]
            when {
                ch == '"' && quoted && index + 1 < line.length && line[index + 1] == '"' -> { current.append('"'); index++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { result.add(current.toString()); current.clear() }
                else -> current.append(ch)
            }
            index++
        }
        result.add(current.toString())
        return result
    }

    private fun formatNumber(value: Double): String {
        if (!value.isFinite()) return "0"
        return if (kotlin.math.abs(value - value.roundToLong()) < 0.0000001) value.roundToLong().toString()
        else String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val result = StringBuilder()
        while (n > 0) {
            result.append(('A'.code + (n - 1) % 26).toChar())
            n = (n - 1) / 26
        }
        return result.reverse().toString()
    }

    private fun suggestedName(extension: String): String {
        val base = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${base?.takeIf { it.isNotBlank() } ?: "Hoja Geo Office"}.$extension"
    }

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
}
