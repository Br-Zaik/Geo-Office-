package com.geooffice.app.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.geooffice.app.page.PageSettings
import kotlin.math.abs
import kotlin.math.min

class PagePreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var settings: PageSettings = PageSettings()
        set(value) {
            field = value.normalized()
            invalidate()
        }

    var onMarginsChanged: ((PageSettings) -> Unit)? = null

    private val pagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        setShadowLayer(dp(10f), 0f, dp(3f), 0x55000000)
    }
    private val marginPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(37, 99, 235)
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(37, 99, 235)
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = dp(12f)
        textAlign = Paint.Align.CENTER
    }
    private val pageRect = RectF()
    private val contentRect = RectF()
    private var activeEdge = Edge.NONE

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        setBackgroundColor(Color.rgb(235, 238, 243))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        calculateRects()
        canvas.drawRoundRect(pageRect, dp(3f), dp(3f), pagePaint)
        canvas.drawRect(contentRect, marginPaint)

        val radius = dp(7f)
        canvas.drawCircle(contentRect.centerX(), contentRect.top, radius, handlePaint)
        canvas.drawCircle(contentRect.centerX(), contentRect.bottom, radius, handlePaint)
        canvas.drawCircle(contentRect.left, contentRect.centerY(), radius, handlePaint)
        canvas.drawCircle(contentRect.right, contentRect.centerY(), radius, handlePaint)

        canvas.drawText(settings.formatValue(settings.pageWidthMm), pageRect.centerX(), pageRect.bottom + dp(22f), labelPaint)
        canvas.save()
        canvas.rotate(-90f, pageRect.left - dp(22f), pageRect.centerY())
        canvas.drawText(settings.formatValue(settings.pageHeightMm), pageRect.left - dp(22f), pageRect.centerY(), labelPaint)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                calculateRects()
                activeEdge = closestEdge(event.x, event.y)
                if (activeEdge == Edge.NONE) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (activeEdge == Edge.NONE) return false
                updateMargin(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeEdge = Edge.NONE
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun calculateRects() {
        val horizontalPadding = dp(58f)
        val verticalPadding = dp(30f)
        val availableWidth = (width - horizontalPadding * 2).coerceAtLeast(dp(50f))
        val availableHeight = (height - verticalPadding * 2 - dp(26f)).coerceAtLeast(dp(50f))
        val scale = min(availableWidth / settings.pageWidthMm, availableHeight / settings.pageHeightMm)
        val pageWidth = settings.pageWidthMm * scale
        val pageHeight = settings.pageHeightMm * scale
        val left = (width - pageWidth) / 2f
        val top = (height - pageHeight - dp(18f)) / 2f
        pageRect.set(left, top, left + pageWidth, top + pageHeight)
        contentRect.set(
            pageRect.left + settings.marginLeftMm * scale,
            pageRect.top + settings.marginTopMm * scale,
            pageRect.right - settings.marginRightMm * scale,
            pageRect.bottom - settings.marginBottomMm * scale
        )
    }

    private fun closestEdge(x: Float, y: Float): Edge {
        val threshold = dp(28f)
        val candidates = listOf(
            Edge.LEFT to abs(x - contentRect.left),
            Edge.RIGHT to abs(x - contentRect.right),
            Edge.TOP to abs(y - contentRect.top),
            Edge.BOTTOM to abs(y - contentRect.bottom)
        )
        return candidates.minByOrNull { it.second }?.takeIf { it.second <= threshold }?.first ?: Edge.NONE
    }

    private fun updateMargin(x: Float, y: Float) {
        val scaleX = settings.pageWidthMm / pageRect.width().coerceAtLeast(1f)
        val scaleY = settings.pageHeightMm / pageRect.height().coerceAtLeast(1f)
        settings = when (activeEdge) {
            Edge.LEFT -> settings.copy(marginLeftMm = ((x - pageRect.left) * scaleX).coerceAtLeast(0f))
            Edge.RIGHT -> settings.copy(marginRightMm = ((pageRect.right - x) * scaleX).coerceAtLeast(0f))
            Edge.TOP -> settings.copy(marginTopMm = ((y - pageRect.top) * scaleY).coerceAtLeast(0f))
            Edge.BOTTOM -> settings.copy(marginBottomMm = ((pageRect.bottom - y) * scaleY).coerceAtLeast(0f))
            Edge.NONE -> settings
        }.normalized()
        onMarginsChanged?.invoke(settings)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
    private enum class Edge { NONE, LEFT, TOP, RIGHT, BOTTOM }
}
