package com.geooffice.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.geooffice.app.MainActivity
import com.geooffice.app.databinding.ActivitySpreadsheetBinding
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.office.GeoCellStyleData
import com.geooffice.app.office.GeoSheetData
import com.geooffice.app.office.OpenXmlXlsx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.ui.view.VirtualSpreadsheetView
import com.geooffice.app.util.UriUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.Locale
import kotlin.math.roundToLong

class SpreadsheetActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySpreadsheetBinding
    private val sheets = mutableListOf<SheetState>()
    private var currentSheetIndex = 0
    private var selectedRow = 0
    private var selectedCol = 0
    private var currentUri: Uri? = null
    private var updating = false
    private var disableAutoResumeOnExit = false
    private var pendingSheetIndex = 0
    private var panelExpanded = true
    private var currentPanel = ExcelPanel.HOME
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }

    private val createXlsx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> uri?.let { saveXlsx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpreadsheetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sheets.add(SheetState.create("Hoja 1"))
        setupActions()
        setupVirtualGrid()
        showExcelPanel(ExcelPanel.HOME)
        renderSheet(0)

        val resumeMode = intent.getBooleanExtra(MainActivity.EXTRA_RESUME_SESSION, false)
        pendingSheetIndex = if (resumeMode) resumePrefs.getInt(ResumeSession.SHEET_INDEX, 0) else 0
        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
            val sourceUri = Uri.parse(raw)
            currentUri = if (resumeMode) null else sourceUri
            binding.tvTitle.text = if (resumeMode) "Libro recuperado" else UriUtils.displayName(this, sourceUri)
            loadFile(sourceUri)
        }
    }

    private fun setupActions() = with(binding) {
        btnBack.setOnClickListener { disableResumeAndFinish() }
        btnSave.setOnClickListener {
            commitGridToCurrentSheet()
            val uri = currentUri
            if (uri == null || UriUtils.extension(this@SpreadsheetActivity, uri) != "xlsx") {
                createXlsx.launch(suggestedName("xlsx"))
            } else {
                saveXlsx(uri, false)
            }
        }
        btnExportPdf.setOnClickListener {
            commitGridToCurrentSheet()
            createPdf.launch(suggestedName("pdf"))
        }
        btnApplyFormula.setOnClickListener { applyFormulaBar() }
        btnBold.setOnClickListener { toggleBold() }
        btnItalic.setOnClickListener { toggleItalic() }
        btnTextColor.setOnClickListener { cycleTextColor() }
        btnFillColor.setOnClickListener { cycleFillColor() }
        btnAlign.setOnClickListener { cycleAlignment() }
        btnCurrency.setOnClickListener { setNumberFormat(NumberFormat.CURRENCY) }
        btnPercent.setOnClickListener { setNumberFormat(NumberFormat.PERCENT) }
        btnDecimal.setOnClickListener { setNumberFormat(NumberFormat.DECIMAL) }
        btnCopy.setOnClickListener { copyCell() }
        btnPaste.setOnClickListener { pasteCell() }
        btnClearCell.setOnClickListener { clearSelectedCell() }
        btnInsertRow.setOnClickListener { insertRow() }
        btnDeleteRow.setOnClickListener { deleteRow() }
        btnInsertColumn.setOnClickListener { insertColumn() }
        btnDeleteColumn.setOnClickListener { deleteColumn() }
        btnAddSheet.setOnClickListener { addSheet() }
        btnExcelPanelToggle.setOnClickListener { toggleExcelPanel() }
        tabExcelHome.setOnClickListener { showExcelPanel(ExcelPanel.HOME) }
        tabExcelInsert.setOnClickListener { showExcelPanel(ExcelPanel.INSERT) }
        tabExcelFormula.setOnClickListener { showExcelPanel(ExcelPanel.FORMULA) }
        tabExcelData.setOnClickListener { showExcelPanel(ExcelPanel.DATA) }

        formulaBar.setOnEditorActionListener { _, _, event ->
            if (event == null || event.keyCode == KeyEvent.KEYCODE_ENTER) {
                applyFormulaBar()
                true
            } else false
        }
        formulaBar.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) applyFormulaBar() }
    }

    private fun setupVirtualGrid() = with(binding.spreadsheetView) {
        onCellSelected = { row, col -> selectCell(row, col, reveal = false) }
        onCellDoubleTap = { row, col ->
            selectCell(row, col, reveal = false)
            binding.formulaBar.requestFocus()
            binding.formulaBar.setSelection(binding.formulaBar.length())
        }
    }

    private fun currentSheet(): SheetState = sheets[currentSheetIndex]

    private fun renderSheet(index: Int) {
        if (index !in sheets.indices) return
        commitGridToCurrentSheet()
        currentSheetIndex = index
        val sheet = currentSheet()
        sheet.ensureMinimumSize(MIN_ROWS, MIN_COLS)
        buildGrid(sheet)
        renderSheetTabs()
        selectedRow = selectedRow.coerceIn(0, sheet.rows.lastIndex)
        selectedCol = selectedCol.coerceIn(0, sheet.columnCount - 1)
        selectCell(selectedRow, selectedCol)
    }

    private fun buildGrid(sheet: SheetState) {
        binding.spreadsheetView.rowCount = sheet.rows.size
        binding.spreadsheetView.columnCount = sheet.columnCount
        binding.spreadsheetView.cellTextProvider = { row, col ->
            displayValue(sheet.rows[row][col], sheet.styles[row to col], mutableSetOf())
        }
        binding.spreadsheetView.cellStyleProvider = { row, col ->
            val format = sheet.styles[row to col] ?: CellFormat()
            VirtualSpreadsheetView.CellStyle(
                bold = format.bold,
                italic = format.italic,
                textColor = format.textColor,
                fillColor = format.fillColor,
                alignment = when (format.alignment) {
                    Gravity.CENTER -> VirtualSpreadsheetView.ALIGN_CENTER
                    Gravity.END -> VirtualSpreadsheetView.ALIGN_RIGHT
                    else -> VirtualSpreadsheetView.ALIGN_LEFT
                }
            )
        }
        binding.spreadsheetView.notifyDataChanged()
    }

    private fun selectCell(row: Int, col: Int, reveal: Boolean = true) {
        val sheet = currentSheet()
        if (row !in sheet.rows.indices || col !in 0 until sheet.columnCount) return
        selectedRow = row
        selectedCol = col
        binding.tvCellName.text = columnName(col) + (row + 1)
        val raw = sheet.rows[row][col]
        updating = true
        binding.formulaBar.setText(raw)
        binding.formulaBar.setSelection(binding.formulaBar.length())
        updating = false
        binding.spreadsheetView.setSelectedCell(row, col, reveal)
        refreshToolbarState()
    }

    private fun commitCell(row: Int, col: Int) = Unit

    private fun commitGridToCurrentSheet() = Unit

    private fun applyFormulaBar() {
        if (updating) return
        val sheet = currentSheet()
        if (selectedRow !in sheet.rows.indices || selectedCol !in 0 until sheet.columnCount) return
        val raw = binding.formulaBar.text?.toString().orEmpty()
        sheet.rows[selectedRow][selectedCol] = raw
        binding.spreadsheetView.notifyDataChanged()
        recalculateAll()
    }

    private fun recalculateAll() {
        binding.spreadsheetView.notifyDataChanged()
    }

    private fun displayValue(raw: String, format: CellFormat?, visiting: MutableSet<Pair<Int, Int>>): String {
        val value = if (raw.startsWith("=")) evaluateFormula(raw.drop(1), visiting) else raw.replace(',', '.').toDoubleOrNull()
        return if (value != null) formatNumberForCell(value, format?.numberFormat ?: NumberFormat.NORMAL) else raw
    }

    private fun formatRaw(raw: String, format: NumberFormat): String {
        val number = raw.replace(',', '.').toDoubleOrNull() ?: return raw
        return formatNumberForCell(number, format)
    }

    private fun evaluateFormula(expression: String, visiting: MutableSet<Pair<Int, Int>>): Double {
        val trimmed = expression.trim().uppercase(Locale.ROOT)
        val function = Regex("^(SUM|AVERAGE|MIN|MAX|COUNT)\\(([A-Z]+\\d+):([A-Z]+\\d+)\\)$").matchEntire(trimmed)
        if (function != null) {
            val name = function.groupValues[1]
            val start = parseRef(function.groupValues[2]) ?: return 0.0
            val end = parseRef(function.groupValues[3]) ?: return 0.0
            val values = mutableListOf<Double>()
            for (row in minOf(start.first, end.first)..maxOf(start.first, end.first)) {
                for (col in minOf(start.second, end.second)..maxOf(start.second, end.second)) {
                    values.add(cellNumeric(row, col, visiting))
                }
            }
            return when (name) {
                "SUM" -> values.sum()
                "AVERAGE" -> values.average().takeIf { !it.isNaN() } ?: 0.0
                "MIN" -> values.minOrNull() ?: 0.0
                "MAX" -> values.maxOrNull() ?: 0.0
                "COUNT" -> values.count { it.isFinite() }.toDouble()
                else -> 0.0
            }
        }

        val binary = Regex("^([A-Z]+\\d+|-?\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*([A-Z]+\\d+|-?\\d+(?:\\.\\d+)?)$").matchEntire(trimmed)
        if (binary != null) {
            val left = tokenValue(binary.groupValues[1], visiting)
            val right = tokenValue(binary.groupValues[3], visiting)
            return when (binary.groupValues[2]) {
                "+" -> left + right
                "-" -> left - right
                "*" -> left * right
                "/" -> if (right == 0.0) 0.0 else left / right
                else -> 0.0
            }
        }
        return tokenValue(trimmed, visiting)
    }

    private fun tokenValue(token: String, visiting: MutableSet<Pair<Int, Int>>): Double {
        token.toDoubleOrNull()?.let { return it }
        val ref = parseRef(token) ?: return 0.0
        return cellNumeric(ref.first, ref.second, visiting)
    }

    private fun cellNumeric(row: Int, col: Int, visiting: MutableSet<Pair<Int, Int>>): Double {
        val sheet = currentSheet()
        if (row !in sheet.rows.indices || col !in 0 until sheet.columnCount) return 0.0
        val key = row to col
        if (!visiting.add(key)) return 0.0
        val raw = sheet.rows[row][col]
        val result = if (raw.startsWith("=")) evaluateFormula(raw.drop(1), visiting) else raw.replace(',', '.').toDoubleOrNull() ?: 0.0
        visiting.remove(key)
        return result
    }

    private fun parseRef(ref: String): Pair<Int, Int>? {
        val match = Regex("^([A-Z]+)(\\d+)$").matchEntire(ref.uppercase(Locale.ROOT)) ?: return null
        var col = 0
        match.groupValues[1].forEach { col = col * 26 + (it - 'A' + 1) }
        val row = match.groupValues[2].toIntOrNull()?.minus(1) ?: return null
        return row to (col - 1)
    }

    private fun toggleBold() = updateSelectedFormat { it.bold = !it.bold }
    private fun toggleItalic() = updateSelectedFormat { it.italic = !it.italic }

    private fun cycleTextColor() = updateSelectedFormat { format ->
        val colors = intArrayOf(Color.rgb(26, 32, 44), Color.rgb(37, 99, 235), Color.rgb(220, 38, 38), Color.rgb(22, 163, 74), Color.WHITE)
        format.textColor = colors[((colors.indexOf(format.textColor) + 1) % colors.size)]
    }

    private fun cycleFillColor() = updateSelectedFormat { format ->
        val colors = intArrayOf(Color.TRANSPARENT, Color.rgb(254, 249, 195), Color.rgb(219, 234, 254), Color.rgb(220, 252, 231), Color.rgb(254, 226, 226), Color.rgb(30, 41, 59))
        format.fillColor = colors[((colors.indexOf(format.fillColor) + 1) % colors.size)]
    }

    private fun cycleAlignment() = updateSelectedFormat { format ->
        format.alignment = when (format.alignment) {
            Gravity.START -> Gravity.CENTER
            Gravity.CENTER -> Gravity.END
            else -> Gravity.START
        }
    }

    private fun setNumberFormat(numberFormat: NumberFormat) = updateSelectedFormat { format ->
        format.numberFormat = if (format.numberFormat == numberFormat) NumberFormat.NORMAL else numberFormat
    }

    private fun updateSelectedFormat(block: (CellFormat) -> Unit) {
        val sheet = currentSheet()
        val key = selectedRow to selectedCol
        val format = sheet.styles.getOrPut(key) { CellFormat() }
        block(format)
        binding.spreadsheetView.notifyDataChanged()
        refreshToolbarState()
    }

    private fun refreshToolbarState() {
        val format = currentSheet().styles[selectedRow to selectedCol] ?: CellFormat()
        binding.btnBold.alpha = if (format.bold) 1f else 0.6f
        binding.btnItalic.alpha = if (format.italic) 1f else 0.6f
        binding.btnCurrency.alpha = if (format.numberFormat == NumberFormat.CURRENCY) 1f else 0.6f
        binding.btnPercent.alpha = if (format.numberFormat == NumberFormat.PERCENT) 1f else 0.6f
        binding.btnDecimal.alpha = if (format.numberFormat == NumberFormat.DECIMAL) 1f else 0.6f
    }

    private fun copyCell() {
        val raw = currentSheet().rows[selectedRow][selectedCol]
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Celda Geo Office", raw))
        toast("Celda copiada")
    }

    private fun pasteCell() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isBlank()) return toast("No hay contenido para pegar")
        currentSheet().rows[selectedRow][selectedCol] = text
        binding.formulaBar.setText(text)
        applyFormulaBar()
    }

    private fun clearSelectedCell() {
        currentSheet().rows[selectedRow][selectedCol] = ""
        currentSheet().styles.remove(selectedRow to selectedCol)
        binding.formulaBar.setText("")
        binding.spreadsheetView.notifyDataChanged()
    }

    private fun insertRow() {
        commitGridToCurrentSheet()
        val sheet = currentSheet()
        val index = selectedRow.coerceIn(0, sheet.rows.size)
        sheet.rows.add(index, MutableList(sheet.columnCount) { "" })
        sheet.shiftStylesRows(index, 1)
        renderSheet(currentSheetIndex)
        selectedRow = index
        selectCell(selectedRow, selectedCol)
    }

    private fun deleteRow() {
        val sheet = currentSheet()
        if (sheet.rows.size <= 1) return toast("La hoja debe conservar una fila")
        commitGridToCurrentSheet()
        val index = selectedRow.coerceIn(0, sheet.rows.lastIndex)
        sheet.rows.removeAt(index)
        sheet.shiftStylesRows(index, -1)
        selectedRow = index.coerceAtMost(sheet.rows.lastIndex)
        renderSheet(currentSheetIndex)
    }

    private fun insertColumn() {
        commitGridToCurrentSheet()
        val sheet = currentSheet()
        val index = selectedCol.coerceIn(0, sheet.columnCount)
        sheet.rows.forEach { it.add(index, "") }
        sheet.shiftStylesColumns(index, 1)
        renderSheet(currentSheetIndex)
        selectedCol = index
        selectCell(selectedRow, selectedCol)
    }

    private fun deleteColumn() {
        val sheet = currentSheet()
        if (sheet.columnCount <= 1) return toast("La hoja debe conservar una columna")
        commitGridToCurrentSheet()
        val index = selectedCol.coerceIn(0, sheet.columnCount - 1)
        sheet.rows.forEach { if (index in it.indices) it.removeAt(index) }
        sheet.shiftStylesColumns(index, -1)
        selectedCol = index.coerceAtMost(sheet.columnCount - 1)
        renderSheet(currentSheetIndex)
    }

    private fun addSheet() {
        commitGridToCurrentSheet()
        val newSheet = SheetState.create("Hoja ${sheets.size + 1}")
        sheets.add(newSheet)
        currentSheetIndex = sheets.lastIndex
        selectedRow = 0
        selectedCol = 0
        renderSheet(currentSheetIndex)
    }

    private fun toggleExcelPanel() {
        panelExpanded = !panelExpanded
        val target = if (panelExpanded) (230 * resources.displayMetrics.density).toInt() else 0
        binding.excelPanelContent.layoutParams = binding.excelPanelContent.layoutParams.apply { height = target }
        binding.btnExcelPanelToggle.text = if (panelExpanded) "⌄" else "⌃"
        binding.excelPanelContent.requestLayout()
    }

    private fun showExcelPanel(panel: ExcelPanel) {
        currentPanel = panel
        if (!panelExpanded) toggleExcelPanel()
        binding.excelPanelHome.visibility = if (panel == ExcelPanel.HOME) android.view.View.VISIBLE else android.view.View.GONE
        binding.excelPanelInsert.visibility = if (panel == ExcelPanel.INSERT) android.view.View.VISIBLE else android.view.View.GONE
        binding.excelPanelFormula.visibility = if (panel == ExcelPanel.FORMULA) android.view.View.VISIBLE else android.view.View.GONE
        binding.excelPanelData.visibility = if (panel == ExcelPanel.DATA) android.view.View.VISIBLE else android.view.View.GONE
        binding.tabExcelHome.alpha = if (panel == ExcelPanel.HOME) 1f else 0.58f
        binding.tabExcelInsert.alpha = if (panel == ExcelPanel.INSERT) 1f else 0.58f
        binding.tabExcelFormula.alpha = if (panel == ExcelPanel.FORMULA) 1f else 0.58f
        binding.tabExcelData.alpha = if (panel == ExcelPanel.DATA) 1f else 0.58f
    }

    private fun renderSheetTabs() {
        binding.sheetTabs.removeAllViews()
        sheets.forEachIndexed { index, sheet ->
            val button = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = sheet.name
                isAllCaps = false
                alpha = if (index == currentSheetIndex) 1f else 0.65f
                setOnClickListener { renderSheet(index) }
                setOnLongClickListener {
                    showSheetOptions(index)
                    true
                }
            }
            binding.sheetTabs.addView(button, android.widget.LinearLayout.LayoutParams(110.dp, 44.dp).apply { marginEnd = 6.dp })
        }
    }

    private fun showSheetOptions(index: Int) {
        val options = arrayOf("Renombrar", "Duplicar", "Eliminar")
        MaterialAlertDialogBuilder(this)
            .setTitle(sheets[index].name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> renameSheet(index)
                    1 -> duplicateSheet(index)
                    2 -> deleteSheet(index)
                }
            }
            .show()
    }

    private fun renameSheet(index: Int) {
        val input = EditText(this).apply {
            setText(sheets[index].name)
            setSelection(length())
            setSingleLine(true)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Renombrar hoja")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text?.toString().orEmpty().trim().take(31)
                if (name.isNotBlank()) sheets[index].name = name
                renderSheetTabs()
            }
            .show()
    }

    private fun duplicateSheet(index: Int) {
        commitGridToCurrentSheet()
        val source = sheets[index]
        val copy = SheetState(
            "${source.name} copia".take(31),
            source.rows.map { it.toMutableList() }.toMutableList(),
            source.styles.mapValues { it.value.copy() }.toMutableMap()
        )
        sheets.add(index + 1, copy)
        renderSheet(index + 1)
    }

    private fun deleteSheet(index: Int) {
        if (sheets.size == 1) return toast("Debe existir al menos una hoja")
        sheets.removeAt(index)
        currentSheetIndex = currentSheetIndex.coerceAtMost(sheets.lastIndex)
        renderSheet(currentSheetIndex)
    }

    private fun loadFile(uri: Uri) {
        Thread {
            runCatching {
                when (UriUtils.extension(this, uri)) {
                    "xlsx" -> OpenXmlXlsx.readWorkbook(this, uri)
                    "csv" -> listOf(GeoSheetData("Hoja 1", contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines -> lines.map { parseCsvLine(it) }.toList() }.orEmpty()))
                    else -> emptyList()
                }
            }.onSuccess { loaded ->
                runOnUiThread {
                    if (loaded.isNotEmpty()) {
                        sheets.clear()
                        loaded.forEachIndexed { index, data ->
                            val loadedStyles = data.styles.mapValues { (_, style) -> style.toCellFormat() }.toMutableMap()
                            val state = SheetState(data.name.ifBlank { "Hoja ${index + 1}" }, data.rows.map { it.toMutableList() }.toMutableList(), loadedStyles)
                            state.ensureMinimumSize(MIN_ROWS, MIN_COLS)
                            sheets.add(state)
                        }
                        currentSheetIndex = pendingSheetIndex.coerceIn(0, sheets.lastIndex)
                        selectedRow = 0
                        selectedCol = 0
                        renderSheet(currentSheetIndex)
                    }
                }
            }.onFailure { error -> runOnUiThread { toast("No se pudo abrir: ${error.message}") } }
        }.start()
    }

    private fun saveXlsx(uri: Uri, updateCurrent: Boolean) {
        commitGridToCurrentSheet()
        val snapshot = sheets.map { sheet ->
            GeoSheetData(sheet.name, trimSheetRows(sheet), sheet.styles.mapValues { (_, style) -> style.toGeoStyle() })
        }
        Thread {
            runCatching { OpenXmlXlsx.writeWorkbook(this, uri, snapshot) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        toast("Libro guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}")
                    }
                }
                .onFailure { error -> runOnUiThread { toast("Error: ${error.message}") } }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        commitGridToCurrentSheet()
        val sheet = currentSheet()
        val rows = trimRows(sheet.rows).mapIndexed { row, values ->
            values.mapIndexed { col, raw -> displayValue(raw, sheet.styles[row to col], mutableSetOf()) }
        }
        Thread {
            runCatching { PdfExporter.tableToPdf(this, uri, rows) }
                .onSuccess { runOnUiThread { toast("PDF creado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }


    private fun trimSheetRows(sheet: SheetState): List<List<String>> {
        val valueLastRow = sheet.rows.indexOfLast { row -> row.any { it.isNotBlank() } }
        val styleLastRow = sheet.styles.keys.maxOfOrNull { it.first } ?: -1
        val lastRow = maxOf(valueLastRow, styleLastRow)
        if (lastRow < 0) return listOf(emptyList())
        val valueMaxCol = sheet.rows.take(lastRow + 1).maxOfOrNull { row -> row.indexOfLast { it.isNotBlank() } } ?: -1
        val styleMaxCol = sheet.styles.keys.filter { it.first <= lastRow }.maxOfOrNull { it.second } ?: -1
        val maxCol = maxOf(0, valueMaxCol, styleMaxCol)
        return sheet.rows.take(lastRow + 1).map { row -> row.take(maxCol + 1) }
    }

    private fun trimRows(rows: List<List<String>>): List<List<String>> {
        var lastRow = rows.indexOfLast { row -> row.any { it.isNotBlank() } }
        if (lastRow < 0) return listOf(emptyList())
        val maxCol = rows.take(lastRow + 1).maxOfOrNull { row -> row.indexOfLast { it.isNotBlank() } }?.coerceAtLeast(0) ?: 0
        return rows.take(lastRow + 1).map { row -> row.take(maxCol + 1) }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var index = 0
        while (index < line.length) {
            val ch = line[index]
            when {
                ch == '"' && quoted && index + 1 < line.length && line[index + 1] == '"' -> { current.append('"'); index++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { result.add(current.toString()); current.clear() }
                else -> current.append(ch)
            }
            index++
        }
        result.add(current.toString())
        return result
    }

    private fun formatNumberForCell(value: Double, format: NumberFormat): String {
        if (!value.isFinite()) return "0"
        return when (format) {
            NumberFormat.CURRENCY -> String.format(Locale("es", "PE"), "S/ %.2f", value)
            NumberFormat.PERCENT -> String.format(Locale("es", "PE"), "%.2f%%", value * 100.0)
            NumberFormat.DECIMAL -> String.format(Locale("es", "PE"), "%.2f", value)
            NumberFormat.NORMAL -> formatNumber(value)
        }
    }

    private fun formatNumber(value: Double): String {
        return if (kotlin.math.abs(value - value.roundToLong()) < 0.0000001) value.roundToLong().toString()
        else String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val result = StringBuilder()
        while (n > 0) {
            result.append(('A'.code + (n - 1) % 26).toChar())
            n = (n - 1) / 26
        }
        return result.reverse().toString()
    }


    override fun onPause() {
        super.onPause()
        if (disableAutoResumeOnExit || sheets.isEmpty()) {
            resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
            return
        }
        commitGridToCurrentSheet()
        runCatching {
            val directory = File(cacheDir, "resume").apply { mkdirs() }
            val file = File(directory, "spreadsheet_session.xlsx")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val snapshot = sheets.map { sheet ->
                GeoSheetData(sheet.name, trimSheetRows(sheet), sheet.styles.mapValues { (_, style) -> style.toGeoStyle() })
            }
            OpenXmlXlsx.writeWorkbook(this, uri, snapshot)
            resumePrefs.edit()
                .putBoolean(ResumeSession.AUTO_RESUME, true)
                .putString(ResumeSession.LAST_SCREEN, ResumeSession.SCREEN_SPREADSHEET)
                .putString(ResumeSession.SHEET_SESSION_URI, uri.toString())
                .putInt(ResumeSession.SHEET_INDEX, currentSheetIndex)
                .apply()
        }
    }

    private fun disableResumeAndFinish() {
        disableAutoResumeOnExit = true
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
        finish()
    }


    private fun CellFormat.toGeoStyle(): GeoCellStyleData = GeoCellStyleData(
        bold = bold,
        italic = italic,
        textColor = textColor,
        fillColor = fillColor,
        alignment = when (alignment) {
            Gravity.CENTER -> "center"
            Gravity.END -> "right"
            else -> "left"
        },
        numberFormat = when (numberFormat) {
            NumberFormat.CURRENCY -> "currency"
            NumberFormat.PERCENT -> "percent"
            NumberFormat.DECIMAL -> "decimal"
            NumberFormat.NORMAL -> "normal"
        }
    )

    private fun GeoCellStyleData.toCellFormat(): CellFormat = CellFormat(
        bold = bold,
        italic = italic,
        textColor = textColor,
        fillColor = fillColor,
        alignment = when (alignment) {
            "center" -> Gravity.CENTER
            "right" -> Gravity.END
            else -> Gravity.START
        },
        numberFormat = when (numberFormat) {
            "currency" -> NumberFormat.CURRENCY
            "percent" -> NumberFormat.PERCENT
            "decimal" -> NumberFormat.DECIMAL
            else -> NumberFormat.NORMAL
        }
    )

    private fun suggestedName(extension: String): String {
        val base = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${base?.takeIf { it.isNotBlank() } ?: "Hoja Geo Office"}.$extension"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    private data class SheetState(
        var name: String,
        val rows: MutableList<MutableList<String>>,
        val styles: MutableMap<Pair<Int, Int>, CellFormat>
    ) {
        val columnCount: Int get() = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1

        fun ensureMinimumSize(minRows: Int, minCols: Int) {
            while (rows.size < minRows) rows.add(MutableList(maxOf(minCols, columnCount)) { "" })
            val requiredCols = maxOf(minCols, columnCount)
            rows.forEach { row -> while (row.size < requiredCols) row.add("") }
        }

        fun shiftStylesRows(start: Int, delta: Int) {
            val updated = mutableMapOf<Pair<Int, Int>, CellFormat>()
            styles.forEach { (key, value) ->
                val row = key.first
                val col = key.second
                when {
                    delta > 0 && row >= start -> updated[(row + delta) to col] = value
                    delta < 0 && row == start -> Unit
                    delta < 0 && row > start -> updated[(row + delta) to col] = value
                    else -> updated[key] = value
                }
            }
            styles.clear(); styles.putAll(updated)
        }

        fun shiftStylesColumns(start: Int, delta: Int) {
            val updated = mutableMapOf<Pair<Int, Int>, CellFormat>()
            styles.forEach { (key, value) ->
                val row = key.first
                val col = key.second
                when {
                    delta > 0 && col >= start -> updated[row to (col + delta)] = value
                    delta < 0 && col == start -> Unit
                    delta < 0 && col > start -> updated[row to (col + delta)] = value
                    else -> updated[key] = value
                }
            }
            styles.clear(); styles.putAll(updated)
        }

        companion object {
            fun create(name: String) = SheetState(name, MutableList(MIN_ROWS) { MutableList(MIN_COLS) { "" } }, mutableMapOf())
        }
    }

    private data class CellFormat(
        var bold: Boolean = false,
        var italic: Boolean = false,
        var textColor: Int = Color.rgb(26, 32, 44),
        var fillColor: Int = Color.TRANSPARENT,
        var alignment: Int = Gravity.START,
        var numberFormat: NumberFormat = NumberFormat.NORMAL
    )

    private enum class NumberFormat { NORMAL, CURRENCY, PERCENT, DECIMAL }
    private enum class ExcelPanel { HOME, INSERT, FORMULA, DATA }

    companion object {
        private const val MIN_ROWS = 40
        private const val MIN_COLS = 10
        private const val CELL_WIDTH = 118
        private const val CELL_HEIGHT = 50
    }
}
