package com.geooffice.app.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.OverScroller
import androidx.core.view.ViewCompat
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class VirtualSpreadsheetView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class CellStyle(
        val bold: Boolean = false,
        val italic: Boolean = false,
        val textColor: Int = Color.rgb(24, 32, 43),
        val fillColor: Int = Color.WHITE,
        val alignment: Int = ALIGN_LEFT
    )

    var rowCount: Int = 40
        set(value) { field = max(1, value); clampOffsets(); invalidate() }
    var columnCount: Int = 10
        set(value) { field = max(1, value); clampOffsets(); invalidate() }

    var cellTextProvider: ((Int, Int) -> String)? = null
    var cellStyleProvider: ((Int, Int) -> CellStyle)? = null
    var onCellSelected: ((Int, Int) -> Unit)? = null
    var onCellDoubleTap: ((Int, Int) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14f * resources.displayMetrics.scaledDensity
        color = Color.rgb(24, 32, 43)
    }
    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(231, 243, 235)
    }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 214, 225)
        strokeWidth = max(1f, density)
        style = Paint.Style.STROKE
    }
    private val selectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(36, 117, 255)
        strokeWidth = 2.5f * density
        style = Paint.Style.STROKE
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(36, 117, 255)
        style = Paint.Style.FILL
    }

    private val scroller = OverScroller(context)
    private val gestureDetector = GestureDetector(context, GestureListener())
    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())

    private var baseCellWidth = 118f * density
    private var baseCellHeight = 50f * density
    private var zoom = 1f
    private val rowHeaderWidth = 56f * density
    private val columnHeaderHeight = 44f * density
    private var offsetX = 0f
    private var offsetY = 0f
    private var selectedRow = 0
    private var selectedCol = 0

    val cellWidth: Float get() = baseCellWidth * zoom
    val cellHeight: Float get() = baseCellHeight * zoom

    init {
        isFocusable = true
        isClickable = true
        setBackgroundColor(Color.rgb(248, 250, 252))
    }

    fun setSelectedCell(row: Int, col: Int, reveal: Boolean = true) {
        selectedRow = row.coerceIn(0, rowCount - 1)
        selectedCol = col.coerceIn(0, columnCount - 1)
        if (reveal) revealSelectedCell()
        invalidate()
    }

    fun notifyDataChanged() {
        clampOffsets()
        invalidate()
    }

    fun getSelectedRow(): Int = selectedRow
    fun getSelectedColumn(): Int = selectedCol

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(248, 250, 252))

        val firstCol = floor(offsetX / cellWidth).toInt().coerceAtLeast(0)
        val firstRow = floor(offsetY / cellHeight).toInt().coerceAtLeast(0)
        val visibleCols = ceil((width - rowHeaderWidth) / cellWidth).toInt() + 2
        val visibleRows = ceil((height - columnHeaderHeight) / cellHeight).toInt() + 2
        val lastCol = min(columnCount - 1, firstCol + visibleCols)
        val lastRow = min(rowCount - 1, firstRow + visibleRows)

        bodyPaint.color = Color.WHITE
        canvas.drawRect(rowHeaderWidth, columnHeaderHeight, width.toFloat(), height.toFloat(), bodyPaint)

        for (row in firstRow..lastRow) {
            val top = columnHeaderHeight + row * cellHeight - offsetY
            val bottom = top + cellHeight
            if (bottom < columnHeaderHeight || top > height) continue
            headerPaint.color = Color.rgb(231, 243, 235)
            canvas.drawRect(0f, top, rowHeaderWidth, bottom, headerPaint)
            drawCenteredText(canvas, (row + 1).toString(), 0f, top, rowHeaderWidth, bottom, true, Color.rgb(27, 42, 58))

            for (col in firstCol..lastCol) {
                val left = rowHeaderWidth + col * cellWidth - offsetX
                val right = left + cellWidth
                if (right < rowHeaderWidth || left > width) continue
                val style = cellStyleProvider?.invoke(row, col) ?: CellStyle()
                bodyPaint.color = if (style.fillColor == Color.TRANSPARENT) Color.WHITE else style.fillColor
                canvas.drawRect(left, top, right, bottom, bodyPaint)
                canvas.drawRect(left, top, right, bottom, gridPaint)
                drawCellText(canvas, cellTextProvider?.invoke(row, col).orEmpty(), left, top, right, bottom, style)
            }
        }

        headerPaint.color = Color.rgb(231, 243, 235)
        canvas.drawRect(0f, 0f, width.toFloat(), columnHeaderHeight, headerPaint)
        canvas.drawRect(0f, 0f, rowHeaderWidth, height.toFloat(), headerPaint)
        canvas.drawRect(0f, 0f, rowHeaderWidth, columnHeaderHeight, gridPaint)

        for (col in firstCol..lastCol) {
            val left = rowHeaderWidth + col * cellWidth - offsetX
            val right = left + cellWidth
            if (right < rowHeaderWidth || left > width) continue
            canvas.drawRect(left, 0f, right, columnHeaderHeight, gridPaint)
            drawCenteredText(canvas, columnName(col), left, 0f, right, columnHeaderHeight, true, Color.rgb(27, 42, 58))
        }

        val selectedLeft = rowHeaderWidth + selectedCol * cellWidth - offsetX
        val selectedTop = columnHeaderHeight + selectedRow * cellHeight - offsetY
        val selectedRight = selectedLeft + cellWidth
        val selectedBottom = selectedTop + cellHeight
        if (selectedRight >= rowHeaderWidth && selectedLeft <= width && selectedBottom >= columnHeaderHeight && selectedTop <= height) {
            canvas.drawRect(selectedLeft, selectedTop, selectedRight, selectedBottom, selectionPaint)
            canvas.drawCircle(selectedRight, selectedBottom, 4.5f * density, handlePaint)
        }
    }

    private fun drawCellText(canvas: Canvas, value: String, left: Float, top: Float, right: Float, bottom: Float, style: CellStyle) {
        textPaint.color = style.textColor
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, when {
            style.bold && style.italic -> Typeface.BOLD_ITALIC
            style.bold -> Typeface.BOLD
            style.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        })
        textPaint.textSize = 14f * resources.displayMetrics.scaledDensity * zoom.coerceIn(0.85f, 1.35f)
        val padding = 10f * density
        val available = max(1f, right - left - padding * 2)
        val text = ellipsize(value, available)
        val x = when (style.alignment) {
            ALIGN_CENTER -> (left + right) / 2f - textPaint.measureText(text) / 2f
            ALIGN_RIGHT -> right - padding - textPaint.measureText(text)
            else -> left + padding
        }
        val y = (top + bottom) / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        canvas.save()
        canvas.clipRect(left + 1, top + 1, right - 1, bottom - 1)
        canvas.drawText(text, x, y, textPaint)
        canvas.restore()
    }

    private fun drawCenteredText(canvas: Canvas, value: String, left: Float, top: Float, right: Float, bottom: Float, bold: Boolean, color: Int) {
        textPaint.color = color
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
        val x = (left + right) / 2f - textPaint.measureText(value) / 2f
        val y = (top + bottom) / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        canvas.drawText(value, x, y, textPaint)
    }

    private fun ellipsize(value: String, maxWidth: Float): String {
        if (textPaint.measureText(value) <= maxWidth) return value
        val ellipsis = "…"
        var end = value.length
        while (end > 0 && textPaint.measureText(value.substring(0, end) + ellipsis) > maxWidth) end--
        return if (end <= 0) ellipsis else value.substring(0, end) + ellipsis
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            offsetX = scroller.currX.toFloat()
            offsetY = scroller.currY.toFloat()
            ViewCompat.postInvalidateOnAnimation(this)
        }
    }

    private fun selectAt(x: Float, y: Float, doubleTap: Boolean) {
        if (x < rowHeaderWidth || y < columnHeaderHeight) return
        val col = floor((x - rowHeaderWidth + offsetX) / cellWidth).toInt().coerceIn(0, columnCount - 1)
        val row = floor((y - columnHeaderHeight + offsetY) / cellHeight).toInt().coerceIn(0, rowCount - 1)
        selectedRow = row
        selectedCol = col
        onCellSelected?.invoke(row, col)
        if (doubleTap) onCellDoubleTap?.invoke(row, col)
        invalidate()
    }

    private fun revealSelectedCell() {
        val left = selectedCol * cellWidth
        val right = left + cellWidth
        val top = selectedRow * cellHeight
        val bottom = top + cellHeight
        val viewportWidth = max(1f, width - rowHeaderWidth)
        val viewportHeight = max(1f, height - columnHeaderHeight)
        if (left < offsetX) offsetX = left
        if (right > offsetX + viewportWidth) offsetX = right - viewportWidth
        if (top < offsetY) offsetY = top
        if (bottom > offsetY + viewportHeight) offsetY = bottom - viewportHeight
        clampOffsets()
    }

    private fun clampOffsets() {
        val maxX = max(0f, columnCount * cellWidth - max(0f, width - rowHeaderWidth))
        val maxY = max(0f, rowCount * cellHeight - max(0f, height - columnHeaderHeight))
        offsetX = offsetX.coerceIn(0f, maxX)
        offsetY = offsetY.coerceIn(0f, maxY)
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            if (!scroller.isFinished) scroller.abortAnimation()
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            selectAt(e.x, e.y, false)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            selectAt(e.x, e.y, true)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (scaleDetector.isInProgress) return false
            offsetX += distanceX
            offsetY += distanceY
            clampOffsets()
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            val maxX = max(0, (columnCount * cellWidth - max(0f, width - rowHeaderWidth)).toInt())
            val maxY = max(0, (rowCount * cellHeight - max(0f, height - columnHeaderHeight)).toInt())
            scroller.fling(offsetX.toInt(), offsetY.toInt(), -velocityX.toInt(), -velocityY.toInt(), 0, maxX, 0, maxY)
            ViewCompat.postInvalidateOnAnimation(this@VirtualSpreadsheetView)
            return true
        }
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val oldWidth = cellWidth
            val oldHeight = cellHeight
            val contentX = (offsetX + detector.focusX - rowHeaderWidth) / oldWidth
            val contentY = (offsetY + detector.focusY - columnHeaderHeight) / oldHeight
            zoom = (zoom * detector.scaleFactor).coerceIn(0.72f, 1.65f)
            offsetX = contentX * cellWidth - detector.focusX + rowHeaderWidth
            offsetY = contentY * cellHeight - detector.focusY + columnHeaderHeight
            clampOffsets()
            invalidate()
            return true
        }
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val result = StringBuilder()
        while (n > 0) {
            result.append(('A'.code + (n - 1) % 26).toChar())
            n = (n - 1) / 26
        }
        return result.reverse().toString()
    }

    companion object {
        const val ALIGN_LEFT = 0
        const val ALIGN_CENTER = 1
        const val ALIGN_RIGHT = 2
    }
}
