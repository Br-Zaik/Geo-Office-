package com.geooffice.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.R
import com.geooffice.app.databinding.ActivityPageSetupBinding
import com.geooffice.app.page.MeasurementUnit
import com.geooffice.app.page.PageOrientation
import com.geooffice.app.page.PageSettings
import com.geooffice.app.page.PageSettingsStore
import com.geooffice.app.page.PaperSize
import kotlin.math.roundToInt

class PageSetupActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPageSetupBinding
    private var settings = PageSettings()
    private var internalUpdate = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPageSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = PageSettings.fromIntent(intent, PageSettingsStore.load(this))
        setupPaperMenu()
        setupListeners()
        renderAll()
    }

    private fun setupPaperMenu() {
        val labels = PaperSize.entries.map { it.label }
        binding.inputPaper.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, labels))
        binding.inputPaper.setOnItemClickListener { _, _, position, _ ->
            settings = settings.copy(paper = PaperSize.entries[position]).normalized()
            updateSliderRanges()
            renderAll()
        }
    }

    private fun setupListeners() = with(binding) {
        btnBack.setOnClickListener { finish() }
        btnSave.setOnClickListener {
            val result = Intent().also { settings.normalized().putInto(it) }
            PageSettingsStore.save(this@PageSetupActivity, settings)
            setResult(Activity.RESULT_OK, result)
            finish()
        }
        orientationGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || internalUpdate) return@addOnButtonCheckedListener
            settings = settings.copy(
                orientation = if (checkedId == R.id.btnLandscape) PageOrientation.LANDSCAPE else PageOrientation.PORTRAIT
            ).normalized()
            updateSliderRanges()
            renderAll()
        }
        unitGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || internalUpdate) return@addOnButtonCheckedListener
            settings = settings.copy(
                unit = if (checkedId == R.id.btnInches) MeasurementUnit.INCHES else MeasurementUnit.CENTIMETERS
            )
            updateSliderRanges()
            renderAll()
        }
        sliderTop.addOnChangeListener { _, value, fromUser -> if (fromUser && !internalUpdate) updateMargin(Margin.TOP, displayToMm(value)) }
        sliderBottom.addOnChangeListener { _, value, fromUser -> if (fromUser && !internalUpdate) updateMargin(Margin.BOTTOM, displayToMm(value)) }
        sliderLeft.addOnChangeListener { _, value, fromUser -> if (fromUser && !internalUpdate) updateMargin(Margin.LEFT, displayToMm(value)) }
        sliderRight.addOnChangeListener { _, value, fromUser -> if (fromUser && !internalUpdate) updateMargin(Margin.RIGHT, displayToMm(value)) }
        pagePreview.onMarginsChanged = { changed ->
            settings = changed.copy(unit = settings.unit)
            renderMarginsOnly()
        }
        btnResetMargins.setOnClickListener {
            settings = settings.copy(
                marginLeftMm = 25.4f,
                marginTopMm = 25.4f,
                marginRightMm = 25.4f,
                marginBottomMm = 25.4f
            ).normalized()
            renderAll()
        }
    }

    private fun updateMargin(margin: Margin, valueMm: Float) {
        settings = when (margin) {
            Margin.LEFT -> settings.copy(marginLeftMm = valueMm)
            Margin.TOP -> settings.copy(marginTopMm = valueMm)
            Margin.RIGHT -> settings.copy(marginRightMm = valueMm)
            Margin.BOTTOM -> settings.copy(marginBottomMm = valueMm)
        }.normalized()
        binding.pagePreview.settings = settings
        renderLabels()
    }

    private fun renderAll() {
        internalUpdate = true
        binding.inputPaper.setText(settings.paper.label, false)
        binding.orientationGroup.check(if (settings.orientation == PageOrientation.LANDSCAPE) R.id.btnLandscape else R.id.btnPortrait)
        binding.unitGroup.check(if (settings.unit == MeasurementUnit.INCHES) R.id.btnInches else R.id.btnCm)
        updateSliderRanges()
        setSliderValues()
        binding.pagePreview.settings = settings
        renderLabels()
        internalUpdate = false
    }

    private fun renderMarginsOnly() {
        internalUpdate = true
        setSliderValues()
        renderLabels()
        internalUpdate = false
    }

    private fun updateSliderRanges() {
        listOf(binding.sliderLeft, binding.sliderRight, binding.sliderTop, binding.sliderBottom).forEach { slider ->
            slider.value = slider.valueFrom
            slider.stepSize = 0f
        }
        val maxHorizontalMm = (settings.pageWidthMm / 2f - 5f).coerceAtLeast(10f)
        val maxVerticalMm = (settings.pageHeightMm / 2f - 5f).coerceAtLeast(10f)
        binding.sliderLeft.valueTo = mmToDisplay(maxHorizontalMm).coerceAtLeast(1f)
        binding.sliderRight.valueTo = binding.sliderLeft.valueTo
        binding.sliderTop.valueTo = mmToDisplay(maxVerticalMm).coerceAtLeast(1f)
        binding.sliderBottom.valueTo = binding.sliderTop.valueTo
    }

    private fun setSliderValues() {
        binding.sliderLeft.value = mmToDisplay(settings.marginLeftMm).coerceIn(binding.sliderLeft.valueFrom, binding.sliderLeft.valueTo)
        binding.sliderRight.value = mmToDisplay(settings.marginRightMm).coerceIn(binding.sliderRight.valueFrom, binding.sliderRight.valueTo)
        binding.sliderTop.value = mmToDisplay(settings.marginTopMm).coerceIn(binding.sliderTop.valueFrom, binding.sliderTop.valueTo)
        binding.sliderBottom.value = mmToDisplay(settings.marginBottomMm).coerceIn(binding.sliderBottom.valueFrom, binding.sliderBottom.valueTo)
    }

    private fun renderLabels() {
        binding.tvTopMargin.text = "Superior: ${settings.formatValue(settings.marginTopMm)}"
        binding.tvBottomMargin.text = "Inferior: ${settings.formatValue(settings.marginBottomMm)}"
        binding.tvLeftMargin.text = "Izquierdo: ${settings.formatValue(settings.marginLeftMm)}"
        binding.tvRightMargin.text = "Derecho: ${settings.formatValue(settings.marginRightMm)}"
    }

    private fun mmToDisplay(mm: Float): Float = when (settings.unit) {
        MeasurementUnit.CENTIMETERS -> ((mm / 10f) * 10f).roundToInt() / 10f
        MeasurementUnit.INCHES -> ((mm / 25.4f) * 20f).roundToInt() / 20f
    }

    private fun displayToMm(value: Float): Float = when (settings.unit) {
        MeasurementUnit.CENTIMETERS -> value * 10f
        MeasurementUnit.INCHES -> value * 25.4f
    }

    private enum class Margin { LEFT, TOP, RIGHT, BOTTOM }

    companion object {
        fun createIntent(context: Context, settings: PageSettings): Intent =
            Intent(context, PageSetupActivity::class.java).also { settings.putInto(it) }
    }
}
