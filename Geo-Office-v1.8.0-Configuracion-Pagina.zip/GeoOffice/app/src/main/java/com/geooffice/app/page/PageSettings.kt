package com.geooffice.app.page

import android.content.Context
import android.content.Intent
import kotlin.math.roundToInt

/** Configuración física de la hoja usada por el editor y los exportadores. */
data class PageSettings(
    val paper: PaperSize = PaperSize.A4,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val unit: MeasurementUnit = MeasurementUnit.CENTIMETERS,
    val marginLeftMm: Float = 25.4f,
    val marginTopMm: Float = 25.4f,
    val marginRightMm: Float = 25.4f,
    val marginBottomMm: Float = 25.4f
) {
    val pageWidthMm: Float
        get() = if (orientation == PageOrientation.PORTRAIT) paper.widthMm else paper.heightMm

    val pageHeightMm: Float
        get() = if (orientation == PageOrientation.PORTRAIT) paper.heightMm else paper.widthMm

    val pageWidthPoints: Int
        get() = mmToPoints(pageWidthMm)

    val pageHeightPoints: Int
        get() = mmToPoints(pageHeightMm)

    fun normalized(): PageSettings {
        val maxHorizontal = (pageWidthMm / 2f - 5f).coerceAtLeast(0f)
        val maxVertical = (pageHeightMm / 2f - 5f).coerceAtLeast(0f)
        return copy(
            marginLeftMm = marginLeftMm.coerceIn(0f, maxHorizontal),
            marginRightMm = marginRightMm.coerceIn(0f, maxHorizontal),
            marginTopMm = marginTopMm.coerceIn(0f, maxVertical),
            marginBottomMm = marginBottomMm.coerceIn(0f, maxVertical)
        )
    }

    fun summary(): String {
        val orientationLabel = if (orientation == PageOrientation.PORTRAIT) "Vertical" else "Horizontal"
        val equalMargins = listOf(marginTopMm, marginRightMm, marginBottomMm).all { kotlin.math.abs(it - marginLeftMm) < 0.2f }
        val marginLabel = if (equalMargins) {
            "márgenes ${formatValue(marginLeftMm, unit)}"
        } else {
            "I ${formatValue(marginLeftMm, unit)} · S ${formatValue(marginTopMm, unit)} · D ${formatValue(marginRightMm, unit)} · Inf ${formatValue(marginBottomMm, unit)}"
        }
        return "${paper.label} · $orientationLabel · $marginLabel"
    }

    fun formatValue(mm: Float, selectedUnit: MeasurementUnit = unit): String {
        return when (selectedUnit) {
            MeasurementUnit.CENTIMETERS -> "${formatNumber(mm / 10f)} cm"
            MeasurementUnit.INCHES -> "${formatNumber(mm / 25.4f)} in"
        }
    }

    fun putInto(intent: Intent): Intent = intent.apply {
        putExtra(EXTRA_PAPER, paper.name)
        putExtra(EXTRA_ORIENTATION, orientation.name)
        putExtra(EXTRA_UNIT, unit.name)
        putExtra(EXTRA_LEFT, marginLeftMm)
        putExtra(EXTRA_TOP, marginTopMm)
        putExtra(EXTRA_RIGHT, marginRightMm)
        putExtra(EXTRA_BOTTOM, marginBottomMm)
    }

    companion object {
        const val EXTRA_PAPER = "page_paper"
        const val EXTRA_ORIENTATION = "page_orientation"
        const val EXTRA_UNIT = "page_unit"
        const val EXTRA_LEFT = "page_margin_left"
        const val EXTRA_TOP = "page_margin_top"
        const val EXTRA_RIGHT = "page_margin_right"
        const val EXTRA_BOTTOM = "page_margin_bottom"

        fun fromIntent(intent: Intent?, fallback: PageSettings = PageSettings()): PageSettings {
            if (intent == null) return fallback
            return PageSettings(
                paper = enumValueOrDefault(intent.getStringExtra(EXTRA_PAPER), fallback.paper),
                orientation = enumValueOrDefault(intent.getStringExtra(EXTRA_ORIENTATION), fallback.orientation),
                unit = enumValueOrDefault(intent.getStringExtra(EXTRA_UNIT), fallback.unit),
                marginLeftMm = intent.getFloatExtra(EXTRA_LEFT, fallback.marginLeftMm),
                marginTopMm = intent.getFloatExtra(EXTRA_TOP, fallback.marginTopMm),
                marginRightMm = intent.getFloatExtra(EXTRA_RIGHT, fallback.marginRightMm),
                marginBottomMm = intent.getFloatExtra(EXTRA_BOTTOM, fallback.marginBottomMm)
            ).normalized()
        }

        private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, fallback: T): T {
            return runCatching { enumValueOf<T>(raw.orEmpty()) }.getOrDefault(fallback)
        }

        private fun mmToPoints(mm: Float): Int = ((mm / 25.4f) * 72f).roundToInt().coerceAtLeast(1)

        private fun formatNumber(value: Float): String {
            val rounded = (value * 10f).roundToInt() / 10f
            return if (rounded % 1f == 0f) rounded.toInt().toString() else "%.1f".format(rounded)
        }
    }
}

enum class PageOrientation { PORTRAIT, LANDSCAPE }
enum class MeasurementUnit { CENTIMETERS, INCHES }

enum class PaperSize(val label: String, val widthMm: Float, val heightMm: Float) {
    A3("A3", 297f, 420f),
    A4("A4", 210f, 297f),
    A5("A5", 148f, 210f),
    B4("B4", 250f, 353f),
    B5("B5", 176f, 250f),
    LETTER("Carta", 215.9f, 279.4f),
    TABLOID("Tabloide", 279.4f, 431.8f),
    DOUBLE_LETTER("Doble carta", 279.4f, 431.8f),
    LEGAL("Oficio", 215.9f, 355.6f),
    EXECUTIVE("Ejecutivo", 184.2f, 266.7f),
    FOLIO("Folio", 210f, 330f),
    QUARTO("Cuarto", 215f, 275f)
}

object PageSettingsStore {
    private const val PREFS = "geo_office_page_settings"

    fun load(context: Context): PageSettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return PageSettings(
            paper = runCatching { PaperSize.valueOf(prefs.getString("paper", PaperSize.A4.name).orEmpty()) }.getOrDefault(PaperSize.A4),
            orientation = runCatching { PageOrientation.valueOf(prefs.getString("orientation", PageOrientation.PORTRAIT.name).orEmpty()) }.getOrDefault(PageOrientation.PORTRAIT),
            unit = runCatching { MeasurementUnit.valueOf(prefs.getString("unit", MeasurementUnit.CENTIMETERS.name).orEmpty()) }.getOrDefault(MeasurementUnit.CENTIMETERS),
            marginLeftMm = prefs.getFloat("left", 25.4f),
            marginTopMm = prefs.getFloat("top", 25.4f),
            marginRightMm = prefs.getFloat("right", 25.4f),
            marginBottomMm = prefs.getFloat("bottom", 25.4f)
        ).normalized()
    }

    fun save(context: Context, settings: PageSettings) {
        val value = settings.normalized()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("paper", value.paper.name)
            .putString("orientation", value.orientation.name)
            .putString("unit", value.unit.name)
            .putFloat("left", value.marginLeftMm)
            .putFloat("top", value.marginTopMm)
            .putFloat("right", value.marginRightMm)
            .putFloat("bottom", value.marginBottomMm)
            .apply()
    }
}
