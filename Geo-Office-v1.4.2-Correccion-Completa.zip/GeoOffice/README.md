# Geo Office 1.3.0

Aplicación Android ligera, local y sin inicio de sesión para documentos, PDF y OCR.

## Novedades principales

### Contraseña real para PDF
- **Imágenes a PDF** ahora solicita nombre, contraseña y confirmación antes de crear el archivo.
- El PDF resultante queda cifrado y pide la contraseña al abrirse.
- Nueva herramienta **Proteger PDF con contraseña** para crear una copia protegida de un PDF existente.
- La contraseña debe tener entre 4 y 127 caracteres.
- La app no almacena la contraseña ni puede recuperarla si se olvida.

La protección se realiza localmente mediante PDFBox-Android; los archivos no se suben a internet.

### Zoom y recuperación
- Zoom con dos dedos, desplazamiento y doble toque en OCR y PDF.
- Zoom por pellizco en el editor de documentos.
- Recuperación de la última sesión de Word, OCR y PDF al volver a abrir la app.

### Editor y OCR
- Formato de texto, listas, imágenes, tablas básicas, búsqueda, guardado DOCX/TXT y exportación PDF.
- OCR de varias imágenes, giro, blanco y negro, contraste, copia, compartir y exportación.

## Compatibilidad

La app está orientada a documentos normales y ligeros. Macros, animaciones avanzadas, fórmulas muy complejas y maquetación editorial extrema todavía no están incluidas.

## Compilación

El ZIP contiene el proyecto Android Studio completo y `gradlew`. GitHub Actions compila con Java 17 y Android SDK 35.

## Novedades 1.4.0

- Imágenes a PDF procesa las fotos una por una, sin límite artificial por cantidad o peso.
- Modo predeterminado **Mínimo peso**.
- Modos: mínimo, equilibrado, alta calidad y calidad original.
- Estimación del tamaño antes de convertir, con tamaño original y ahorro aproximado.
- Tamaño final real y ahorro real al terminar.
- PDF creado desde imágenes continúa protegido con contraseña obligatoria.
- Compresión de PDF existente con estimación previa y resultado final real.

## Versión 1.4.2

- Corrige de forma global el acceso nullable al contenido del editor Word.
- Centraliza todas las operaciones de formato, inserción, búsqueda, listas, guardado y autoguardado sobre un `Editable` no nulo.
- Evita la cadena de errores de compilación que aparecía línea por línea en `DocumentEditorActivity.kt`.

