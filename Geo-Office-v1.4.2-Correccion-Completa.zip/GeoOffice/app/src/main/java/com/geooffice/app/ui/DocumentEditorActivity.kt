package com.geooffice.app.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.Html
import android.text.Layout
import android.text.Selection
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.geooffice.app.MainActivity
import com.geooffice.app.R
import com.geooffice.app.databinding.ActivityDocumentEditorBinding
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.editor.GeoImageSpan
import com.geooffice.app.office.OpenXmlDocx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.util.UriUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class DocumentEditorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDocumentEditorBinding

    /**
     * Android declara EditText.getText() como nullable para interoperabilidad Java,
     * pero una vez inflada esta pantalla el editor siempre mantiene un Editable.
     * Centralizar el acceso evita errores de compilación y llamadas inseguras.
     */
    private val editorContent: Editable
        get() = requireNotNull(binding.editor.text) { "El contenido del editor no está disponible" }
    private var currentUri: Uri? = null
    private var currentTextSizeSp = 16
    private var dirty = false
    private var internalChange = false
    private var keepScreenOn = false
    private var lineSpacingIndex = 0
    private val lineSpacings = floatArrayOf(1.0f, 1.15f, 1.5f, 2.0f)
    private val undoStack = ArrayDeque<EditorSnapshot>()
    private val redoStack = ArrayDeque<EditorSnapshot>()
    private var beforeSnapshot: EditorSnapshot? = null
    private var lastChangeStart = 0
    private var lastInsertedCount = 0
    private var pendingBold = false
    private var pendingItalic = false
    private var pendingUnderline = false
    private var pendingStrike = false
    private var pendingForeground: Int? = null
    private var pendingBackground: Int? = null
    private var pendingSizeSp: Int? = null
    private var pendingFontFamily: String? = null
    private var currentPanel = Panel.HOME
    private var disableAutoResumeOnExit = false
    private val prefs by lazy { getSharedPreferences("geo_office_editor", MODE_PRIVATE) }
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }

    private val createDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri -> uri?.let { saveDocx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    private val createTxt = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri -> uri?.let { saveTxt(it) } }

    private val chooseImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { insertImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupEditor()
        setupBackHandling()
        showPanel(Panel.HOME)

        val resumeMode = intent.getBooleanExtra(MainActivity.EXTRA_RESUME_SESSION, false)
        if (resumeMode && restoreResumeSessionIfAvailable()) {
            // restored from previous session
        } else {
            intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
                currentUri = Uri.parse(raw)
                loadUri(currentUri!!)
            } ?: restoreDraftIfAvailable()
        }
    }

    private fun setupToolbar() = with(binding) {
        btnBack.setOnClickListener { requestClose() }
        btnSave.setOnClickListener { saveRequested() }
        btnSaveDocx.setOnClickListener { saveRequested() }
        btnExportPdf.setOnClickListener { createPdf.launch(suggestedName("pdf")) }
        btnSaveTxt.setOnClickListener { createTxt.launch(suggestedName("txt")) }
        btnUndo.setOnClickListener { undo() }
        btnRedo.setOnClickListener { redo() }

        btnFont.setOnClickListener { showFontPicker() }
        btnBold.setOnClickListener { toggleStyle(Typeface.BOLD) }
        btnItalic.setOnClickListener { toggleStyle(Typeface.ITALIC) }
        btnUnderline.setOnClickListener { toggleUnderline() }
        btnStrike.setOnClickListener { toggleStrike() }
        btnSizeDown.setOnClickListener { changeSize(-1) }
        btnSizeUp.setOnClickListener { changeSize(1) }
        btnTextColor.setOnClickListener { showColorPicker(false) }
        btnHighlight.setOnClickListener { showColorPicker(true) }
        btnAlignLeft.setOnClickListener { applyAlignment(Layout.Alignment.ALIGN_NORMAL) }
        btnAlignCenter.setOnClickListener { applyAlignment(Layout.Alignment.ALIGN_CENTER) }
        btnAlignRight.setOnClickListener { applyAlignment(Layout.Alignment.ALIGN_OPPOSITE) }
        btnJustify.setOnClickListener { toggleJustification() }
        btnBullet.setOnClickListener { toggleBulletList() }
        btnNumberList.setOnClickListener { toggleNumberedList() }
        btnIndentIn.setOnClickListener { changeIndent(1) }
        btnIndentOut.setOnClickListener { changeIndent(-1) }
        btnLineSpacing.setOnClickListener { cycleLineSpacing() }

        btnInsertImage.setOnClickListener { chooseImage.launch("image/*") }
        btnInsertSignature.setOnClickListener { chooseImage.launch("image/*") }
        btnInsertTable.setOnClickListener { showTableDialog() }
        btnPageBreak.setOnClickListener { insertTextAtCursor("\n\u000C\n") }
        btnInsertDate.setOnClickListener {
            val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            insertTextAtCursor(date)
        }
        btnInsertLink.setOnClickListener { showLinkDialog() }

        btnFindReplace.setOnClickListener { showFindReplaceDialog() }
        btnPageWhite.setOnClickListener { setPageTheme(Color.WHITE, ContextCompat.getColor(this@DocumentEditorActivity, R.color.geo_text)) }
        btnPageSepia.setOnClickListener { setPageTheme(Color.rgb(250, 242, 218), Color.rgb(45, 39, 30)) }
        btnPageDark.setOnClickListener { setPageTheme(Color.rgb(35, 37, 43), Color.rgb(238, 238, 238)) }
        btnKeepScreen.setOnClickListener { toggleKeepScreenOn() }
        btnZoomOut.setOnClickListener { zoomEditor(-1f) }
        btnZoomIn.setOnClickListener { zoomEditor(1f) }
        btnShare.setOnClickListener { shareDocument() }
        btnInfo.setOnClickListener { showDocumentInfo() }

        tabHome.setOnClickListener { showPanel(Panel.HOME) }
        tabInsert.setOnClickListener { showPanel(Panel.INSERT) }
        tabFile.setOnClickListener { showPanel(Panel.FILE) }
        tabView.setOnClickListener { showPanel(Panel.VIEW) }
    }

    private fun setupEditor() {
        binding.editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                if (!internalChange) beforeSnapshot = captureSnapshot()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                lastChangeStart = start
                lastInsertedCount = count
            }

            override fun afterTextChanged(s: Editable?) {
                if (internalChange) return
                beforeSnapshot?.let { pushUndoSnapshot(it) }
                beforeSnapshot = null
                dirty = true
                applyPendingFormatting(lastChangeStart, lastInsertedCount)
                continueListAfterNewLine(lastChangeStart, lastInsertedCount)
                updateStatus()
            }
        })
        binding.editor.setOnSelectionChangedListenerCompat { updateCurrentSizeFromSelection() }
        binding.editor.onZoomChanged = { size ->
            currentTextSizeSp = size.roundToInt()
            binding.tvTextSize.text = currentTextSizeSp.toString()
        }
        currentTextSizeSp = binding.editor.getZoomTextSizeSp().roundToInt()
        binding.tvTextSize.text = currentTextSizeSp.toString()
        updateStatus()
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = requestClose()
        })
    }

    private fun restoreResumeSessionIfAvailable(): Boolean {
        val html = resumePrefs.getString(ResumeSession.DOC_HTML, null).orEmpty()
        if (html.isBlank()) return false
        currentUri = resumePrefs.getString(ResumeSession.DOC_URI, null)?.takeIf { it.isNotBlank() }?.let(Uri::parse)
        val restored = HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY)
        internalChange = true
        binding.editor.setText(restored)
        internalChange = false
        binding.tvTitle.text = resumePrefs.getString(ResumeSession.DOC_TITLE, null)
            ?: currentUri?.let { UriUtils.displayName(this, it) }
            ?: "Borrador recuperado"
        val restoredSize = resumePrefs.getFloat(ResumeSession.DOC_TEXT_SIZE_SP, 16f)
        binding.editor.applyZoomTextSize(restoredSize)
        currentTextSizeSp = restoredSize.roundToInt()
        binding.tvTextSize.text = currentTextSizeSp.toString()
        dirty = resumePrefs.getBoolean(ResumeSession.DOC_DIRTY, true)
        showPanel(
            runCatching { Panel.valueOf(resumePrefs.getString(ResumeSession.DOC_PANEL, Panel.HOME.name) ?: Panel.HOME.name) }
                .getOrDefault(Panel.HOME)
        )
        val start = resumePrefs.getInt(ResumeSession.DOC_SELECTION_START, binding.editor.length()).coerceIn(0, binding.editor.length())
        val end = resumePrefs.getInt(ResumeSession.DOC_SELECTION_END, start).coerceIn(start, binding.editor.length())
        binding.editor.post {
            runCatching { binding.editor.setSelection(start, end) }
            binding.editor.scrollTo(0, resumePrefs.getInt(ResumeSession.DOC_SCROLL_Y, 0))
        }
        updateStatus()
        return true
    }

    private fun restoreDraftIfAvailable() {
        val html = prefs.getString("draft_html", null).orEmpty()
        if (html.isBlank()) return
        val restored = HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY)
        internalChange = true
        binding.editor.setText(restored)
        binding.editor.setSelection(binding.editor.length())
        internalChange = false
        binding.tvTitle.text = "Borrador recuperado"
        dirty = true
        updateStatus()
    }

    private fun loadUri(uri: Uri) {
        val name = UriUtils.displayName(this, uri)
        binding.tvTitle.text = name
        Thread {
            runCatching<CharSequence> {
                when (UriUtils.extension(this, uri)) {
                    "docx" -> OpenXmlDocx.read(this, uri)
                    else -> contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                }
            }.onSuccess { text ->
                runOnUiThread {
                    internalChange = true
                    binding.editor.setText(text)
                    binding.editor.setSelection(binding.editor.length())
                    internalChange = false
                    dirty = false
                    undoStack.clear()
                    redoStack.clear()
                    updateStatus()
                }
            }.onFailure { error ->
                runOnUiThread { toast("No se pudo abrir: ${error.message}") }
            }
        }.start()
    }

    private fun saveRequested() {
        val existing = currentUri
        if (existing == null || UriUtils.extension(this, existing) != "docx") {
            createDocx.launch(suggestedName("docx"))
        } else {
            saveDocx(existing, false)
        }
    }

    private fun saveDocx(uri: Uri, updateCurrent: Boolean) {
        val content = SpannableString(editorContent)
        Thread {
            runCatching { OpenXmlDocx.write(this, uri, content) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        dirty = false
                        prefs.edit().remove("draft_html").apply()
                        toast("Documento guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}")
                    }
                }
                .onFailure {
                    runOnUiThread {
                        if (!updateCurrent) {
                            toast("No se puede sobrescribir. Guarda una copia.")
                            createDocx.launch(suggestedName("docx"))
                        } else toast("Error al guardar: ${it.message}")
                    }
                }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val content = SpannableString(editorContent)
        Thread {
            runCatching { PdfExporter.styledTextToPdf(this, uri, content, "Geo Office") }
                .onSuccess { runOnUiThread { toast("PDF creado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun saveTxt(uri: Uri) {
        val plainText = editorContent.toString()
        Thread {
            runCatching {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "No se pudo crear el TXT" }
                    output.write(plainText.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { runOnUiThread { toast("TXT guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun toggleStyle(style: Int) {
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        if (start == end) {
            if (style == Typeface.BOLD) pendingBold = !pendingBold else pendingItalic = !pendingItalic
            refreshPendingButtons()
            return
        }
        pushUndoSnapshot(captureSnapshot())
        val spans = editorContent.getSpans(start, end, StyleSpan::class.java)
        val matching = spans.filter { it.style == style }
        if (matching.isNotEmpty()) matching.forEach { editorContent.removeSpan(it) }
        else editorContent.setSpan(StyleSpan(style), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun toggleUnderline() {
        val range = selectedRangeOrPending { pendingUnderline = !pendingUnderline }
        if (range == null) return
        pushUndoSnapshot(captureSnapshot())
        val end = range.last + 1
        val spans = editorContent.getSpans(range.first, end, UnderlineSpan::class.java)
        if (spans.isNotEmpty()) spans.forEach { editorContent.removeSpan(it) }
        else editorContent.setSpan(UnderlineSpan(), range.first, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun toggleStrike() {
        val range = selectedRangeOrPending { pendingStrike = !pendingStrike }
        if (range == null) return
        pushUndoSnapshot(captureSnapshot())
        val end = range.last + 1
        val spans = editorContent.getSpans(range.first, end, StrikethroughSpan::class.java)
        if (spans.isNotEmpty()) spans.forEach { editorContent.removeSpan(it) }
        else editorContent.setSpan(StrikethroughSpan(), range.first, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun selectedRangeOrPending(onPending: () -> Unit): IntRange? {
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        if (start == end) {
            onPending()
            refreshPendingButtons()
            return null
        }
        return start until end
    }

    private fun changeSize(delta: Int) {
        currentTextSizeSp = (currentTextSizeSp + delta).coerceIn(8, 72)
        binding.tvTextSize.text = currentTextSizeSp.toString()
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        if (start == end) {
            pendingSizeSp = currentTextSizeSp
            return
        }
        pushUndoSnapshot(captureSnapshot())
        editorContent.getSpans(start, end, AbsoluteSizeSpan::class.java).forEach { editorContent.removeSpan(it) }
        editorContent.setSpan(AbsoluteSizeSpan(currentTextSizeSp, true), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }


    private fun showFontPicker() {
        val labels = arrayOf("Calibri / Sans", "Times / Serif", "Monoespaciada")
        val families = arrayOf("sans", "serif", "monospace")
        MaterialAlertDialogBuilder(this)
            .setTitle("Tipo de letra")
            .setItems(labels) { _, which -> applyFontFamily(families[which], labels[which]) }
            .show()
    }

    private fun applyFontFamily(family: String, label: String) {
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        binding.btnFont.text = label.substringBefore(" /")
        if (start == end) {
            pendingFontFamily = family
            return
        }
        pushUndoSnapshot(captureSnapshot())
        editorContent.getSpans(start, end, TypefaceSpan::class.java).forEach { editorContent.removeSpan(it) }
        editorContent.setSpan(TypefaceSpan(family), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun showColorPicker(highlight: Boolean) {
        val labels = arrayOf("Negro", "Azul", "Rojo", "Verde", "Naranja", "Morado", "Amarillo", "Quitar")
        val colors = intArrayOf(Color.BLACK, Color.rgb(30, 90, 200), Color.rgb(210, 45, 45), Color.rgb(25, 140, 75), Color.rgb(230, 120, 20), Color.rgb(120, 65, 175), Color.YELLOW, Color.TRANSPARENT)
        MaterialAlertDialogBuilder(this)
            .setTitle(if (highlight) "Color de resaltado" else "Color de texto")
            .setItems(labels) { _, which -> applyColor(colors[which], highlight) }
            .show()
    }

    private fun applyColor(color: Int, highlight: Boolean) {
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        if (start == end) {
            if (highlight) pendingBackground = color.takeUnless { it == Color.TRANSPARENT }
            else pendingForeground = color.takeUnless { it == Color.TRANSPARENT }
            return
        }
        pushUndoSnapshot(captureSnapshot())
        if (highlight) {
            editorContent.getSpans(start, end, BackgroundColorSpan::class.java).forEach { editorContent.removeSpan(it) }
            if (color != Color.TRANSPARENT) editorContent.setSpan(BackgroundColorSpan(color), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        } else {
            editorContent.getSpans(start, end, ForegroundColorSpan::class.java).forEach { editorContent.removeSpan(it) }
            if (color != Color.TRANSPARENT) editorContent.setSpan(ForegroundColorSpan(color), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        dirty = true
    }

    private fun applyAlignment(alignment: Layout.Alignment) {
        val (start, end) = paragraphRange()
        pushUndoSnapshot(captureSnapshot())
        editorContent.getSpans(start, end, AlignmentSpan::class.java).forEach { editorContent.removeSpan(it) }
        editorContent.setSpan(AlignmentSpan.Standard(alignment), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun toggleJustification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            binding.editor.justificationMode = if (binding.editor.justificationMode == Layout.JUSTIFICATION_MODE_INTER_WORD) Layout.JUSTIFICATION_MODE_NONE else Layout.JUSTIFICATION_MODE_INTER_WORD
            toast(if (binding.editor.justificationMode == Layout.JUSTIFICATION_MODE_INTER_WORD) "Texto justificado" else "Justificación desactivada")
        } else toast("La justificación requiere Android 8 o superior")
    }

    private fun toggleBulletList() {
        transformSelectedLines { lines ->
            val allBullets = lines.filter { it.isNotBlank() }.all { it.trimStart().startsWith("• ") }
            lines.map { line ->
                if (line.isBlank()) line
                else if (allBullets) line.replaceFirst(Regex("^\\s*•\\s+"), "")
                else "• ${line.replaceFirst(Regex("^\\s*(•|\\d+\\.)\\s+"), "")}" 
            }
        }
    }

    private fun toggleNumberedList() {
        transformSelectedLines { lines ->
            val allNumbered = lines.filter { it.isNotBlank() }.all { it.trimStart().matches(Regex("\\d+\\.\\s+.*")) }
            var number = 1
            lines.map { line ->
                if (line.isBlank()) line
                else if (allNumbered) line.replaceFirst(Regex("^\\s*\\d+\\.\\s+"), "")
                else "${number++}. ${line.replaceFirst(Regex("^\\s*(•|\\d+\\.)\\s+"), "")}" 
            }
        }
    }

    private fun transformSelectedLines(transform: (List<String>) -> List<String>) {
        val (start, end) = paragraphRange()
        val original = editorContent.substring(start, end)
        pushUndoSnapshot(captureSnapshot())
        internalChange = true
        val transformed = transform(original.split('\n')).joinToString("\n")
        editorContent.replace(start, end, transformed)
        binding.editor.setSelection((start + transformed.length).coerceAtMost(binding.editor.length()))
        internalChange = false
        dirty = true
        updateStatus()
    }

    private fun changeIndent(direction: Int) {
        val (start, end) = paragraphRange()
        pushUndoSnapshot(captureSnapshot())
        val existing = editorContent.getSpans(start, end, LeadingMarginSpan.Standard::class.java)
        val current = existing.maxOfOrNull { it.getLeadingMargin(true) } ?: 0
        existing.forEach { editorContent.removeSpan(it) }
        val next = (current + direction * dp(24)).coerceAtLeast(0)
        if (next > 0) editorContent.setSpan(LeadingMarginSpan.Standard(next, next), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        dirty = true
    }

    private fun cycleLineSpacing() {
        lineSpacingIndex = (lineSpacingIndex + 1) % lineSpacings.size
        val multiplier = lineSpacings[lineSpacingIndex]
        binding.editor.setLineSpacing(0f, multiplier)
        binding.btnLineSpacing.text = "${multiplier}×"
    }

    private fun applyPendingFormatting(start: Int, count: Int) {
        if (count <= 0 || start < 0) return
        val end = (start + count).coerceAtMost(binding.editor.length())
        if (end <= start) return
        internalChange = true
        if (pendingBold) editorContent.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (pendingItalic) editorContent.setSpan(StyleSpan(Typeface.ITALIC), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (pendingUnderline) editorContent.setSpan(UnderlineSpan(), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (pendingStrike) editorContent.setSpan(StrikethroughSpan(), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        pendingForeground?.let { editorContent.setSpan(ForegroundColorSpan(it), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        pendingBackground?.let { editorContent.setSpan(BackgroundColorSpan(it), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        pendingSizeSp?.let { editorContent.setSpan(AbsoluteSizeSpan(it, true), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        pendingFontFamily?.let { editorContent.setSpan(TypefaceSpan(it), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        internalChange = false
    }

    private fun continueListAfterNewLine(start: Int, count: Int) {
        if (count != 1 || start < 0 || start >= binding.editor.length() || editorContent[start] != '\n') return
        val previousLineStart = editorContent.lastIndexOf('\n', (start - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val previousLine = editorContent.substring(previousLineStart, start)
        val prefix = when {
            previousLine.trimStart().startsWith("• ") -> "• "
            previousLine.trimStart().matches(Regex("\\d+\\.\\s+.*")) -> {
                val number = Regex("(\\d+)\\.").find(previousLine.trimStart())?.groupValues?.get(1)?.toIntOrNull() ?: 0
                "${number + 1}. "
            }
            else -> null
        } ?: return
        internalChange = true
        editorContent.insert(start + 1, prefix)
        binding.editor.setSelection(start + 1 + prefix.length)
        internalChange = false
    }

    private fun insertImage(uri: Uri) {
        Thread {
            runCatching {
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "No se pudo abrir la imagen" }
                    BitmapFactory.decodeStream(input) ?: error("Imagen no compatible")
                }
            }.onSuccess { bitmap ->
                runOnUiThread { addBitmapToEditor(bitmap, uri) }
            }.onFailure { runOnUiThread { toast("No se pudo insertar la imagen: ${it.message}") } }
        }.start()
    }

    private fun addBitmapToEditor(bitmap: Bitmap, uri: Uri) {
        val maxWidth = (binding.editor.width - binding.editor.paddingLeft - binding.editor.paddingRight).coerceAtLeast(dp(220))
        val scale = (maxWidth.toFloat() / bitmap.width).coerceAtMost(1f)
        val width = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val height = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        val drawable = BitmapDrawable(resources, bitmap).apply { setBounds(0, 0, width, height) }
        val span = GeoImageSpan(drawable, uri.toString(), width, height)
        val position = binding.editor.selectionStart.coerceAtLeast(0)
        pushUndoSnapshot(captureSnapshot())
        internalChange = true
        editorContent.insert(position, "\n\uFFFC\n")
        editorContent.setSpan(span, position + 1, position + 2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.editor.setSelection(position + 3)
        internalChange = false
        dirty = true
        updateStatus()
    }

    private fun showTableDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val rows = EditText(this).apply { hint = "Filas (1–20)"; inputType = 2; setText("3") }
        val cols = EditText(this).apply { hint = "Columnas (1–8)"; inputType = 2; setText("3") }
        container.addView(rows)
        container.addView(cols)
        MaterialAlertDialogBuilder(this)
            .setTitle("Insertar tabla básica")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Insertar") { _, _ ->
                val r = rows.text.toString().toIntOrNull()?.coerceIn(1, 20) ?: 3
                val c = cols.text.toString().toIntOrNull()?.coerceIn(1, 8) ?: 3
                val table = buildString {
                    repeat(r) { row ->
                        append((1..c).joinToString("\t") { col -> "Celda ${row + 1}.$col" })
                        if (row < r - 1) append('\n')
                    }
                }
                insertTextAtCursor(table)
            }.show()
    }

    private fun showLinkDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val textInput = EditText(this).apply { hint = "Texto del enlace" }
        val urlInput = EditText(this).apply { hint = "https://..."; inputType = 33 }
        container.addView(textInput)
        container.addView(urlInput)
        MaterialAlertDialogBuilder(this)
            .setTitle("Insertar hipervínculo")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Insertar") { _, _ ->
                val label = textInput.text.toString().ifBlank { urlInput.text.toString() }
                val url = urlInput.text.toString().trim()
                if (label.isBlank() || url.isBlank()) return@setPositiveButton
                val position = binding.editor.selectionStart.coerceAtLeast(0)
                pushUndoSnapshot(captureSnapshot())
                internalChange = true
                editorContent.insert(position, label)
                editorContent.setSpan(URLSpan(url), position, position + label.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                binding.editor.setSelection(position + label.length)
                internalChange = false
                dirty = true
            }.show()
    }

    private fun showFindReplaceDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val find = EditText(this).apply { hint = "Buscar" }
        val replace = EditText(this).apply { hint = "Reemplazar por" }
        container.addView(find)
        container.addView(replace)
        MaterialAlertDialogBuilder(this)
            .setTitle("Buscar y reemplazar")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Buscar") { _, _ -> findNext(find.text.toString()) }
            .setPositiveButton("Reemplazar todo") { _, _ ->
                val needle = find.text.toString()
                if (needle.isBlank()) return@setPositiveButton
                pushUndoSnapshot(captureSnapshot())
                val replaced = editorContent.toString().replace(needle, replace.text.toString(), ignoreCase = true)
                internalChange = true
                binding.editor.setText(replaced)
                binding.editor.setSelection(binding.editor.length())
                internalChange = false
                dirty = true
                updateStatus()
            }.show()
    }

    private fun findNext(query: String) {
        if (query.isBlank()) return
        val text = editorContent.toString()
        val from = binding.editor.selectionEnd.coerceAtLeast(0)
        var index = text.indexOf(query, from, ignoreCase = true)
        if (index < 0) index = text.indexOf(query, 0, ignoreCase = true)
        if (index >= 0) {
            binding.editor.requestFocus()
            binding.editor.setSelection(index, index + query.length)
        } else toast("No se encontró el texto")
    }

    private fun insertTextAtCursor(value: String) {
        val start = binding.editor.selectionStart.coerceAtLeast(0)
        val end = binding.editor.selectionEnd.coerceAtLeast(start)
        pushUndoSnapshot(captureSnapshot())
        internalChange = true
        editorContent.replace(start, end, value)
        binding.editor.setSelection(start + value.length)
        internalChange = false
        dirty = true
        updateStatus()
    }

    private fun paragraphRange(): Pair<Int, Int> {
        val text = editorContent
        var start = binding.editor.selectionStart.coerceAtLeast(0)
        var end = binding.editor.selectionEnd.coerceAtLeast(start)
        while (start > 0 && text[start - 1] != '\n') start--
        while (end < text.length && text[end] != '\n') end++
        return start to end
    }

    private fun captureSnapshot(): EditorSnapshot = EditorSnapshot(
        SpannableString(editorContent),
        binding.editor.selectionStart.coerceAtLeast(0),
        binding.editor.selectionEnd.coerceAtLeast(0)
    )

    private fun pushUndoSnapshot(snapshot: EditorSnapshot) {
        undoStack.addLast(snapshot)
        while (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(captureSnapshot())
        restoreSnapshot(undoStack.removeLast())
    }

    private fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(captureSnapshot())
        restoreSnapshot(redoStack.removeLast())
    }

    private fun restoreSnapshot(snapshot: EditorSnapshot) {
        internalChange = true
        binding.editor.setText(snapshot.text)
        val start = snapshot.selectionStart.coerceIn(0, binding.editor.length())
        val end = snapshot.selectionEnd.coerceIn(start, binding.editor.length())
        binding.editor.setSelection(start, end)
        internalChange = false
        dirty = true
        updateStatus()
    }

    private fun updateStatus() {
        val text = editorContent.toString()
        val words = Regex("\\S+").findAll(text.replace('\u000C', ' ')).count()
        val characters = text.length
        val explicitBreaks = text.count { it == '\u000C' }
        val estimatedPages = (1 + explicitBreaks + (characters / 2600)).coerceAtLeast(1)
        binding.tvStatus.text = "$words palabras · $characters caracteres"
        binding.tvPageCount.text = if (estimatedPages == 1) "Página 1" else "$estimatedPages páginas"
    }

    private fun updateCurrentSizeFromSelection() {
        val position = binding.editor.selectionStart.coerceAtLeast(0).coerceAtMost(binding.editor.length())
        val spans = editorContent.getSpans((position - 1).coerceAtLeast(0), position, AbsoluteSizeSpan::class.java)
        currentTextSizeSp = spans.lastOrNull()?.let { if (it.dip) it.size else (it.size / resources.displayMetrics.scaledDensity).roundToInt() } ?: 16
        binding.tvTextSize.text = currentTextSizeSp.toString()
    }

    private fun refreshPendingButtons() {
        binding.btnBold.isSelected = pendingBold
        binding.btnItalic.isSelected = pendingItalic
        binding.btnUnderline.isSelected = pendingUnderline
        binding.btnStrike.isSelected = pendingStrike
        binding.btnBold.alpha = if (pendingBold) 1f else 0.72f
        binding.btnItalic.alpha = if (pendingItalic) 1f else 0.72f
        binding.btnUnderline.alpha = if (pendingUnderline) 1f else 0.72f
        binding.btnStrike.alpha = if (pendingStrike) 1f else 0.72f
    }

    private fun setPageTheme(background: Int, textColor: Int) {
        binding.pageCard.setCardBackgroundColor(background)
        binding.editor.setTextColor(textColor)
        binding.editor.setHintTextColor(Color.argb(140, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
    }

    private fun toggleKeepScreenOn() {
        keepScreenOn = !keepScreenOn
        if (keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding.btnKeepScreen.text = if (keepScreenOn) "Pantalla: sí" else "Pantalla activa"
    }

    private fun zoomEditor(delta: Float) {
        val next = (binding.editor.getZoomTextSizeSp() + delta).coerceIn(10f, 30f)
        binding.editor.applyZoomTextSize(next)
        currentTextSizeSp = next.roundToInt()
        binding.tvTextSize.text = currentTextSizeSp.toString()
    }

    private fun shareDocument() {
        val text = editorContent.toString()
        if (text.isBlank()) {
            toast("No hay contenido para compartir")
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, binding.tvTitle.text.toString())
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Compartir documento"))
    }

    private fun showDocumentInfo() {
        val text = editorContent.toString()
        val words = Regex("\\S+").findAll(text).count()
        val paragraphs = text.split('\n').count { it.isNotBlank() }
        val images = editorContent.getSpans(0, binding.editor.length(), GeoImageSpan::class.java).size
        MaterialAlertDialogBuilder(this)
            .setTitle("Información del documento")
            .setMessage("Nombre: ${binding.tvTitle.text}\nPalabras: $words\nCaracteres: ${text.length}\nPárrafos: $paragraphs\nImágenes: $images\nCambios sin guardar: ${if (dirty) "Sí" else "No"}")
            .setPositiveButton("Cerrar", null)
            .show()
    }

    private fun showPanel(panel: Panel) {
        currentPanel = panel
        binding.panelHome.visibility = if (panel == Panel.HOME) View.VISIBLE else View.GONE
        binding.panelInsert.visibility = if (panel == Panel.INSERT) View.VISIBLE else View.GONE
        binding.panelFile.visibility = if (panel == Panel.FILE) View.VISIBLE else View.GONE
        binding.panelView.visibility = if (panel == Panel.VIEW) View.VISIBLE else View.GONE
        binding.tabHome.alpha = if (panel == Panel.HOME) 1f else 0.62f
        binding.tabInsert.alpha = if (panel == Panel.INSERT) 1f else 0.62f
        binding.tabFile.alpha = if (panel == Panel.FILE) 1f else 0.62f
        binding.tabView.alpha = if (panel == Panel.VIEW) 1f else 0.62f
    }

    private fun requestClose() {
        if (!dirty) {
            disableResumeAndFinish()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("¿Salir del documento?")
            .setMessage("Hay cambios que todavía no guardaste.")
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Salir sin guardar") { _, _ -> disableResumeAndFinish() }
            .setPositiveButton("Guardar") { _, _ -> saveRequested() }
            .show()
    }

    override fun onPause() {
        super.onPause()
        val html = Html.toHtml(editorContent as Spanned, Html.TO_HTML_PARAGRAPH_LINES_CONSECUTIVE)
        if (currentUri == null && editorContent.isNotBlank()) {
            prefs.edit().putString("draft_html", html).apply()
        }
        if (disableAutoResumeOnExit) {
            resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
            return
        }
        if (editorContent.isBlank() && currentUri == null) return
        resumePrefs.edit()
            .putBoolean(ResumeSession.AUTO_RESUME, true)
            .putString(ResumeSession.LAST_SCREEN, ResumeSession.SCREEN_DOCUMENT)
            .putString(ResumeSession.DOC_URI, currentUri?.toString())
            .putString(ResumeSession.DOC_HTML, html)
            .putString(ResumeSession.DOC_TITLE, binding.tvTitle.text?.toString().orEmpty())
            .putInt(ResumeSession.DOC_SELECTION_START, binding.editor.selectionStart.coerceAtLeast(0))
            .putInt(ResumeSession.DOC_SELECTION_END, binding.editor.selectionEnd.coerceAtLeast(0))
            .putInt(ResumeSession.DOC_SCROLL_Y, binding.editor.scrollY)
            .putFloat(ResumeSession.DOC_TEXT_SIZE_SP, binding.editor.getZoomTextSizeSp())
            .putBoolean(ResumeSession.DOC_DIRTY, dirty)
            .putString(ResumeSession.DOC_PANEL, currentPanel.name)
            .apply()
    }

    private fun disableResumeAndFinish() {
        disableAutoResumeOnExit = true
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
        finish()
    }

    private fun suggestedName(extension: String): String {
        val current = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${current?.takeIf { it.isNotBlank() } ?: "Documento Geo Office"}.$extension"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private enum class Panel { HOME, INSERT, FILE, VIEW }
    private data class EditorSnapshot(val text: SpannableString, val selectionStart: Int, val selectionEnd: Int)
}

private fun EditText.setOnSelectionChangedListenerCompat(listener: () -> Unit) {
    setOnFocusChangeListener { _, hasFocus -> if (hasFocus) listener() }
}
