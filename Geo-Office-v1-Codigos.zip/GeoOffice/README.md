# Geo Office

Aplicación Android ligera para crear documentos sencillos, trabajar con PDF y usar OCR sin iniciar sesión.

## Funciones incluidas en esta primera versión

- Editor de documentos con formato visual básico.
- Crear, abrir y guardar documentos DOCX sencillos.
- Exportar documentos a PDF.
- Hoja de cálculo básica con 8 columnas, filas ampliables y fórmulas simples.
- Crear, abrir y guardar XLSX sencillos.
- Abrir CSV y exportar hojas a PDF.
- Crear, abrir y guardar presentaciones PPTX sencillas.
- Exportar presentaciones a PDF.
- OCR de fotografías sin iniciar sesión.
- Tomar una foto o elegir una imagen y convertir el texto a DOCX o PDF.
- Ver archivos PDF.
- Convertir varias imágenes en un PDF.
- Unir archivos PDF.
- Dividir un PDF por páginas.
- Convertir páginas PDF a imágenes PNG.
- Comprimir un PDF recreándolo con páginas optimizadas.
- Archivos recientes.
- Sin cuenta, nube, publicidad ni permiso de internet.

## Límites reales de esta versión

Geo Office todavía no sustituye a Microsoft Office ni a WPS en documentos complejos. La primera versión está pensada para cartas, tareas, cuadros, presentaciones y conversiones sencillas.

- DOCX: abre y guarda principalmente el texto. El formato avanzado del archivo original puede perderse al volver a guardarlo.
- XLSX: trabaja con una hoja y funciones básicas. No soporta macros ni gráficos complejos.
- PPTX: trabaja con diapositivas de título y contenido. No incluye animaciones ni plantillas avanzadas.
- Compresión PDF: convierte las páginas a imágenes optimizadas; por eso el texto del PDF comprimido deja de ser seleccionable.

## Compilar

Requiere Java 17 y Android SDK 35.

```bash
chmod +x gradlew
./gradlew assembleDebug
```

El APK se genera en:

```text
app/build/outputs/apk/debug/app-debug.apk
```

También se incluye GitHub Actions en `.github/workflows/android-build.yml`.

## Privacidad

La aplicación no solicita inicio de sesión. El procesamiento se realiza dentro del teléfono y no existe código para subir automáticamente los documentos a un servidor.
