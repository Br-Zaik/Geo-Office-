package com.geooffice.app.ui

import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.MainActivity
import com.geooffice.app.databinding.ActivityPresentationBinding
import com.geooffice.app.office.GeoSlide
import com.geooffice.app.office.OpenXmlPptx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.util.UriUtils

class PresentationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPresentationBinding
    private val slides = mutableListOf(GeoSlide("Título de la diapositiva", "Contenido"))
    private var currentIndex = 0
    private var currentUri: Uri? = null
    private var updating = false

    private val createPptx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation")
    ) { uri -> uri?.let { savePptx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPresentationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnPrevious.setOnClickListener { moveTo(currentIndex - 1) }
        binding.btnNext.setOnClickListener { moveTo(currentIndex + 1) }
        binding.btnAddSlide.setOnClickListener {
            saveCurrentFields()
            slides.add(GeoSlide("Nueva diapositiva", ""))
            currentIndex = slides.lastIndex
            renderCurrent()
        }
        binding.btnDeleteSlide.setOnClickListener {
            if (slides.size == 1) {
                slides[0] = GeoSlide()
                currentIndex = 0
            } else {
                slides.removeAt(currentIndex)
                currentIndex = currentIndex.coerceAtMost(slides.lastIndex)
            }
            renderCurrent()
        }
        binding.btnSave.setOnClickListener {
            saveCurrentFields()
            val uri = currentUri
            if (uri == null) createPptx.launch(suggestedName("pptx")) else savePptx(uri, false)
        }
        binding.btnExportPdf.setOnClickListener {
            saveCurrentFields()
            createPdf.launch(suggestedName("pdf"))
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!updating) {
                    saveCurrentFields()
                    updatePreview()
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        binding.inputTitle.addTextChangedListener(watcher)
        binding.inputBody.addTextChangedListener(watcher)

        renderCurrent()
        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
            currentUri = Uri.parse(raw)
            binding.tvTitle.text = UriUtils.displayName(this, currentUri!!)
            loadFile(currentUri!!)
        }
    }

    private fun moveTo(index: Int) {
        if (index !in slides.indices) return
        saveCurrentFields()
        currentIndex = index
        renderCurrent()
    }

    private fun saveCurrentFields() {
        if (updating || currentIndex !in slides.indices) return
        slides[currentIndex].title = binding.inputTitle.text?.toString().orEmpty()
        slides[currentIndex].body = binding.inputBody.text?.toString().orEmpty()
    }

    private fun renderCurrent() {
        if (currentIndex !in slides.indices) currentIndex = 0
        val slide = slides[currentIndex]
        updating = true
        binding.inputTitle.setText(slide.title)
        binding.inputBody.setText(slide.body)
        binding.tvSlideCounter.text = "Diapositiva ${currentIndex + 1} de ${slides.size}"
        binding.btnPrevious.isEnabled = currentIndex > 0
        binding.btnNext.isEnabled = currentIndex < slides.lastIndex
        binding.btnDeleteSlide.text = if (slides.size == 1) "Limpiar" else "Eliminar"
        updating = false
        updatePreview()
    }

    private fun updatePreview() {
        binding.previewTitle.text = binding.inputTitle.text?.toString()?.ifBlank { "Sin título" }
        binding.previewBody.text = binding.inputBody.text?.toString().orEmpty()
    }

    private fun loadFile(uri: Uri) {
        Thread {
            runCatching { OpenXmlPptx.read(this, uri) }
                .onSuccess { loaded ->
                    runOnUiThread {
                        if (loaded.isNotEmpty()) {
                            slides.clear()
                            slides.addAll(loaded)
                            currentIndex = 0
                            renderCurrent()
                        }
                    }
                }
                .onFailure { error -> runOnUiThread { Toast.makeText(this, "No se pudo abrir: ${error.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun savePptx(uri: Uri, updateCurrent: Boolean) {
        val snapshot = slides.map { it.copy() }
        Thread {
            runCatching { OpenXmlPptx.write(this, uri, snapshot) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        Toast.makeText(this, "Presentación guardada", Toast.LENGTH_SHORT).show()
                    }
                }
                .onFailure {
                    runOnUiThread {
                        if (!updateCurrent) createPptx.launch(suggestedName("pptx"))
                        else Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val snapshot = slides.map { it.copy() }
        Thread {
            runCatching { PdfExporter.slidesToPdf(this, uri, snapshot) }
                .onSuccess { runOnUiThread { Toast.makeText(this, "PDF creado", Toast.LENGTH_SHORT).show() } }
                .onFailure { runOnUiThread { Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun suggestedName(extension: String): String {
        val base = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${base?.takeIf { it.isNotBlank() } ?: "Presentación Geo Office"}.$extension"
    }
}
