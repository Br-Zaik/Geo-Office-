package com.geooffice.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentFile(val uri: String, val name: String, val type: String, val openedAt: Long)

class RecentStore(context: Context) {
    private val prefs = context.getSharedPreferences("recent_files", Context.MODE_PRIVATE)

    fun add(uri: Uri, name: String, type: String) {
        val current = getAll().filterNot { it.uri == uri.toString() }.toMutableList()
        current.add(0, RecentFile(uri.toString(), name, type, System.currentTimeMillis()))
        save(current.take(8))
    }

    fun getAll(): List<RecentFile> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        RecentFile(
                            uri = obj.getString("uri"),
                            name = obj.optString("name", "Archivo"),
                            type = obj.optString("type", "archivo"),
                            openedAt = obj.optLong("openedAt", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun save(items: List<RecentFile>) {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("uri", it.uri)
                    .put("name", it.name)
                    .put("type", it.type)
                    .put("openedAt", it.openedAt)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
