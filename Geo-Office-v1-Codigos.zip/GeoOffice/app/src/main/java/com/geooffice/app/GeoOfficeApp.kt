package com.geooffice.app

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class GeoOfficeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(this)
    }
}
