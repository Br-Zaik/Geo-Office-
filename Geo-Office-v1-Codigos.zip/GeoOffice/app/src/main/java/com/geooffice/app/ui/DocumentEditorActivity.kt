package com.geooffice.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.Selection
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.AlignmentSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.Gravity
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.MainActivity
import com.geooffice.app.databinding.ActivityDocumentEditorBinding
import com.geooffice.app.office.OpenXmlDocx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.util.UriUtils
import java.util.ArrayDeque

class DocumentEditorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDocumentEditorBinding
    private var currentUri: Uri? = null
    private var textSizeSp = 16f
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private var internalChange = false

    private val createDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri -> uri?.let { saveDocx(it, true) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSave.setOnClickListener { saveRequested() }
        binding.btnExportPdf.setOnClickListener { createPdf.launch(suggestedName("pdf")) }
        binding.btnBold.setOnClickListener { applySpan(StyleSpan(Typeface.BOLD)) }
        binding.btnItalic.setOnClickListener { applySpan(StyleSpan(Typeface.ITALIC)) }
        binding.btnUnderline.setOnClickListener { applySpan(UnderlineSpan()) }
        binding.btnAlignLeft.setOnClickListener { applyAlignment(android.text.Layout.Alignment.ALIGN_NORMAL) }
        binding.btnAlignCenter.setOnClickListener { applyAlignment(android.text.Layout.Alignment.ALIGN_CENTER) }
        binding.btnBullet.setOnClickListener { insertBullet() }
        binding.btnSizeDown.setOnClickListener { changeSize(-1f) }
        binding.btnSizeUp.setOnClickListener { changeSize(1f) }
        binding.btnUndo.setOnClickListener { undo() }
        binding.btnRedo.setOnClickListener { redo() }

        binding.editor.addTextChangedListener(object : TextWatcher {
            private var before = ""
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                if (!internalChange) before = s?.toString().orEmpty()
            }
            override fun onTextChanged(s: CharSequence?, start: Int, beforeCount: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (!internalChange && before != s?.toString().orEmpty()) {
                    undoStack.addLast(before)
                    while (undoStack.size > 40) undoStack.removeFirst()
                    redoStack.clear()
                }
            }
        })

        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
            currentUri = Uri.parse(raw)
            loadUri(currentUri!!)
        }
    }

    private fun loadUri(uri: Uri) {
        val name = UriUtils.displayName(this, uri)
        binding.tvTitle.text = name
        Thread {
            runCatching {
                when (UriUtils.extension(this, uri)) {
                    "docx" -> OpenXmlDocx.read(this, uri)
                    else -> contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                }
            }.onSuccess { text ->
                runOnUiThread {
                    internalChange = true
                    binding.editor.setText(text)
                    binding.editor.setSelection(binding.editor.text.length)
                    internalChange = false
                }
            }.onFailure { error ->
                runOnUiThread { Toast.makeText(this, "No se pudo abrir: ${error.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun saveRequested() {
        val existing = currentUri
        if (existing == null || UriUtils.extension(this, existing) != "docx") {
            createDocx.launch(suggestedName("docx"))
            return
        }
        saveDocx(existing, false)
    }

    private fun saveDocx(uri: Uri, updateCurrent: Boolean) {
        Thread {
            runCatching { OpenXmlDocx.write(this, uri, binding.editor.text) }
                .onSuccess {
                    if (updateCurrent) currentUri = uri
                    runOnUiThread {
                        binding.tvTitle.text = UriUtils.displayName(this, uri)
                        Toast.makeText(this, "Documento guardado", Toast.LENGTH_SHORT).show()
                    }
                }
                .onFailure {
                    runOnUiThread {
                        if (!updateCurrent) {
                            Toast.makeText(this, "No se puede sobrescribir. Guarda una copia.", Toast.LENGTH_LONG).show()
                            createDocx.launch(suggestedName("docx"))
                        } else {
                            Toast.makeText(this, "Error al guardar: ${it.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        Thread {
            runCatching { PdfExporter.textToPdf(this, uri, binding.editor.text.toString(), "Geo Office") }
                .onSuccess { runOnUiThread { Toast.makeText(this, "PDF creado", Toast.LENGTH_SHORT).show() } }
                .onFailure { runOnUiThread { Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun applySpan(span: Any) {
        val start = binding.editor.selectionStart
        val end = binding.editor.selectionEnd
        if (start < 0 || end <= start) {
            Toast.makeText(this, "Selecciona el texto que deseas cambiar", Toast.LENGTH_SHORT).show()
            return
        }
        binding.editor.text.setSpan(span, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun applyAlignment(alignment: android.text.Layout.Alignment) {
        val text = binding.editor.text
        var start = binding.editor.selectionStart.coerceAtLeast(0)
        var end = binding.editor.selectionEnd.coerceAtLeast(start)
        while (start > 0 && text[start - 1] != '\n') start--
        while (end < text.length && text[end] != '\n') end++
        text.setSpan(AlignmentSpan.Standard(alignment), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.editor.gravity = if (alignment == android.text.Layout.Alignment.ALIGN_CENTER) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.TOP or Gravity.START
    }

    private fun insertBullet() {
        val position = binding.editor.selectionStart.coerceAtLeast(0)
        binding.editor.text.insert(position, "• ")
        Selection.setSelection(binding.editor.text, position + 2)
    }

    private fun changeSize(delta: Float) {
        textSizeSp = (textSizeSp + delta).coerceIn(10f, 40f)
        binding.editor.textSize = textSizeSp
        binding.tvTextSize.text = textSizeSp.toInt().toString()
    }

    private fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(binding.editor.text.toString())
        val value = undoStack.removeLast()
        internalChange = true
        binding.editor.setText(value)
        binding.editor.setSelection(binding.editor.text.length)
        internalChange = false
    }

    private fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(binding.editor.text.toString())
        val value = redoStack.removeLast()
        internalChange = true
        binding.editor.setText(value)
        binding.editor.setSelection(binding.editor.text.length)
        internalChange = false
    }

    private fun suggestedName(extension: String): String {
        val current = currentUri?.let { UriUtils.displayName(this, it).substringBeforeLast('.') }
        return "${current?.takeIf { it.isNotBlank() } ?: "Documento Geo Office"}.$extension"
    }
}
