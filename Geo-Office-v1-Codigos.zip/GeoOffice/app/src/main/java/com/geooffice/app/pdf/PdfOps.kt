package com.geooffice.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument

object PdfOps {
    fun merge(context: Context, inputs: List<Uri>, output: Uri) {
        require(inputs.size >= 2) { "Selecciona al menos dos PDF" }
        val streams = inputs.map { uri ->
            context.contentResolver.openInputStream(uri) ?: error("No se pudo abrir un PDF")
        }
        try {
            context.contentResolver.openOutputStream(output, "w").use { out ->
                requireNotNull(out) { "No se pudo crear el PDF" }
                val merger = PDFMergerUtility()
                streams.forEach { merger.addSource(it) }
                merger.destinationStream = out
                merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
            }
        } finally {
            streams.forEach { runCatching { it.close() } }
        }
    }

    fun split(context: Context, input: Uri, outputTree: Uri): Int {
        val directory = DocumentFile.fromTreeUri(context, outputTree) ?: error("Carpeta no válida")
        context.contentResolver.openInputStream(input).use { stream ->
            requireNotNull(stream) { "No se pudo abrir el PDF" }
            PDDocument.load(stream).use { source ->
                for (index in 0 until source.numberOfPages) {
                    val file = directory.createFile("application/pdf", "GeoOffice_pagina_${index + 1}.pdf")
                        ?: error("No se pudo crear la página ${index + 1}")
                    context.contentResolver.openOutputStream(file.uri, "w").use { out ->
                        requireNotNull(out)
                        PDDocument().use { target ->
                            target.importPage(source.getPage(index))
                            target.save(out)
                        }
                    }
                }
                return source.numberOfPages
            }
        }
    }

    fun toImages(context: Context, input: Uri, outputTree: Uri): Int {
        val directory = DocumentFile.fromTreeUri(context, outputTree) ?: error("Carpeta no válida")
        context.contentResolver.openFileDescriptor(input, "r").use { descriptor ->
            requireNotNull(descriptor) { "No se pudo abrir el PDF" }
            PdfRenderer(descriptor).use { renderer ->
                for (index in 0 until renderer.pageCount) {
                    renderer.openPage(index).use { page ->
                        val scale = 2f
                        val bitmap = Bitmap.createBitmap(
                            (page.width * scale).toInt().coerceAtLeast(1),
                            (page.height * scale).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val file = directory.createFile("image/png", "GeoOffice_pagina_${index + 1}.png")
                            ?: error("No se pudo crear la imagen ${index + 1}")
                        context.contentResolver.openOutputStream(file.uri, "w").use { out ->
                            requireNotNull(out)
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        }
                        bitmap.recycle()
                    }
                }
                return renderer.pageCount
            }
        }
    }

    fun compressAsImages(context: Context, input: Uri, output: Uri): Int {
        context.contentResolver.openFileDescriptor(input, "r").use { descriptor ->
            requireNotNull(descriptor) { "No se pudo abrir el PDF" }
            PdfRenderer(descriptor).use { renderer ->
                val pdf = PdfDocument()
                try {
                    for (index in 0 until renderer.pageCount) {
                        renderer.openPage(index).use { sourcePage ->
                            val maxWidth = 1280
                            val scale = minOf(1.4f, maxWidth.toFloat() / sourcePage.width.coerceAtLeast(1))
                            val bitmapWidth = (sourcePage.width * scale).toInt().coerceAtLeast(1)
                            val bitmapHeight = (sourcePage.height * scale).toInt().coerceAtLeast(1)
                            val bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
                            bitmap.eraseColor(Color.WHITE)
                            sourcePage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                            val page = pdf.startPage(
                                PdfDocument.PageInfo.Builder(sourcePage.width, sourcePage.height, index + 1).create()
                            )
                            page.canvas.drawColor(Color.WHITE)
                            page.canvas.drawBitmap(
                                bitmap,
                                null,
                                RectF(0f, 0f, sourcePage.width.toFloat(), sourcePage.height.toFloat()),
                                Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            )
                            pdf.finishPage(page)
                            bitmap.recycle()
                        }
                    }
                    context.contentResolver.openOutputStream(output, "w").use { out ->
                        requireNotNull(out)
                        pdf.writeTo(out)
                    }
                    return renderer.pageCount
                } finally {
                    pdf.close()
                }
            }
        }
    }
}
