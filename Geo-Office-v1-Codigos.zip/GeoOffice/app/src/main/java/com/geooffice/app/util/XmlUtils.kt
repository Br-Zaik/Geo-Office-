package com.geooffice.app.util

object XmlUtils {
    fun escape(value: String): String = buildString(value.length + 32) {
        value.forEach { ch ->
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if (ch.code >= 32 || ch == '\n' || ch == '\t' || ch == '\r') append(ch)
            }
        }
    }
}
