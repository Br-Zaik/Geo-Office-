package com.geooffice.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.databinding.ActivityPdfToolsBinding
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.pdf.PdfOps

class PdfToolsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfToolsBinding
    private var selectedImages: List<Uri> = emptyList()
    private var selectedPdfs: List<Uri> = emptyList()
    private var selectedSinglePdf: Uri? = null
    private var treeAction: TreeAction? = null

    private enum class TreeAction { SPLIT, TO_IMAGES }

    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            selectedImages = uris
            createImagesPdf.launch("Geo Office imágenes.pdf")
        }
    }

    private val createImagesPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output -> runTask("Creando PDF…") { PdfExporter.imagesToPdf(this, output, selectedImages); "PDF creado" } }
    }

    private val pickMergePdfs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.size < 2) toast("Selecciona al menos dos PDF")
        else {
            selectedPdfs = uris
            createMergedPdf.launch("Geo Office unido.pdf")
        }
    }

    private val createMergedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output -> runTask("Uniendo PDF…") { PdfOps.merge(this, selectedPdfs, output); "PDF unidos correctamente" } }
    }

    private val pickSplitPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            selectedSinglePdf = it
            treeAction = TreeAction.SPLIT
            chooseFolder.launch(null)
        }
    }

    private val pickImagePdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            selectedSinglePdf = it
            treeAction = TreeAction.TO_IMAGES
            chooseFolder.launch(null)
        }
    }

    private val chooseFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val input = selectedSinglePdf
        val action = treeAction
        if (tree == null || input == null || action == null) return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                tree,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        when (action) {
            TreeAction.SPLIT -> runTask("Dividiendo PDF…") {
                val count = PdfOps.split(this, input, tree)
                "$count páginas guardadas"
            }
            TreeAction.TO_IMAGES -> runTask("Convirtiendo páginas…") {
                val count = PdfOps.toImages(this, input, tree)
                "$count imágenes guardadas"
            }
        }
    }

    private val pickCompressPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            selectedSinglePdf = it
            createCompressedPdf.launch("Geo Office comprimido.pdf")
        }
    }

    private val createCompressedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val input = selectedSinglePdf
        if (output != null && input != null) {
            runTask("Comprimiendo PDF…") {
                val count = PdfOps.compressAsImages(this, input, output)
                "$count páginas comprimidas"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.cardImagesToPdf.setOnClickListener { pickImages.launch(arrayOf("image/*")) }
        binding.cardMergePdf.setOnClickListener { pickMergePdfs.launch(arrayOf("application/pdf")) }
        binding.cardSplitPdf.setOnClickListener { pickSplitPdf.launch(arrayOf("application/pdf")) }
        binding.cardPdfToImages.setOnClickListener { pickImagePdf.launch(arrayOf("application/pdf")) }
        binding.cardCompressPdf.setOnClickListener { pickCompressPdf.launch(arrayOf("application/pdf")) }
    }

    private fun runTask(startMessage: String, task: () -> String) {
        toast(startMessage)
        Thread {
            runCatching(task)
                .onSuccess { message -> runOnUiThread { toast(message) } }
                .onFailure { error -> runOnUiThread { toast("Error: ${error.message}") } }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
