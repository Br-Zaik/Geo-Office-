package com.geooffice.app.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.MainActivity
import com.geooffice.app.databinding.ActivityPdfViewerBinding
import com.geooffice.app.util.UriUtils

class PdfViewerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfViewerBinding
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageIndex = 0
    private var bitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnPrevious.setOnClickListener { showPage(pageIndex - 1) }
        binding.btnNext.setOnClickListener { showPage(pageIndex + 1) }

        val uri = intent.getStringExtra(MainActivity.EXTRA_URI)?.let(Uri::parse)
        if (uri == null) {
            Toast.makeText(this, "No se recibió el PDF", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        binding.tvTitle.text = UriUtils.displayName(this, uri)
        openPdf(uri)
    }

    private fun openPdf(uri: Uri) {
        runCatching {
            descriptor = contentResolver.openFileDescriptor(uri, "r")
            renderer = PdfRenderer(requireNotNull(descriptor))
            showPage(0)
        }.onFailure {
            Toast.makeText(this, "No se pudo abrir: ${it.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun showPage(index: Int) {
        val pdf = renderer ?: return
        if (index !in 0 until pdf.pageCount) return
        pdf.openPage(index).use { page ->
            val maxWidth = resources.displayMetrics.widthPixels * 2
            val scale = minOf(2.2f, maxWidth.toFloat() / page.width.coerceAtLeast(1))
            val newBitmap = Bitmap.createBitmap(
                (page.width * scale).toInt().coerceAtLeast(1),
                (page.height * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            newBitmap.eraseColor(Color.WHITE)
            page.render(newBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmap?.recycle()
            bitmap = newBitmap
            binding.pageImage.setImageBitmap(newBitmap)
        }
        pageIndex = index
        binding.tvPage.text = "${index + 1} / ${pdf.pageCount}"
        binding.btnPrevious.isEnabled = index > 0
        binding.btnNext.isEnabled = index < pdf.pageCount - 1
    }

    override fun onDestroy() {
        bitmap?.recycle()
        renderer?.close()
        descriptor?.close()
        super.onDestroy()
    }
}
