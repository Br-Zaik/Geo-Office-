package com.geooffice.app.office

import android.content.Context
import android.net.Uri
import android.util.Xml
import com.geooffice.app.util.XmlUtils
import com.geooffice.app.util.ZipUtils
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipOutputStream

object OpenXmlDocx {
    fun write(context: Context, uri: Uri, text: CharSequence) {
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el documento" }
            ZipOutputStream(output).use { zip ->
                ZipUtils.writeEntry(zip, "[Content_Types].xml", contentTypes())
                ZipUtils.writeEntry(zip, "_rels/.rels", rootRels())
                ZipUtils.writeEntry(zip, "docProps/core.xml", coreProps())
                ZipUtils.writeEntry(zip, "docProps/app.xml", appProps())
                ZipUtils.writeEntry(zip, "word/document.xml", documentXml(text.toString()))
                ZipUtils.writeEntry(zip, "word/styles.xml", stylesXml())
                ZipUtils.writeEntry(zip, "word/_rels/document.xml.rels", documentRels())
            }
        }
    }

    fun read(context: Context, uri: Uri): String {
        val entries = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el documento" }
            ZipUtils.readEntries(input)
        }
        val xml = entries["word/document.xml"] ?: return ""
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xml), "UTF-8")
        val result = StringBuilder()
        var event = parser.eventType
        var inText = false
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "t") inText = true
                    if (name == "tab") result.append('\t')
                    if (name == "br") result.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) result.append(parser.text)
                XmlPullParser.END_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "t") inText = false
                    if (name == "p" && result.isNotEmpty() && result.last() != '\n') result.append('\n')
                }
            }
            event = parser.next()
        }
        return result.toString().trimEnd()
    }

    private fun documentXml(text: String): String {
        val paragraphs = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val body = buildString {
            paragraphs.forEach { line ->
                append("<w:p><w:r><w:rPr><w:lang w:val=\"es-PE\"/></w:rPr><w:t xml:space=\"preserve\">")
                append(XmlUtils.escape(line))
                append("</w:t></w:r></w:p>")
            }
            append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<w:body>$body</w:body></w:document>"""
    }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

    private fun documentRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    private fun coreProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Documento de Geo Office</dc:title><dc:creator>Geo Office</dc:creator><cp:lastModifiedBy>Geo Office</cp:lastModifiedBy>
</cp:coreProperties>"""

    private fun appProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Geo Office</Application></Properties>"""

    private fun stylesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="es-PE"/></w:rPr></w:rPrDefault><w:pPrDefault/></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
</w:styles>"""
}
