package com.geooffice.app.office

import android.content.Context
import android.net.Uri
import android.util.Xml
import com.geooffice.app.util.XmlUtils
import com.geooffice.app.util.ZipUtils
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipOutputStream

object OpenXmlXlsx {
    fun write(context: Context, uri: Uri, rows: List<List<String>>) {
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear la hoja" }
            ZipOutputStream(output).use { zip ->
                ZipUtils.writeEntry(zip, "[Content_Types].xml", contentTypes())
                ZipUtils.writeEntry(zip, "_rels/.rels", rootRels())
                ZipUtils.writeEntry(zip, "docProps/core.xml", coreProps())
                ZipUtils.writeEntry(zip, "docProps/app.xml", appProps())
                ZipUtils.writeEntry(zip, "xl/workbook.xml", workbookXml())
                ZipUtils.writeEntry(zip, "xl/_rels/workbook.xml.rels", workbookRels())
                ZipUtils.writeEntry(zip, "xl/styles.xml", stylesXml())
                ZipUtils.writeEntry(zip, "xl/worksheets/sheet1.xml", sheetXml(rows))
            }
        }
    }

    fun read(context: Context, uri: Uri): List<List<String>> {
        val entries = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la hoja" }
            ZipUtils.readEntries(input)
        }
        val shared = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        return parseSheet(sheet, shared)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var event = parser.eventType
        var inItem = false
        var inText = false
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "si") { inItem = true; current = StringBuilder() }
                    if (name == "t" && inItem) inText = true
                }
                XmlPullParser.TEXT -> if (inText) current.append(parser.text)
                XmlPullParser.END_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "t") inText = false
                    if (name == "si") { result.add(current.toString()); inItem = false }
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val cells = linkedMapOf<Pair<Int, Int>, String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType
        var ref = ""
        var type = ""
        var value = StringBuilder()
        var formula = StringBuilder()
        var activeTag = ""
        var maxRow = 0
        var maxCol = 0
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == "c") {
                        ref = parser.getAttributeValue(null, "r") ?: ""
                        type = parser.getAttributeValue(null, "t") ?: ""
                        value = StringBuilder()
                        formula = StringBuilder()
                    }
                    if (name == "v" || name == "t" || name == "f") activeTag = name
                }
                XmlPullParser.TEXT -> when (activeTag) {
                    "f" -> formula.append(parser.text)
                    "v", "t" -> value.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name.substringAfter(':')
                    if (name == activeTag) activeTag = ""
                    if (name == "c" && ref.isNotBlank()) {
                        val (row, col) = parseCellRef(ref)
                        var cellValue = if (formula.isNotEmpty()) "=${formula}" else value.toString()
                        if (formula.isEmpty() && type == "s") {
                            cellValue = shared.getOrNull(value.toString().toIntOrNull() ?: -1).orEmpty()
                        }
                        cells[row to col] = cellValue
                        maxRow = maxOf(maxRow, row)
                        maxCol = maxOf(maxCol, col)
                    }
                }
            }
            event = parser.next()
        }
        if (cells.isEmpty()) return emptyList()
        return (0..maxRow).map { row -> (0..maxCol).map { col -> cells[row to col].orEmpty() } }
    }

    private fun parseCellRef(ref: String): Pair<Int, Int> {
        val letters = ref.takeWhile { it.isLetter() }.uppercase()
        val digits = ref.dropWhile { it.isLetter() }
        var col = 0
        letters.forEach { col = col * 26 + (it - 'A' + 1) }
        return (digits.toIntOrNull()?.minus(1) ?: 0) to (col - 1).coerceAtLeast(0)
    }

    private fun sheetXml(rows: List<List<String>>): String {
        val xmlRows = buildString {
            rows.forEachIndexed { rowIndex, row ->
                val nonEmpty = row.mapIndexedNotNull { col, value -> if (value.isNotBlank()) col to value else null }
                if (nonEmpty.isEmpty()) return@forEachIndexed
                append("<row r=\"${rowIndex + 1}\">")
                nonEmpty.forEach { (colIndex, raw) ->
                    val ref = columnName(colIndex) + (rowIndex + 1)
                    if (raw.startsWith("=") && raw.length > 1) {
                        append("<c r=\"$ref\"><f>").append(XmlUtils.escape(raw.drop(1))).append("</f><v>0</v></c>")
                    } else if (raw.toDoubleOrNull() != null) {
                        append("<c r=\"$ref\"><v>").append(raw).append("</v></c>")
                    } else {
                        append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                            .append(XmlUtils.escape(raw)).append("</t></is></c>")
                    }
                }
                append("</row>")
            }
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView workbookViewId="0"><selection activeCell="A1" sqref="A1"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="15"/><sheetData>$xmlRows</sheetData>
<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
</worksheet>"""
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val result = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            result.append(('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return result.reverse().toString()
    }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

    private fun workbookXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="12000" windowHeight="8000"/></bookViews>
<sheets><sheet name="Hoja 1" sheetId="1" r:id="rId1"/></sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/>
</workbook>"""

    private fun workbookRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    private fun stylesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="1"><font><sz val="11"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""

    private fun coreProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Hoja de Geo Office</dc:title><dc:creator>Geo Office</dc:creator></cp:coreProperties>"""

    private fun appProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Geo Office</Application></Properties>"""
}
