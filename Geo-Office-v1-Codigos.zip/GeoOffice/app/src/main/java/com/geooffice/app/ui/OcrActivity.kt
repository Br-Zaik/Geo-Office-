package com.geooffice.app.ui

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.geooffice.app.MainActivity
import com.geooffice.app.databinding.ActivityOcrBinding
import com.geooffice.app.office.OpenXmlDocx
import com.geooffice.app.pdf.PdfExporter
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

class OcrActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOcrBinding
    private var imageUri: Uri? = null
    private var pendingCameraUri: Uri? = null

    private val chooseImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { setImage(it) }
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) pendingCameraUri?.let { setImage(it) }
    }

    private val createDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri -> uri?.let { saveDocx(it) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOcrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnGallery.setOnClickListener { chooseImage.launch("image/*") }
        binding.btnCamera.setOnClickListener { launchCamera() }
        binding.btnRecognize.setOnClickListener { recognize() }
        binding.btnSaveDocx.setOnClickListener {
            if (binding.resultText.text.isNullOrBlank()) toast("Primero reconoce o escribe un texto")
            else createDocx.launch("OCR Geo Office.docx")
        }
        binding.btnSavePdf.setOnClickListener {
            if (binding.resultText.text.isNullOrBlank()) toast("Primero reconoce o escribe un texto")
            else createPdf.launch("OCR Geo Office.pdf")
        }

        intent.getStringExtra(MainActivity.EXTRA_URI)?.let { setImage(Uri.parse(it)) }
    }

    private fun launchCamera() {
        val directory = File(cacheDir, "camera").apply { mkdirs() }
        val file = File(directory, "geo_office_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhoto.launch(uri)
    }

    private fun setImage(uri: Uri) {
        imageUri = uri
        binding.imagePreview.setImageURI(uri)
        binding.btnRecognize.isEnabled = true
    }

    private fun recognize() {
        val uri = imageUri ?: return
        binding.btnRecognize.isEnabled = false
        binding.btnRecognize.text = "Reconociendo…"
        runCatching { InputImage.fromFilePath(this, uri) }
            .onFailure {
                binding.btnRecognize.isEnabled = true
                binding.btnRecognize.text = "Reconocer texto"
                toast("No se pudo leer la imagen")
            }
            .onSuccess { image ->
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        binding.resultText.setText(result.text)
                        if (result.text.isBlank()) toast("No se detectó texto legible")
                    }
                    .addOnFailureListener { error -> toast("Error de OCR: ${error.message}") }
                    .addOnCompleteListener {
                        binding.btnRecognize.isEnabled = true
                        binding.btnRecognize.text = "Reconocer texto"
                        recognizer.close()
                    }
            }
    }

    private fun saveDocx(uri: Uri) {
        val text = binding.resultText.text?.toString().orEmpty()
        Thread {
            runCatching { OpenXmlDocx.write(this, uri, text) }
                .onSuccess { runOnUiThread { toast("DOCX guardado") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val text = binding.resultText.text?.toString().orEmpty()
        Thread {
            runCatching { PdfExporter.textToPdf(this, uri, text, "Texto reconocido") }
                .onSuccess { runOnUiThread { toast("PDF guardado") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
