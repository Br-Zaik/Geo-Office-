package com.geooffice.app.util

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream

object UriUtils {
    fun displayName(context: Context, uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) ?: "Archivo" else "Archivo"
            } else {
                uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo"
            }
        } catch (_: Exception) {
            uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo"
        } finally {
            cursor?.close()
        }
    }

    fun extension(context: Context, uri: Uri): String {
        val name = displayName(context, uri)
        return name.substringAfterLast('.', "").lowercase()
    }

    fun readBytes(context: Context, uri: Uri): ByteArray {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el archivo" }
            val output = ByteArrayOutputStream()
            input.copyTo(output)
            return output.toByteArray()
        }
    }
}
