package com.geooffice.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import com.geooffice.app.office.GeoSlide
import java.io.OutputStream
import kotlin.math.min

object PdfExporter {
    private const val A4_WIDTH = 595
    private const val A4_HEIGHT = 842

    fun textToPdf(context: Context, uri: Uri, text: String, title: String = "Geo Office") {
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el PDF" }
            val document = PdfDocument()
            try {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(32, 39, 51)
                    textSize = 14f
                    typeface = Typeface.create("sans", Typeface.NORMAL)
                }
                val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(37, 99, 235)
                    textSize = 12f
                    typeface = Typeface.create("sans", Typeface.BOLD)
                }
                val margin = 48f
                val maxWidth = A4_WIDTH - margin * 2
                val lines = wrapText(text.ifBlank { " " }, paint, maxWidth)
                val lineHeight = 22f
                val linesPerPage = ((A4_HEIGHT - 110f) / lineHeight).toInt().coerceAtLeast(1)
                val pages = lines.chunked(linesPerPage).ifEmpty { listOf(listOf("")) }
                pages.forEachIndexed { pageIndex, pageLines ->
                    val info = PdfDocument.PageInfo.Builder(A4_WIDTH, A4_HEIGHT, pageIndex + 1).create()
                    val page = document.startPage(info)
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)
                    canvas.drawText(title, margin, 34f, titlePaint)
                    canvas.drawLine(margin, 44f, A4_WIDTH - margin, 44f, Paint().apply { color = Color.LTGRAY; strokeWidth = 1f })
                    var y = 72f
                    pageLines.forEach { line ->
                        canvas.drawText(line, margin, y, paint)
                        y += lineHeight
                    }
                    canvas.drawText("${pageIndex + 1} / ${pages.size}", A4_WIDTH - 82f, A4_HEIGHT - 24f, titlePaint)
                    document.finishPage(page)
                }
                document.writeTo(output)
            } finally {
                document.close()
            }
        }
    }

    fun tableToPdf(context: Context, uri: Uri, rows: List<List<String>>) {
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el PDF" }
            val document = PdfDocument()
            try {
                val width = 842
                val height = 595
                val margin = 32f
                val cols = rows.maxOfOrNull { it.size }?.coerceIn(1, 12) ?: 8
                val colWidth = (width - margin * 2) / cols
                val rowHeight = 30f
                val rowsPerPage = ((height - 82f) / rowHeight).toInt().coerceAtLeast(1)
                val data = rows.ifEmpty { listOf(List(cols) { "" }) }
                data.chunked(rowsPerPage).forEachIndexed { pageIndex, pageRows ->
                    val info = PdfDocument.PageInfo.Builder(width, height, pageIndex + 1).create()
                    val page = document.startPage(info)
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)
                    val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(190, 196, 205); style = Paint.Style.STROKE; strokeWidth = 1f }
                    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(22, 32, 51); textSize = 11f }
                    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(22, 163, 74); textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
                    canvas.drawText("Geo Office · Hoja de cálculo", margin, 28f, titlePaint)
                    var y = 48f
                    pageRows.forEach { row ->
                        for (col in 0 until cols) {
                            val left = margin + col * colWidth
                            val rect = RectF(left, y, left + colWidth, y + rowHeight)
                            canvas.drawRect(rect, gridPaint)
                            val value = row.getOrNull(col).orEmpty()
                            val shown = ellipsize(value, textPaint, colWidth - 8f)
                            canvas.drawText(shown, left + 4f, y + 20f, textPaint)
                        }
                        y += rowHeight
                    }
                    document.finishPage(page)
                }
                document.writeTo(output)
            } finally {
                document.close()
            }
        }
    }

    fun slidesToPdf(context: Context, uri: Uri, slides: List<GeoSlide>) {
        context.contentResolver.openOutputStream(uri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el PDF" }
            val document = PdfDocument()
            try {
                val width = 1280
                val height = 720
                val safeSlides = slides.ifEmpty { listOf(GeoSlide()) }
                safeSlides.forEachIndexed { index, slide ->
                    val page = document.startPage(PdfDocument.PageInfo.Builder(width, height, index + 1).create())
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)
                    val accent = Paint().apply { color = Color.rgb(245, 158, 11) }
                    canvas.drawRect(0f, 0f, 18f, height.toFloat(), accent)
                    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.rgb(22, 32, 51)
                        textSize = 52f
                        typeface = Typeface.create("sans", Typeface.BOLD)
                    }
                    val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.rgb(75, 85, 99)
                        textSize = 30f
                    }
                    val titleLines = wrapText(slide.title.ifBlank { "Sin título" }, titlePaint, 1080f)
                    var y = 130f
                    titleLines.take(2).forEach { line -> canvas.drawText(line, 90f, y, titlePaint); y += 64f }
                    y = maxOf(y + 40f, 280f)
                    wrapText(slide.body, bodyPaint, 1080f).take(10).forEach { line -> canvas.drawText(line, 110f, y, bodyPaint); y += 44f }
                    val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 18f }
                    canvas.drawText("Geo Office · ${index + 1}", 1030f, 680f, footer)
                    document.finishPage(page)
                }
                document.writeTo(output)
            } finally {
                document.close()
            }
        }
    }

    fun imagesToPdf(context: Context, outputUri: Uri, images: List<Uri>) {
        context.contentResolver.openOutputStream(outputUri, "w").use { output ->
            requireNotNull(output) { "No se pudo crear el PDF" }
            val document = PdfDocument()
            try {
                images.forEachIndexed { index, imageUri ->
                    val bitmap = loadBitmap(context, imageUri)
                    try {
                        val landscape = bitmap.width > bitmap.height
                        val pageWidth = if (landscape) A4_HEIGHT else A4_WIDTH
                        val pageHeight = if (landscape) A4_WIDTH else A4_HEIGHT
                        val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create())
                        page.canvas.drawColor(Color.WHITE)
                        drawBitmapFit(page.canvas, bitmap, 22f, 22f, pageWidth - 22f, pageHeight - 22f)
                        document.finishPage(page)
                    } finally {
                        bitmap.recycle()
                    }
                }
                document.writeTo(output)
            } finally {
                document.close()
            }
        }
    }

    fun loadBitmap(context: Context, uri: Uri): Bitmap {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val max = 2400
                val width = info.size.width
                val height = info.size.height
                if (width > max || height > max) {
                    val scale = min(max.toFloat() / width, max.toFloat() / height)
                    decoder.setTargetSize((width * scale).toInt(), (height * scale).toInt())
                }
            }
        } else {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                BitmapFactory.decodeStream(input) ?: error("No se pudo leer la imagen")
            }
        }
    }

    fun drawBitmapFit(canvas: Canvas, bitmap: Bitmap, left: Float, top: Float, right: Float, bottom: Float) {
        val targetWidth = right - left
        val targetHeight = bottom - top
        val scale = min(targetWidth / bitmap.width, targetHeight / bitmap.height)
        val width = bitmap.width * scale
        val height = bitmap.height * scale
        val x = left + (targetWidth - width) / 2f
        val y = top + (targetHeight - height) / 2f
        canvas.drawBitmap(bitmap, null, RectF(x, y, x + width, y + height), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        text.replace("\r\n", "\n").replace('\r', '\n').split('\n').forEach { paragraph ->
            if (paragraph.isEmpty()) {
                result.add("")
                return@forEach
            }
            var remaining = paragraph
            while (remaining.isNotEmpty()) {
                var count = paint.breakText(remaining, true, maxWidth, null).coerceAtLeast(1)
                if (count < remaining.length) {
                    val space = remaining.substring(0, count).lastIndexOf(' ')
                    if (space > 0) count = space
                }
                result.add(remaining.substring(0, count).trimEnd())
                remaining = remaining.substring(count).trimStart()
            }
        }
        return result
    }

    private fun ellipsize(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var value = text
        while (value.isNotEmpty() && paint.measureText("$value…") > maxWidth) value = value.dropLast(1)
        return "$value…"
    }
}
