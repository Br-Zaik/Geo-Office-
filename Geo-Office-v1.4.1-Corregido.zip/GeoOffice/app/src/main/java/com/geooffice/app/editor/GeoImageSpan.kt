package com.geooffice.app.editor

import android.graphics.drawable.Drawable
import android.text.style.ImageSpan

class GeoImageSpan(
    drawable: Drawable,
    val sourceUri: String,
    val displayWidthPx: Int,
    val displayHeightPx: Int
) : ImageSpan(drawable, sourceUri, ImageSpan.ALIGN_BOTTOM)
