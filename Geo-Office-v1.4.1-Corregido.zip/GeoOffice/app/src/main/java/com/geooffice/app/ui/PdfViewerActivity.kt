package com.geooffice.app.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.MainActivity
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.databinding.ActivityPdfViewerBinding
import com.geooffice.app.ui.view.ZoomableImageView
import com.geooffice.app.util.UriUtils

class PdfViewerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfViewerBinding
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageIndex = 0
    private var bitmap: Bitmap? = null
    private var currentUri: Uri? = null
    private var pendingZoomState: ZoomableImageView.ZoomState? = null
    private var disableAutoResumeOnExit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            disableResumeAndFinish()
        }
        binding.btnPrevious.setOnClickListener { showPage(pageIndex - 1, keepZoom = false) }
        binding.btnNext.setOnClickListener { showPage(pageIndex + 1, keepZoom = false) }

        val resumeMode = intent.getBooleanExtra(MainActivity.EXTRA_RESUME_SESSION, false)
        currentUri = if (resumeMode) {
            resumePrefs.getString(ResumeSession.PDF_URI, null)?.let(Uri::parse)
                ?: intent.getStringExtra(MainActivity.EXTRA_URI)?.let(Uri::parse)
        } else {
            intent.getStringExtra(MainActivity.EXTRA_URI)?.let(Uri::parse)
        }
        if (resumeMode) {
            pageIndex = resumePrefs.getInt(ResumeSession.PDF_PAGE, 0)
            pendingZoomState = ZoomableImageView.ZoomState(
                resumePrefs.getFloat(ResumeSession.PDF_ZOOM, 1f),
                resumePrefs.getFloat(ResumeSession.PDF_TX, 0f),
                resumePrefs.getFloat(ResumeSession.PDF_TY, 0f)
            )
        }

        val uri = currentUri
        if (uri == null) {
            Toast.makeText(this, "No se recibió el PDF", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        binding.tvTitle.text = UriUtils.displayName(this, uri)
        openPdf(uri)
    }

    private fun openPdf(uri: Uri) {
        runCatching {
            descriptor = contentResolver.openFileDescriptor(uri, "r")
            renderer = PdfRenderer(requireNotNull(descriptor))
            showPage(pageIndex, keepZoom = true)
        }.onFailure {
            Toast.makeText(this, "No se pudo abrir: ${it.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun showPage(index: Int, keepZoom: Boolean) {
        val pdf = renderer ?: return
        if (index !in 0 until pdf.pageCount) return
        pdf.openPage(index).use { page ->
            val maxWidth = resources.displayMetrics.widthPixels * 2
            val scale = minOf(2.2f, maxWidth.toFloat() / page.width.coerceAtLeast(1))
            val newBitmap = Bitmap.createBitmap(
                (page.width * scale).toInt().coerceAtLeast(1),
                (page.height * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            newBitmap.eraseColor(Color.WHITE)
            page.render(newBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmap?.recycle()
            bitmap = newBitmap
            binding.pageImage.setImageBitmap(newBitmap)
            if (keepZoom) {
                pendingZoomState?.let { state ->
                    binding.pageImage.post { binding.pageImage.setZoomState(state) }
                    pendingZoomState = null
                }
            } else {
                binding.pageImage.post { binding.pageImage.resetZoom() }
            }
        }
        pageIndex = index
        binding.tvPage.text = "${index + 1} / ${pdf.pageCount}"
        binding.btnPrevious.isEnabled = index > 0
        binding.btnNext.isEnabled = index < pdf.pageCount - 1
    }

    override fun onPause() {
        super.onPause()
        if (disableAutoResumeOnExit) {
            resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
            return
        }
        val uri = currentUri?.toString() ?: return
        val zoom = binding.pageImage.getZoomState()
        resumePrefs.edit()
            .putBoolean(ResumeSession.AUTO_RESUME, true)
            .putString(ResumeSession.LAST_SCREEN, ResumeSession.SCREEN_PDF)
            .putString(ResumeSession.PDF_URI, uri)
            .putInt(ResumeSession.PDF_PAGE, pageIndex)
            .putFloat(ResumeSession.PDF_ZOOM, zoom.scale)
            .putFloat(ResumeSession.PDF_TX, zoom.translationX)
            .putFloat(ResumeSession.PDF_TY, zoom.translationY)
            .apply()
    }

    private fun disableResumeAndFinish() {
        disableAutoResumeOnExit = true
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
        finish()
    }

    override fun onDestroy() {
        bitmap?.recycle()
        renderer?.close()
        descriptor?.close()
        super.onDestroy()
    }
}
