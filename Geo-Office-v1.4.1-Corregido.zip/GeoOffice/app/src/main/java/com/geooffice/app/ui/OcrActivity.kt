package com.geooffice.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.widget.doOnTextChanged
import com.geooffice.app.MainActivity
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.databinding.ActivityOcrBinding
import com.geooffice.app.office.OpenXmlDocx
import com.geooffice.app.pdf.PdfExporter
import com.geooffice.app.ui.view.ZoomableImageView
import com.geooffice.app.util.UriUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

class OcrActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOcrBinding
    private val imageUris = mutableListOf<Uri>()
    private val editedBitmaps = mutableMapOf<Int, Bitmap>()
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }
    private var currentIndex = 0
    private var pendingCameraUri: Uri? = null
    private var recognizing = false
    private var pendingZoomState: ZoomableImageView.ZoomState? = null
    private var disableAutoResumeOnExit = false

    private val chooseImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
            }
            clearImages()
            imageUris.addAll(uris)
            currentIndex = 0
            pendingZoomState = null
            loadCurrentImage(reset = true)
        }
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) pendingCameraUri?.let { uri ->
            clearImages()
            imageUris.add(uri)
            currentIndex = 0
            pendingZoomState = null
            loadCurrentImage(reset = true)
        }
    }

    private val createDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri -> uri?.let { saveDocx(it) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { savePdf(it) } }

    private val createTxt = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri -> uri?.let { saveTxt(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOcrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { disableResumeAndFinish() }
        binding.btnGallery.setOnClickListener { chooseImages.launch(arrayOf("image/*")) }
        binding.btnCamera.setOnClickListener { launchCamera() }
        binding.btnRecognize.setOnClickListener { recognizeAll() }
        binding.btnPreviousImage.setOnClickListener { moveImage(-1) }
        binding.btnNextImage.setOnClickListener { moveImage(1) }
        binding.btnRotate.setOnClickListener { rotateCurrent() }
        binding.btnGray.setOnClickListener { applyGrayScale() }
        binding.btnEnhance.setOnClickListener { enhanceContrast() }
        binding.btnResetImage.setOnClickListener {
            pendingZoomState = null
            loadCurrentImage(reset = true)
        }
        binding.btnCopyText.setOnClickListener { copyRecognizedText() }
        binding.btnShareText.setOnClickListener { shareRecognizedText() }
        binding.btnClearText.setOnClickListener { binding.resultText.setText("") }
        binding.btnSaveTxt.setOnClickListener {
            if (ensureText()) createTxt.launch("OCR Geo Office.txt")
        }
        binding.btnSaveDocx.setOnClickListener {
            if (ensureText()) createDocx.launch("OCR Geo Office.docx")
        }
        binding.btnSavePdf.setOnClickListener {
            if (ensureText()) createPdf.launch("OCR Geo Office.pdf")
        }

        binding.resultText.doOnTextChanged { text, _, _, _ -> updateOcrInfo(text?.toString().orEmpty()) }
        binding.resultText.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        val resumeMode = intent.getBooleanExtra(MainActivity.EXTRA_RESUME_SESSION, false)
        if (resumeMode && restoreOcrSession()) {
            // restored from saved session
        } else {
            intent.getStringExtra(MainActivity.EXTRA_URI)?.let { raw ->
                imageUris.add(Uri.parse(raw))
                currentIndex = 0
                loadCurrentImage(reset = true)
            }
        }
        updateControls()
        updateOcrInfo(binding.resultText.text?.toString().orEmpty())
    }

    private fun restoreOcrSession(): Boolean {
        val saved = resumePrefs.getString(ResumeSession.OCR_URIS, null).orEmpty()
        if (saved.isBlank()) return false
        imageUris.clear()
        imageUris.addAll(saved.split('\n').filter { it.isNotBlank() }.map(Uri::parse))
        currentIndex = resumePrefs.getInt(ResumeSession.OCR_INDEX, 0).coerceIn(0, imageUris.lastIndex.coerceAtLeast(0))
        binding.resultText.setText(resumePrefs.getString(ResumeSession.OCR_TEXT, "").orEmpty())
        pendingZoomState = ZoomableImageView.ZoomState(
            resumePrefs.getFloat(ResumeSession.OCR_ZOOM, 1f),
            resumePrefs.getFloat(ResumeSession.OCR_TX, 0f),
            resumePrefs.getFloat(ResumeSession.OCR_TY, 0f)
        )
        loadCurrentImage(reset = true)
        return true
    }

    private fun launchCamera() {
        val directory = File(cacheDir, "camera").apply { mkdirs() }
        val file = File(directory, "geo_office_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhoto.launch(uri)
    }

    private fun moveImage(delta: Int) {
        if (imageUris.isEmpty()) return
        currentIndex = (currentIndex + delta).coerceIn(0, imageUris.lastIndex)
        pendingZoomState = null
        loadCurrentImage(reset = false)
    }

    private fun loadCurrentImage(reset: Boolean) {
        val uri = imageUris.getOrNull(currentIndex) ?: return
        if (!reset) {
            editedBitmaps[currentIndex]?.let {
                showBitmap(it)
                return
            }
        }
        binding.imagePreview.setImageDrawable(null)
        Thread {
            runCatching { PdfExporter.loadBitmap(this, uri) }
                .onSuccess { bitmap ->
                    runOnUiThread {
                        editedBitmaps.remove(currentIndex)?.takeIf { it !== bitmap && !it.isRecycled }?.recycle()
                        editedBitmaps[currentIndex] = bitmap
                        showBitmap(bitmap)
                    }
                }
                .onFailure { runOnUiThread { toast("No se pudo abrir la imagen: ${it.message}") } }
        }.start()
    }

    private fun showBitmap(bitmap: Bitmap) {
        binding.imagePreview.setImageBitmap(bitmap)
        binding.imagePreview.post {
            if (pendingZoomState != null) {
                binding.imagePreview.setZoomState(pendingZoomState!!)
                pendingZoomState = null
            } else {
                binding.imagePreview.resetZoom()
            }
        }
        updateControls()
    }

    private fun rotateCurrent() {
        val source = editedBitmaps[currentIndex] ?: return
        val matrix = Matrix().apply { postRotate(90f) }
        val rotated = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        replaceCurrentBitmap(rotated)
    }

    private fun applyGrayScale() {
        val source = editedBitmaps[currentIndex] ?: return
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val matrix = ColorMatrix().apply { setSaturation(0f) }
        canvas.drawBitmap(source, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(matrix) })
        replaceCurrentBitmap(result)
    }

    private fun enhanceContrast() {
        val source = editedBitmaps[currentIndex] ?: return
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val contrast = 1.35f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val matrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        Canvas(result).drawBitmap(source, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(matrix) })
        replaceCurrentBitmap(result)
    }

    private fun replaceCurrentBitmap(bitmap: Bitmap) {
        val previous = editedBitmaps.put(currentIndex, bitmap)
        if (previous != null && previous !== bitmap && !previous.isRecycled) previous.recycle()
        pendingZoomState = null
        showBitmap(bitmap)
    }

    private fun recognizeAll() {
        if (recognizing || imageUris.isEmpty()) return
        recognizing = true
        binding.btnRecognize.isEnabled = false
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizeIndex(0, mutableListOf(), recognizer)
    }

    private fun recognizeIndex(index: Int, pages: MutableList<String>, recognizer: TextRecognizer) {
        if (index >= imageUris.size) {
            val combined = pages.mapIndexed { page, text ->
                if (imageUris.size == 1) text else "Página ${page + 1}\n$text"
            }.joinToString("\n\n")
            binding.resultText.setText(combined)
            if (combined.isBlank()) toast("No se detectó texto legible")
            recognizing = false
            binding.btnRecognize.isEnabled = true
            binding.btnRecognize.text = "Reconocer todas las imágenes"
            recognizer.close()
            return
        }

        binding.btnRecognize.text = "Reconociendo ${index + 1}/${imageUris.size}…"
        val readyBitmap = editedBitmaps[index]
        if (readyBitmap != null) {
            processBitmap(index, readyBitmap, pages, recognizer)
            return
        }
        Thread {
            runCatching { PdfExporter.loadBitmap(this, imageUris[index]) }
                .onSuccess { bitmap ->
                    runOnUiThread {
                        editedBitmaps[index] = bitmap
                        processBitmap(index, bitmap, pages, recognizer)
                    }
                }
                .onFailure { error ->
                    runOnUiThread {
                        pages.add("")
                        toast("No se pudo leer la imagen ${index + 1}: ${error.message}")
                        recognizeIndex(index + 1, pages, recognizer)
                    }
                }
        }.start()
    }

    private fun processBitmap(index: Int, bitmap: Bitmap, pages: MutableList<String>, recognizer: TextRecognizer) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result -> pages.add(result.text) }
            .addOnFailureListener { error ->
                pages.add("")
                toast("Error OCR en imagen ${index + 1}: ${error.message}")
            }
            .addOnCompleteListener { recognizeIndex(index + 1, pages, recognizer) }
    }

    private fun copyRecognizedText() {
        val text = binding.resultText.text?.toString().orEmpty()
        if (text.isBlank()) return toast("No hay texto para copiar")
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("OCR Geo Office", text))
        toast("Texto copiado")
    }

    private fun shareRecognizedText() {
        val text = binding.resultText.text?.toString().orEmpty()
        if (text.isBlank()) return toast("No hay texto para compartir")
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OCR Geo Office")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Compartir texto"))
    }

    private fun saveDocx(uri: Uri) {
        val text = binding.resultText.text?.toString().orEmpty()
        Thread {
            runCatching { OpenXmlDocx.write(this, uri, text) }
                .onSuccess { runOnUiThread { toast("DOCX guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun savePdf(uri: Uri) {
        val text = binding.resultText.text?.toString().orEmpty()
        Thread {
            runCatching { PdfExporter.textToPdf(this, uri, text, "Texto reconocido") }
                .onSuccess { runOnUiThread { toast("PDF guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun saveTxt(uri: Uri) {
        val text = binding.resultText.text?.toString().orEmpty()
        Thread {
            runCatching {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "No se pudo crear el TXT" }
                    output.write(text.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { runOnUiThread { toast("TXT guardado · ${UriUtils.formatSize(UriUtils.size(this, uri))}") } }
                .onFailure { runOnUiThread { toast("Error: ${it.message}") } }
        }.start()
    }

    private fun updateControls() {
        val hasImages = imageUris.isNotEmpty()
        binding.btnRecognize.isEnabled = hasImages && !recognizing
        binding.btnPreviousImage.isEnabled = hasImages && currentIndex > 0
        binding.btnNextImage.isEnabled = hasImages && currentIndex < imageUris.lastIndex
        binding.btnRotate.isEnabled = editedBitmaps[currentIndex] != null
        binding.btnGray.isEnabled = editedBitmaps[currentIndex] != null
        binding.btnEnhance.isEnabled = editedBitmaps[currentIndex] != null
        binding.btnResetImage.isEnabled = hasImages
        binding.tvImageIndex.text = if (hasImages) "${currentIndex + 1}/${imageUris.size}" else "0/0"
    }

    private fun updateOcrInfo(text: String) {
        val lines = if (text.isBlank()) 0 else text.lines().size
        val words = Regex("\\S+").findAll(text).count()
        binding.tvOcrInfo.text = "${text.length} caracteres · $words palabras · $lines líneas"
    }

    private fun ensureText(): Boolean {
        if (binding.resultText.text.isNullOrBlank()) {
            toast("Primero reconoce o escribe un texto")
            return false
        }
        return true
    }

    private fun clearImages() {
        editedBitmaps.values.forEach { if (!it.isRecycled) it.recycle() }
        editedBitmaps.clear()
        imageUris.clear()
    }

    override fun onPause() {
        super.onPause()
        if (disableAutoResumeOnExit) {
            resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
            return
        }
        if (imageUris.isEmpty() && binding.resultText.text.isNullOrBlank()) return
        val zoom = binding.imagePreview.getZoomState()
        resumePrefs.edit()
            .putBoolean(ResumeSession.AUTO_RESUME, true)
            .putString(ResumeSession.LAST_SCREEN, ResumeSession.SCREEN_OCR)
            .putString(ResumeSession.OCR_URIS, imageUris.joinToString("\n") { it.toString() })
            .putInt(ResumeSession.OCR_INDEX, currentIndex)
            .putString(ResumeSession.OCR_TEXT, binding.resultText.text?.toString().orEmpty())
            .putFloat(ResumeSession.OCR_ZOOM, zoom.scale)
            .putFloat(ResumeSession.OCR_TX, zoom.translationX)
            .putFloat(ResumeSession.OCR_TY, zoom.translationY)
            .apply()
    }

    private fun disableResumeAndFinish() {
        disableAutoResumeOnExit = true
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()
        finish()
    }

    override fun onDestroy() {
        clearImages()
        super.onDestroy()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
