package com.geooffice.app.util

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.util.Locale

object UriUtils {
    fun displayName(context: Context, uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) ?: "Archivo" else "Archivo"
            } else {
                uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo"
            }
        } catch (_: Exception) {
            uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo"
        } finally {
            cursor?.close()
        }
    }

    fun extension(context: Context, uri: Uri): String {
        val name = displayName(context, uri)
        return name.substringAfterLast('.', "").lowercase()
    }

    fun size(context: Context, uri: Uri): Long {
        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !cursor.isNull(index)) {
                    val value = cursor.getLong(index)
                    if (value >= 0L) return value
                }
            }
        } catch (_: Exception) {
            // Try the asset descriptor below.
        } finally {
            cursor?.close()
        }
        return runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { descriptor ->
                descriptor.length.takeIf { it >= 0L } ?: 0L
            } ?: 0L
        }.getOrDefault(0L)
    }

    fun totalSize(context: Context, uris: List<Uri>): Long = uris.sumOf { size(context, it) }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.getDefault(), "%.0f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.getDefault(), "%.2f MB", mb)
        return String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
    }

    fun readBytes(context: Context, uri: Uri): ByteArray {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el archivo" }
            val output = ByteArrayOutputStream()
            input.copyTo(output)
            return output.toByteArray()
        }
    }
}
