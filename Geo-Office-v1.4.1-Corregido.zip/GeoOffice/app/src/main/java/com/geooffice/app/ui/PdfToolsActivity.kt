package com.geooffice.app.ui

import android.content.Intent
import android.content.res.Resources
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.geooffice.app.databinding.ActivityPdfToolsBinding
import com.geooffice.app.pdf.PdfOps
import com.geooffice.app.util.UriUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlin.math.roundToInt

class PdfToolsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfToolsBinding
    private var selectedImages: List<Uri> = emptyList()
    private var selectedPdfs: List<Uri> = emptyList()
    private var selectedSinglePdf: Uri? = null
    private var pendingPassword = ""
    private var pendingProtectedName = "Geo Office protegido.pdf"
    private var pendingCompressionProfile = PdfOps.CompressionProfile.MINIMUM
    private var pendingOriginalBytes = 0L
    private var treeAction: TreeAction? = null

    private enum class TreeAction { SPLIT, TO_IMAGES }

    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            persistUris(uris)
            selectedImages = uris
            pendingOriginalBytes = UriUtils.totalSize(this, uris)
            showImagesPdfDialog()
        }
    }

    private val createImagesPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output ->
            val password = pendingPassword
            val profile = pendingCompressionProfile
            val originalBytes = pendingOriginalBytes
            runTask("Creando PDF página por página…") {
                val pages = PdfOps.imagesToProtectedPdf(this, selectedImages, output, password, profile)
                val finalBytes = UriUtils.size(this, output)
                buildResultMessage(
                    heading = "PDF creado con contraseña",
                    itemLine = "$pages imágenes convertidas",
                    originalBytes = originalBytes,
                    finalBytes = finalBytes,
                    profile = profile
                )
            }
        }
    }

    private val pickProtectPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            showPasswordDialog(
                title = "Proteger PDF existente",
                defaultName = "Geo Office protegido",
                message = "Se creará una copia cifrada. El archivo original no se modifica."
            ) { name, password ->
                pendingPassword = password
                pendingProtectedName = ensurePdfExtension(name)
                createProtectedPdf.launch(pendingProtectedName)
            }
        }
    }

    private val createProtectedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val input = selectedSinglePdf
        if (output != null && input != null) {
            val password = pendingPassword
            runTask("Aplicando contraseña…") {
                PdfOps.protect(this, input, output, password)
                val size = UriUtils.size(this, output)
                "PDF protegido correctamente\nTamaño final: ${UriUtils.formatSize(size)}"
            }
        }
    }

    private val pickMergePdfs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.size < 2) toast("Selecciona al menos dos PDF")
        else {
            persistUris(uris)
            selectedPdfs = uris
            createMergedPdf.launch("Geo Office unido.pdf")
        }
    }

    private val createMergedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { output ->
            runTask("Uniendo PDF…") {
                PdfOps.merge(this, selectedPdfs, output)
                "PDF unidos correctamente\nTamaño final: ${UriUtils.formatSize(UriUtils.size(this, output))}"
            }
        }
    }

    private val pickSplitPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            treeAction = TreeAction.SPLIT
            chooseFolder.launch(null)
        }
    }

    private val pickImagePdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            treeAction = TreeAction.TO_IMAGES
            chooseFolder.launch(null)
        }
    }

    private val chooseFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val input = selectedSinglePdf
        val action = treeAction
        if (tree == null || input == null || action == null) return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                tree,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        when (action) {
            TreeAction.SPLIT -> runTask("Dividiendo PDF…") {
                val count = PdfOps.split(this, input, tree)
                "$count páginas PDF guardadas"
            }
            TreeAction.TO_IMAGES -> runTask("Convirtiendo páginas…") {
                val count = PdfOps.toImages(this, input, tree)
                "$count imágenes PNG guardadas"
            }
        }
    }

    private val pickCompressPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistUri(it)
            selectedSinglePdf = it
            pendingOriginalBytes = UriUtils.size(this, it)
            showCompressPdfDialog()
        }
    }

    private val createCompressedPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val input = selectedSinglePdf
        if (output != null && input != null) {
            val profile = pendingCompressionProfile
            val originalBytes = pendingOriginalBytes
            runTask("Comprimiendo página por página…") {
                val count = PdfOps.compressAsImages(this, input, output, profile)
                val finalBytes = UriUtils.size(this, output)
                buildResultMessage(
                    heading = "PDF comprimido",
                    itemLine = "$count páginas procesadas",
                    originalBytes = originalBytes,
                    finalBytes = finalBytes,
                    profile = profile
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.cardImagesToPdf.setOnClickListener { pickImages.launch(arrayOf("image/*")) }
        binding.cardProtectPdf.setOnClickListener { pickProtectPdf.launch(arrayOf("application/pdf")) }
        binding.cardMergePdf.setOnClickListener { pickMergePdfs.launch(arrayOf("application/pdf")) }
        binding.cardSplitPdf.setOnClickListener { pickSplitPdf.launch(arrayOf("application/pdf")) }
        binding.cardPdfToImages.setOnClickListener { pickImagePdf.launch(arrayOf("application/pdf")) }
        binding.cardCompressPdf.setOnClickListener { pickCompressPdf.launch(arrayOf("application/pdf")) }
    }

    private fun showImagesPdfDialog() {
        val container = createDialogContainer()
        val nameLayout = textField("Nombre del PDF", "Geo Office imágenes")
        val passwordLayout = passwordField("Contraseña para abrir", "Mínimo 4 caracteres. No podremos recuperar una contraseña olvidada.")
        val confirmLayout = passwordField("Repetir contraseña", null)
        val compressionTitle = sectionTitle("Compresión y tamaño")
        val estimateText = estimateTextView()
        val profileGroup = createProfileGroup(PdfOps.CompressionProfile.MINIMUM) { selected ->
            pendingCompressionProfile = selected
            updateEstimateText(estimateText, pendingOriginalBytes, selectedImages.size, selected)
        }

        container.addView(nameLayout.first)
        container.addView(passwordLayout.first, marginTopParams(12))
        container.addView(confirmLayout.first, marginTopParams(10))
        container.addView(compressionTitle, marginTopParams(16))
        container.addView(profileGroup, marginTopParams(4))
        container.addView(estimateText, marginTopParams(12))
        updateEstimateText(estimateText, pendingOriginalBytes, selectedImages.size, pendingCompressionProfile)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Crear PDF protegido")
            .setMessage("${selectedImages.size} imágenes seleccionadas. No hay límite artificial por cantidad o peso; se procesan una por una.")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameLayout.second.text?.toString()?.trim().orEmpty()
                val password = passwordLayout.second.text?.toString().orEmpty()
                val confirmation = confirmLayout.second.text?.toString().orEmpty()
                nameLayout.first.error = null
                passwordLayout.first.error = null
                confirmLayout.first.error = null

                when {
                    name.isBlank() -> nameLayout.first.error = "Escribe un nombre"
                    password.length < 4 -> passwordLayout.first.error = "Usa al menos 4 caracteres"
                    password.length > 127 -> passwordLayout.first.error = "La contraseña es demasiado larga"
                    password != confirmation -> confirmLayout.first.error = "Las contraseñas no coinciden"
                    else -> {
                        pendingPassword = password
                        dialog.dismiss()
                        createImagesPdf.launch(ensurePdfExtension(name))
                    }
                }
            }
        }
        dialog.show()
    }

    private fun showCompressPdfDialog() {
        val container = createDialogContainer()
        val nameLayout = textField("Nombre del PDF", "Geo Office comprimido")
        val estimateText = estimateTextView()
        val profileGroup = createProfileGroup(PdfOps.CompressionProfile.MINIMUM) { selected ->
            pendingCompressionProfile = selected
            updateEstimateText(estimateText, pendingOriginalBytes, 1, selected)
        }
        container.addView(sectionTitle("Nivel de compresión"))
        container.addView(profileGroup, marginTopParams(4))
        container.addView(estimateText, marginTopParams(12))
        container.addView(nameLayout.first, marginTopParams(14))
        updateEstimateText(estimateText, pendingOriginalBytes, 1, pendingCompressionProfile)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Comprimir PDF")
            .setMessage("Mínimo peso está seleccionado por defecto. La estimación puede variar según las fotos, gráficos y texto del PDF.")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Comprimir", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameLayout.second.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    nameLayout.first.error = "Escribe un nombre"
                } else {
                    dialog.dismiss()
                    createCompressedPdf.launch(ensurePdfExtension(name))
                }
            }
        }
        dialog.show()
    }

    private fun showPasswordDialog(
        title: String,
        defaultName: String,
        message: String,
        onReady: (String, String) -> Unit
    ) {
        val container = createDialogContainer()
        val nameLayout = textField("Nombre del PDF", defaultName)
        val passwordLayout = passwordField("Contraseña para abrir", "Mínimo 4 caracteres. No podremos recuperar una contraseña olvidada.")
        val confirmLayout = passwordField("Repetir contraseña", null)

        container.addView(nameLayout.first)
        container.addView(passwordLayout.first, marginTopParams(14))
        container.addView(confirmLayout.first, marginTopParams(10))

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                passwordLayout.first.error = null
                confirmLayout.first.error = null
                nameLayout.first.error = null

                val name = nameLayout.second.text?.toString()?.trim().orEmpty()
                val password = passwordLayout.second.text?.toString().orEmpty()
                val confirmation = confirmLayout.second.text?.toString().orEmpty()

                when {
                    name.isBlank() -> nameLayout.first.error = "Escribe un nombre"
                    password.length < 4 -> passwordLayout.first.error = "Usa al menos 4 caracteres"
                    password.length > 127 -> passwordLayout.first.error = "La contraseña es demasiado larga"
                    password != confirmation -> confirmLayout.first.error = "Las contraseñas no coinciden"
                    else -> {
                        dialog.dismiss()
                        onReady(name, password)
                    }
                }
            }
        }
        dialog.show()
    }

    private fun createProfileGroup(
        initial: PdfOps.CompressionProfile,
        onChanged: (PdfOps.CompressionProfile) -> Unit
    ): RadioGroup {
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }
        PdfOps.CompressionProfile.entries.forEach { profile ->
            val button = RadioButton(this).apply {
                id = View.generateViewId()
                tag = profile.name
                text = "${profile.label}\n${profile.description}"
                textSize = 14f
                setPadding(0, 6.dp, 0, 6.dp)
                isChecked = profile == initial
            }
            group.addView(button)
        }
        group.setOnCheckedChangeListener { radioGroup, checkedId ->
            val selectedName = radioGroup.findViewById<RadioButton>(checkedId)?.tag?.toString() ?: return@setOnCheckedChangeListener
            val selected = PdfOps.CompressionProfile.valueOf(selectedName)
            onChanged(selected)
        }
        pendingCompressionProfile = initial
        return group
    }

    private fun updateEstimateText(
        target: TextView,
        originalBytes: Long,
        itemCount: Int,
        profile: PdfOps.CompressionProfile
    ) {
        val estimate = PdfOps.estimateOutputBytes(originalBytes, itemCount, profile)
        val lower = (estimate * 0.80).toLong()
        val upper = (estimate * 1.20).toLong()
        val original = if (originalBytes > 0) UriUtils.formatSize(originalBytes) else "No disponible"
        val saving = if (originalBytes > 0) {
            val percent = (100.0 * (1.0 - estimate.toDouble() / originalBytes.toDouble())).roundToInt().coerceIn(0, 99)
            "\nAhorro aproximado: $percent %"
        } else ""
        target.text = "Tamaño original: $original\nTamaño estimado: ${UriUtils.formatSize(lower)}–${UriUtils.formatSize(upper)}$saving\nEl tamaño final real se mostrará al terminar."
    }

    private fun buildResultMessage(
        heading: String,
        itemLine: String,
        originalBytes: Long,
        finalBytes: Long,
        profile: PdfOps.CompressionProfile
    ): String {
        val originalLine = if (originalBytes > 0L) "\nTamaño original: ${UriUtils.formatSize(originalBytes)}" else ""
        val finalLine = if (finalBytes > 0L) "\nTamaño final real: ${UriUtils.formatSize(finalBytes)}" else "\nTamaño final: no disponible"
        val savingLine = if (originalBytes > 0L && finalBytes > 0L) {
            val saving = (100.0 * (1.0 - finalBytes.toDouble() / originalBytes.toDouble())).roundToInt()
            if (saving >= 0) "\nAhorro real: $saving %" else "\nEl archivo aumentó ${-saving} %"
        } else ""
        return "$heading\n$itemLine\nModo: ${profile.label}$originalLine$finalLine$savingLine"
    }

    private fun createDialogContainer() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(20.dp, 4.dp, 20.dp, 0)
    }

    private fun textField(hint: String, defaultText: String): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this).apply {
            this.hint = hint
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
        }
        val input = TextInputEditText(layout.context).apply {
            setText(defaultText)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        layout.addView(input)
        return layout to input
    }

    private fun passwordField(hint: String, helper: String?): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this).apply {
            this.hint = hint
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
            helperText = helper
        }
        val input = TextInputEditText(layout.context).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        layout.addView(input)
        return layout to input
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun estimateTextView() = TextView(this).apply {
        textSize = 14f
        setPadding(14.dp, 12.dp, 14.dp, 12.dp)
        setBackgroundColor(0xFFF1F5F9.toInt())
    }

    private fun marginTopParams(topDp: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = topDp.dp }

    private fun ensurePdfExtension(name: String): String {
        val clean = name.trim().ifBlank { "Geo Office protegido" }
        return if (clean.endsWith(".pdf", ignoreCase = true)) clean else "$clean.pdf"
    }

    private fun persistUris(uris: List<Uri>) = uris.forEach(::persistUri)

    private fun persistUri(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    private fun runTask(startMessage: String, task: () -> String) {
        toast(startMessage)
        Thread {
            runCatching(task)
                .onSuccess { message ->
                    runOnUiThread {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Proceso terminado")
                            .setMessage(message)
                            .setPositiveButton("Aceptar", null)
                            .show()
                    }
                }
                .onFailure { error -> runOnUiThread { toast("Error: ${error.message}") } }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private val Int.dp: Int
        get() = (this * Resources.getSystem().displayMetrics.density).toInt()
}
