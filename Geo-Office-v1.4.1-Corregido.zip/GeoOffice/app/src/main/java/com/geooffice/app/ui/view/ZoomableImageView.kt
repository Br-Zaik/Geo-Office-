package com.geooffice.app.ui.view

import android.content.Context
import android.graphics.Matrix
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max

class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    data class ZoomState(val scale: Float, val translationX: Float, val translationY: Float)

    private val drawMatrix = Matrix()
    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private val gestureDetector = GestureDetector(context, GestureListener())

    private var currentScale = 1f
    private var minScale = 1f
    private var maxScale = 5f
    private var translationXValue = 0f
    private var translationYValue = 0f
    private var baseScale = 1f
    private var pendingState: ZoomState? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var dragging = false

    init {
        super.setScaleType(ScaleType.MATRIX)
        imageMatrix = drawMatrix
        isClickable = true
    }

    override fun setImageDrawable(drawable: Drawable?) {
        super.setImageDrawable(drawable)
        post { resetZoom(applyPending = true) }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != oldw || h != oldh) {
            post { applyMatrixState() }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastTouchX = event.x
                lastTouchY = event.y
                dragging = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && dragging) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    translationXValue += dx
                    translationYValue += dy
                    clampTranslation()
                    applyMatrixState()
                    lastTouchX = event.x
                    lastTouchY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_POINTER_DOWN -> parent?.requestDisallowInterceptTouchEvent(true)
        }
        return true
    }

    fun resetZoom(applyPending: Boolean = false) {
        currentScale = 1f
        translationXValue = 0f
        translationYValue = 0f
        applyMatrixState()
        if (applyPending) {
            pendingState?.let {
                setZoomState(it)
                pendingState = null
            }
        }
    }

    fun getZoomState(): ZoomState = ZoomState(currentScale, translationXValue, translationYValue)

    fun setZoomState(state: ZoomState) {
        if (drawable == null || width == 0 || height == 0) {
            pendingState = state
            return
        }
        currentScale = state.scale.coerceIn(minScale, maxScale)
        translationXValue = state.translationX
        translationYValue = state.translationY
        clampTranslation()
        applyMatrixState()
    }

    private fun applyMatrixState() {
        val d = drawable ?: return
        if (width == 0 || height == 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return

        baseScale = width.toFloat() / d.intrinsicWidth.toFloat().coerceAtLeast(1f)
        drawMatrix.reset()
        val totalScale = baseScale * currentScale
        drawMatrix.postScale(totalScale, totalScale)
        clampTranslation()
        val finalX = finalTranslationX(d)
        val finalY = finalTranslationY(d)
        drawMatrix.postTranslate(finalX, finalY)
        imageMatrix = drawMatrix
    }

    private fun clampTranslation() {
        val d = drawable ?: return
        translationXValue = translationXValue.coerceIn(minTranslationX(d), maxTranslationX(d))
        translationYValue = translationYValue.coerceIn(minTranslationY(d), maxTranslationY(d))
    }

    private fun renderedWidth(d: Drawable): Float = d.intrinsicWidth * baseScale * currentScale
    private fun renderedHeight(d: Drawable): Float = d.intrinsicHeight * baseScale * currentScale

    private fun finalTranslationX(d: Drawable): Float {
        val contentWidth = renderedWidth(d)
        return if (contentWidth <= width) (width - contentWidth) / 2f else translationXValue
    }

    private fun finalTranslationY(d: Drawable): Float {
        val contentHeight = renderedHeight(d)
        return if (contentHeight <= height) (height - contentHeight) / 2f else translationYValue
    }

    private fun minTranslationX(d: Drawable): Float {
        val contentWidth = renderedWidth(d)
        return if (contentWidth <= width) 0f else width - contentWidth
    }

    private fun maxTranslationX(d: Drawable): Float = if (renderedWidth(d) <= width) 0f else 0f

    private fun minTranslationY(d: Drawable): Float {
        val contentHeight = renderedHeight(d)
        return if (contentHeight <= height) 0f else height - contentHeight
    }

    private fun maxTranslationY(d: Drawable): Float = if (renderedHeight(d) <= height) 0f else 0f

    private fun zoomTo(targetScale: Float, focusX: Float, focusY: Float) {
        val d = drawable ?: return
        val previousTotalScale = baseScale * currentScale
        val imageX = (focusX - finalTranslationX(d)) / previousTotalScale
        val imageY = (focusY - finalTranslationY(d)) / previousTotalScale

        currentScale = targetScale.coerceIn(minScale, maxScale)
        val newTotalScale = baseScale * currentScale
        translationXValue = focusX - imageX * newTotalScale
        translationYValue = focusY - imageY * newTotalScale
        clampTranslation()
        applyMatrixState()
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            parent?.requestDisallowInterceptTouchEvent(true)
            zoomTo(currentScale * detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val target = if (currentScale < 2f) 2.5f else 1f
            zoomTo(target, e.x, e.y)
            return true
        }
    }
}
