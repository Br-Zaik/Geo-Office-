package com.geooffice.app.data

object ResumeSession {
    const val PREFS = "geo_office_resume"
    const val AUTO_RESUME = "auto_resume_next_launch"
    const val LAST_SCREEN = "last_screen"

    const val SCREEN_DOCUMENT = "document"
    const val SCREEN_OCR = "ocr"
    const val SCREEN_PDF = "pdf"

    const val DOC_URI = "doc_uri"
    const val DOC_HTML = "doc_html"
    const val DOC_TITLE = "doc_title"
    const val DOC_SELECTION_START = "doc_selection_start"
    const val DOC_SELECTION_END = "doc_selection_end"
    const val DOC_SCROLL_Y = "doc_scroll_y"
    const val DOC_TEXT_SIZE_SP = "doc_text_size_sp"
    const val DOC_DIRTY = "doc_dirty"
    const val DOC_PANEL = "doc_panel"

    const val OCR_URIS = "ocr_uris"
    const val OCR_INDEX = "ocr_index"
    const val OCR_TEXT = "ocr_text"
    const val OCR_ZOOM = "ocr_zoom"
    const val OCR_TX = "ocr_tx"
    const val OCR_TY = "ocr_ty"

    const val PDF_URI = "pdf_uri"
    const val PDF_PAGE = "pdf_page"
    const val PDF_ZOOM = "pdf_zoom"
    const val PDF_TX = "pdf_tx"
    const val PDF_TY = "pdf_ty"
}
