package com.geooffice.app.ui.view

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatEditText

class PinchZoomEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private var currentTextSizeSp = 16f
    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private val gestureDetector = GestureDetector(context, GestureListener())
    var onZoomChanged: ((Float) -> Unit)? = null

    init {
        currentTextSizeSp = textSize / resources.displayMetrics.scaledDensity
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        if (event.pointerCount > 1) parent?.requestDisallowInterceptTouchEvent(true)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onTouchEvent(event)
    }

    fun applyZoomTextSize(sp: Float) {
        currentTextSizeSp = sp.coerceIn(10f, 30f)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, currentTextSizeSp)
        onZoomChanged?.invoke(currentTextSizeSp)
    }

    fun getZoomTextSizeSp(): Float = currentTextSizeSp

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            applyZoomTextSize(currentTextSizeSp * detector.scaleFactor)
            return true
        }
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            applyZoomTextSize(16f)
            return true
        }
    }
}
