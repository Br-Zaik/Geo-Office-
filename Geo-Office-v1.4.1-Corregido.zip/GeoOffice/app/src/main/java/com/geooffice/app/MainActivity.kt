package com.geooffice.app

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.geooffice.app.data.RecentStore
import com.geooffice.app.data.ResumeSession
import com.geooffice.app.databinding.ActivityMainBinding
import com.geooffice.app.ui.DocumentEditorActivity
import com.geooffice.app.ui.OcrActivity
import com.geooffice.app.ui.PdfToolsActivity
import com.geooffice.app.ui.PdfViewerActivity
import com.geooffice.app.ui.PresentationActivity
import com.geooffice.app.ui.SpreadsheetActivity
import com.geooffice.app.util.UriUtils
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var recentStore: RecentStore
    private val resumePrefs by lazy { getSharedPreferences(ResumeSession.PREFS, MODE_PRIVATE) }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            routeUri(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        recentStore = RecentStore(this)

        binding.cardDocument.setOnClickListener {
            startActivity(Intent(this, DocumentEditorActivity::class.java))
        }
        binding.cardSpreadsheet.setOnClickListener {
            startActivity(Intent(this, SpreadsheetActivity::class.java))
        }
        binding.cardPresentation.setOnClickListener {
            startActivity(Intent(this, PresentationActivity::class.java))
        }
        binding.cardOpenFile.setOnClickListener {
            openFile.launch(arrayOf("*/*"))
        }
        binding.cardOcr.setOnClickListener {
            startActivity(Intent(this, OcrActivity::class.java))
        }
        binding.cardPdfTools.setOnClickListener {
            startActivity(Intent(this, PdfToolsActivity::class.java))
        }

        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { routeUri(it) }
        } else {
            maybeResumeLastSession()
        }
    }

    override fun onResume() {
        super.onResume()
        renderRecents()
    }

    private fun maybeResumeLastSession() {
        if (!resumePrefs.getBoolean(ResumeSession.AUTO_RESUME, false)) return
        val screen = resumePrefs.getString(ResumeSession.LAST_SCREEN, null).orEmpty()
        if (screen.isBlank()) return
        resumePrefs.edit().putBoolean(ResumeSession.AUTO_RESUME, false).apply()

        val target = when (screen) {
            ResumeSession.SCREEN_DOCUMENT -> Intent(this, DocumentEditorActivity::class.java).apply {
                putExtra(EXTRA_URI, resumePrefs.getString(ResumeSession.DOC_URI, null))
            }
            ResumeSession.SCREEN_OCR -> Intent(this, OcrActivity::class.java)
            ResumeSession.SCREEN_PDF -> Intent(this, PdfViewerActivity::class.java).apply {
                putExtra(EXTRA_URI, resumePrefs.getString(ResumeSession.PDF_URI, null))
            }
            else -> null
        } ?: return

        target.putExtra(EXTRA_RESUME_SESSION, true)
        startActivity(target)
    }

    private fun routeUri(uri: Uri) {
        val extension = UriUtils.extension(this, uri)
        val mime = contentResolver.getType(uri).orEmpty()
        val name = UriUtils.displayName(this, uri)

        val target = when {
            extension == "docx" || extension == "txt" || mime == "text/plain" ->
                Intent(this, DocumentEditorActivity::class.java)
            extension == "xlsx" || extension == "csv" || mime.contains("spreadsheet") ->
                Intent(this, SpreadsheetActivity::class.java)
            extension == "pptx" || mime.contains("presentation") ->
                Intent(this, PresentationActivity::class.java)
            extension == "pdf" || mime == "application/pdf" ->
                Intent(this, PdfViewerActivity::class.java)
            mime.startsWith("image/") || extension in setOf("jpg", "jpeg", "png", "webp") ->
                Intent(this, OcrActivity::class.java)
            else -> null
        }

        if (target == null) {
            Toast.makeText(this, "Formato todavía no compatible", Toast.LENGTH_LONG).show()
            return
        }

        target.putExtra(EXTRA_URI, uri.toString())
        target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        recentStore.add(uri, name, extension.ifBlank { mime.substringAfterLast('/') })
        startActivity(target)
    }

    private fun renderRecents() {
        binding.recentContainer.removeAllViews()
        val items = recentStore.getAll()
        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Todavía no has abierto archivos."
                setTextColor(ContextCompat.getColor(context, R.color.geo_text_secondary))
                setPadding(4, 8, 4, 8)
            }
            binding.recentContainer.addView(empty)
            return
        }

        items.forEach { item ->
            val card = MaterialCardView(this).apply {
                radius = 18f
                cardElevation = 1f
                strokeWidth = 1
                setStrokeColor(0x18000000)
                isClickable = true
                isFocusable = true
                setCardBackgroundColor(
                    com.google.android.material.color.MaterialColors.getColor(
                        this,
                        com.google.android.material.R.attr.colorSurfaceContainerLow
                    )
                )
                setOnClickListener {
                    runCatching { routeUri(Uri.parse(item.uri)) }
                        .onFailure {
                            Toast.makeText(context, "No se pudo volver a abrir el archivo", Toast.LENGTH_SHORT).show()
                        }
                }
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16.dp, 14.dp, 16.dp, 14.dp)
            }
            val badge = TextView(this).apply {
                text = when (item.type.lowercase()) {
                    "docx", "txt" -> "W"
                    "xlsx", "csv" -> "X"
                    "pptx" -> "P"
                    "pdf" -> "PDF"
                    else -> "•"
                }
                gravity = Gravity.CENTER
                setTextColor(ContextCompat.getColor(context, R.color.white))
                setTypeface(typeface, Typeface.BOLD)
                textSize = if (text == "PDF") 11f else 18f
                background = ContextCompat.getDrawable(
                    context,
                    when (item.type.lowercase()) {
                        "docx", "txt" -> R.drawable.bg_word
                        "xlsx", "csv" -> R.drawable.bg_excel
                        "pptx" -> R.drawable.bg_powerpoint
                        "pdf" -> R.drawable.bg_pdf
                        else -> R.drawable.bg_open
                    }
                )
                layoutParams = LinearLayout.LayoutParams(44.dp, 44.dp)
            }
            val title = TextView(this).apply {
                text = item.name
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                maxLines = 2
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = 14.dp
                }
            }
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 28f
            }
            row.addView(badge)
            row.addView(title)
            row.addView(arrow)
            card.addView(row)
            binding.recentContainer.addView(
                card,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = 10.dp
                }
            )
        }
    }

    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_RESUME_SESSION = "extra_resume_session"
    }
}
